# Bangladesh Religions - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh Religions**

## CodeSystem: Bangladesh Religions 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/CodeSystem/bd-religions | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDReligionsCS |

 This Code system is referenced in the content logical definition of the following value sets: 

* [BDReligionsVS](ValueSet-bd-religions-valueset.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "bd-religions",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-religions",
  "version" : "0.4.6",
  "name" : "BDReligionsCS",
  "title" : "Bangladesh Religions",
  "status" : "draft",
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "content" : "complete",
  "count" : 7,
  "concept" : [{
    "code" : "1",
    "display" : "Islam",
    "definition" : "Muslim"
  },
  {
    "code" : "2",
    "display" : "Hinduism",
    "definition" : "Hindu"
  },
  {
    "code" : "3",
    "display" : "Buddhism",
    "definition" : "Buddhist"
  },
  {
    "code" : "4",
    "display" : "Christianity",
    "definition" : "Christian"
  },
  {
    "code" : "8",
    "display" : "Refuse to disclose",
    "definition" : "Patient declined to state religion"
  },
  {
    "code" : "9",
    "display" : "Not a believer",
    "definition" : "Identifies as not having a religion"
  },
  {
    "code" : "0",
    "display" : "Other (specify)",
    "definition" : "Other religion (to be specified in free text)"
  }]
}

```
