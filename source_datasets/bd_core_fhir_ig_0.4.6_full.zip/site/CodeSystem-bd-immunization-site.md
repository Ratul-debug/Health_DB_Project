# Bangladesh Immunization Site Code System - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh Immunization Site Code System**

## CodeSystem: Bangladesh Immunization Site Code System 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/CodeSystem/bd-immunization-site | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDImmunizationSiteCS |

 
Codes for anatomical site of vaccine administration in Bangladesh. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [BDImmunizationSiteVS](ValueSet-bd-immunization-site-valueset.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "bd-immunization-site",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-immunization-site",
  "version" : "0.4.6",
  "name" : "BDImmunizationSiteCS",
  "title" : "Bangladesh Immunization Site Code System",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Codes for anatomical site of vaccine administration in Bangladesh.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 5,
  "concept" : [{
    "code" : "LA",
    "display" : "Left Arm",
    "definition" : "Vaccine administered in the left arm (intramuscular or subcutaneous)."
  },
  {
    "code" : "RA",
    "display" : "Right Arm",
    "definition" : "Vaccine administered in the right arm."
  },
  {
    "code" : "LT",
    "display" : "Left Thigh",
    "definition" : "Vaccine administered in the left thigh."
  },
  {
    "code" : "RT",
    "display" : "Right Thigh",
    "definition" : "Vaccine administered in the right thigh."
  },
  {
    "code" : "ORAL",
    "display" : "Oral",
    "definition" : "Vaccine administered orally (e.g., OPV, Rotavirus)."
  }]
}

```
