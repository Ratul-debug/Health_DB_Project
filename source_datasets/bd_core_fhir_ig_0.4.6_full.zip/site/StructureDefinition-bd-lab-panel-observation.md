# Bangladesh Laboratory Panel Observation - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh Laboratory Panel Observation**

## Resource Profile: Bangladesh Laboratory Panel Observation 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/StructureDefinition/bd-lab-panel-observation | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDLabPanelObservationProfile |

 
Profile for laboratory panel (order-level) Observations in Bangladesh. Represents an ordered laboratory test panel (e.g. CBC, LFT, RFT) as the parent Observation in a hasMember hierarchy. 
Usage: 
* Observation.code is the panel/order code (from BD LOINC Lab Panels ValueSet)
* Observation.hasMember references individual result Observations (bd-lab-result-observation) for each component
* Observation.value[x] is prohibited — panels do not carry a direct result value
* Observation.category is fixed to 'laboratory'
 
FHIR hasMember pattern: DiagnosticReport.result –> bd-lab-panel-observation └── hasMember –> bd-lab-result-observation (x N) 

**Usages:**

* Refer to this Profile: [Bangladesh Laboratory Report](StructureDefinition-bd-lab-report.md) and [Bangladesh Laboratory Result Observation](StructureDefinition-bd-lab-result-observation.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/bd.fhir.core|current/StructureDefinition/bd-lab-panel-observation)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-bd-lab-panel-observation.csv), [Excel](StructureDefinition-bd-lab-panel-observation.xlsx), [Schematron](StructureDefinition-bd-lab-panel-observation.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "bd-lab-panel-observation",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-lab-panel-observation",
  "version" : "0.4.6",
  "name" : "BDLabPanelObservationProfile",
  "title" : "Bangladesh Laboratory Panel Observation",
  "status" : "draft",
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Profile for laboratory panel (order-level) Observations in Bangladesh.\nRepresents an ordered laboratory test panel (e.g. CBC, LFT, RFT) as the\nparent Observation in a hasMember hierarchy.\n\nUsage:\n  - Observation.code is the panel/order code (from BD LOINC Lab Panels ValueSet)\n  - Observation.hasMember references individual result Observations\n    (bd-lab-result-observation) for each component\n  - Observation.value[x] is prohibited — panels do not carry a direct result value\n  - Observation.category is fixed to 'laboratory'\n\nFHIR hasMember pattern:\n  DiagnosticReport.result --> bd-lab-panel-observation\n                                  └── hasMember --> bd-lab-result-observation (x N)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-observation",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation"
    },
    {
      "id" : "Observation.identifier",
      "path" : "Observation.identifier",
      "min" : 1
    },
    {
      "id" : "Observation.status",
      "path" : "Observation.status",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.org/fhir/ValueSet/observation-status"
      }
    },
    {
      "id" : "Observation.category",
      "path" : "Observation.category",
      "definition" : "Fixed to 'laboratory' for laboratory panel observations",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }
    },
    {
      "id" : "Observation.code",
      "path" : "Observation.code",
      "definition" : "LOINC panel/order code for this laboratory panel",
      "comment" : "E.g. 58410-2 CBC panel, 24323-8 Comprehensive metabolic panel",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.dghs.gov.bd/core/ValueSet/loinc-lab-panels"
      }
    },
    {
      "id" : "Observation.effective[x]",
      "path" : "Observation.effective[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1,
      "type" : [{
        "code" : "dateTime"
      },
      {
        "code" : "Period"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.effective[x]:effectiveDateTime",
      "path" : "Observation.effective[x]",
      "sliceName" : "effectiveDateTime",
      "definition" : "Date/time the laboratory panel was performed",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "Observation.value[x]",
      "path" : "Observation.value[x]",
      "max" : "0"
    },
    {
      "id" : "Observation.value[x]:valueQuantity",
      "path" : "Observation.value[x]",
      "sliceName" : "valueQuantity",
      "max" : "0",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "Observation.value[x]:valueString",
      "path" : "Observation.value[x]",
      "sliceName" : "valueString",
      "max" : "0",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "Observation.value[x]:valueCodeableConcept",
      "path" : "Observation.value[x]",
      "sliceName" : "valueCodeableConcept",
      "max" : "0",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "Observation.value[x]:valueBoolean",
      "path" : "Observation.value[x]",
      "sliceName" : "valueBoolean",
      "max" : "0",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "Observation.value[x]:valueInteger",
      "path" : "Observation.value[x]",
      "sliceName" : "valueInteger",
      "max" : "0",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "Observation.value[x]:valueRange",
      "path" : "Observation.value[x]",
      "sliceName" : "valueRange",
      "max" : "0",
      "type" : [{
        "code" : "Range"
      }]
    },
    {
      "id" : "Observation.value[x]:valueRatio",
      "path" : "Observation.value[x]",
      "sliceName" : "valueRatio",
      "max" : "0",
      "type" : [{
        "code" : "Ratio"
      }]
    },
    {
      "id" : "Observation.value[x]:valueSampledData",
      "path" : "Observation.value[x]",
      "sliceName" : "valueSampledData",
      "max" : "0",
      "type" : [{
        "code" : "SampledData"
      }]
    },
    {
      "id" : "Observation.value[x]:valueTime",
      "path" : "Observation.value[x]",
      "sliceName" : "valueTime",
      "max" : "0",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "Observation.value[x]:valueDateTime",
      "path" : "Observation.value[x]",
      "sliceName" : "valueDateTime",
      "max" : "0",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "Observation.value[x]:valuePeriod",
      "path" : "Observation.value[x]",
      "sliceName" : "valuePeriod",
      "max" : "0",
      "type" : [{
        "code" : "Period"
      }]
    },
    {
      "id" : "Observation.note",
      "path" : "Observation.note",
      "definition" : "Comments about the laboratory panel",
      "mustSupport" : true
    },
    {
      "id" : "Observation.specimen",
      "path" : "Observation.specimen",
      "definition" : "Specimen collected for this laboratory panel",
      "comment" : "Should be present when specimen information is available"
    },
    {
      "id" : "Observation.hasMember",
      "path" : "Observation.hasMember",
      "definition" : "References to individual component result Observations for this panel",
      "comment" : "Each hasMember entry is a bd-lab-result-observation",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-lab-result-observation"]
      }]
    },
    {
      "id" : "Observation.derivedFrom",
      "path" : "Observation.derivedFrom",
      "max" : "0"
    }]
  }
}

```
