# Example Medication - BDMedicationExample - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example Medication - BDMedicationExample**

## Example Medication: Example Medication - BDMedicationExample

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

-------

**English**

-------

Profile: [Medication Profile for Bangladesh](StructureDefinition-bd-medication.md)

**code**: Marvelous Fe

**form**: Tablet

> **ingredient****item**: Ferrous sulphate**isActive**: true

> **ingredient****item**: Folic acid**isActive**: true

-------

**German**

-------

Profile: [Medication Profile for Bangladesh](StructureDefinition-bd-medication.md)

**code**: Marvelous Fe

**form**: Tablet

> **ingredient****item**: Ferrous sulphate**isActive**: true

> **ingredient****item**: Folic acid**isActive**: true

-------

**French**

-------

Profil: [Medication Profile for Bangladesh](StructureDefinition-bd-medication.md)

**code**: Marvelous Fe

**form**: Tablet

> **ingredient****item**: Ferrous sulphate**isActive**: true

> **ingredient****item**: Folic acid**isActive**: true



## Resource Content

```json
{
  "resourceType" : "Medication",
  "id" : "BDMedicationExample",
  "meta" : {
    "profile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-medication"]
  },
  "code" : {
    "coding" : [{
      "system" : "https://dgda.gov.bd/drug-registry",
      "code" : "353-0026-039--marvelous-fe",
      "display" : "Marvelous Fe"
    }],
    "text" : "Marvelous Fe"
  },
  "form" : {
    "coding" : [{
      "system" : "http://standardterms.edqm.eu",
      "code" : "10219000",
      "display" : "Tablet"
    }]
  },
  "ingredient" : [{
    "itemCodeableConcept" : {
      "coding" : [{
        "system" : "http://id.who.int/icd/release/11/mms",
        "code" : "XM3SQ1",
        "display" : "Ferrous sulphate"
      }],
      "text" : "Ferrous sulphate"
    },
    "isActive" : true
  },
  {
    "itemCodeableConcept" : {
      "coding" : [{
        "system" : "http://id.who.int/icd/release/11/mms",
        "code" : "XM7R82",
        "display" : "Folic acid"
      }],
      "text" : "Folic acid"
    },
    "isActive" : true
  }]
}

```
