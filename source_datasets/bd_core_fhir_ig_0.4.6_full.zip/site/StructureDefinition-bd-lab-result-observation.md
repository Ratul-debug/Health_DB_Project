# Bangladesh Laboratory Result Observation - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh Laboratory Result Observation**

## Resource Profile: Bangladesh Laboratory Result Observation 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/StructureDefinition/bd-lab-result-observation | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDLabResultObservationProfile |

 
Profile for individual laboratory result (component-level) Observations in Bangladesh. Represents a single test result within a laboratory panel (e.g. Haemoglobin within a CBC panel). 
Usage: 
* Observation.code is the result/component code (from BD LOINC Lab Results ValueSet)
* Observation.value[x] is required — every leaf result must carry a value
* Observation.hasMember is prohibited — leaf results cannot group further
* Observation.derivedFrom references the parent panel Observation
* Observation.category is fixed to 'laboratory'
 
FHIR hasMember pattern: bd-lab-panel-observation └── hasMember –> bd-lab-result-observation (this profile) 
Coded results (Ord/Nom scale): Use valueCodeableConcept with codes from BD LOINC Answer Lists ValueSet. 

**Usages:**

* Refer to this Profile: [Bangladesh Laboratory Panel Observation](StructureDefinition-bd-lab-panel-observation.md) and [Bangladesh Laboratory Report](StructureDefinition-bd-lab-report.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/bd.fhir.core|current/StructureDefinition/bd-lab-result-observation)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-bd-lab-result-observation.csv), [Excel](StructureDefinition-bd-lab-result-observation.xlsx), [Schematron](StructureDefinition-bd-lab-result-observation.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "bd-lab-result-observation",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-lab-result-observation",
  "version" : "0.4.6",
  "name" : "BDLabResultObservationProfile",
  "title" : "Bangladesh Laboratory Result Observation",
  "status" : "draft",
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Profile for individual laboratory result (component-level) Observations\nin Bangladesh. Represents a single test result within a laboratory panel\n(e.g. Haemoglobin within a CBC panel).\n\nUsage:\n  - Observation.code is the result/component code (from BD LOINC Lab Results ValueSet)\n  - Observation.value[x] is required — every leaf result must carry a value\n  - Observation.hasMember is prohibited — leaf results cannot group further\n  - Observation.derivedFrom references the parent panel Observation\n  - Observation.category is fixed to 'laboratory'\n\nFHIR hasMember pattern:\n  bd-lab-panel-observation\n      └── hasMember --> bd-lab-result-observation (this profile)\n\nCoded results (Ord/Nom scale):\n  Use valueCodeableConcept with codes from BD LOINC Answer Lists ValueSet.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-observation",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation"
    },
    {
      "id" : "Observation.identifier",
      "path" : "Observation.identifier",
      "min" : 1
    },
    {
      "id" : "Observation.status",
      "path" : "Observation.status",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.org/fhir/ValueSet/observation-status"
      }
    },
    {
      "id" : "Observation.category",
      "path" : "Observation.category",
      "definition" : "Fixed to 'laboratory' for laboratory result observations",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      }
    },
    {
      "id" : "Observation.code",
      "path" : "Observation.code",
      "definition" : "LOINC result/component code for this individual laboratory result",
      "comment" : "E.g. 718-7 Hemoglobin, 2160-0 Creatinine",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.dghs.gov.bd/core/ValueSet/loinc-lab-results"
      }
    },
    {
      "id" : "Observation.effective[x]",
      "path" : "Observation.effective[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1,
      "type" : [{
        "code" : "dateTime"
      },
      {
        "code" : "Period"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.effective[x]:effectiveDateTime",
      "path" : "Observation.effective[x]",
      "sliceName" : "effectiveDateTime",
      "definition" : "Date/time the result was obtained",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "Observation.value[x]",
      "path" : "Observation.value[x]",
      "definition" : "The actual result value for this laboratory test",
      "min" : 1,
      "type" : [{
        "code" : "Quantity"
      },
      {
        "code" : "CodeableConcept"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x]:valueQuantity",
      "path" : "Observation.value[x]",
      "sliceName" : "valueQuantity",
      "comment" : "Use for quantitative (Qn scale) results. Units must be UCUM.",
      "type" : [{
        "code" : "Quantity"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x]:valueQuantity.value",
      "path" : "Observation.value[x].value",
      "min" : 1
    },
    {
      "id" : "Observation.value[x]:valueQuantity.unit",
      "path" : "Observation.value[x].unit",
      "min" : 1
    },
    {
      "id" : "Observation.value[x]:valueQuantity.system",
      "path" : "Observation.value[x].system",
      "min" : 1
    },
    {
      "id" : "Observation.value[x]:valueQuantity.code",
      "path" : "Observation.value[x].code",
      "min" : 1
    },
    {
      "id" : "Observation.value[x]:valueCodeableConcept",
      "path" : "Observation.value[x]",
      "sliceName" : "valueCodeableConcept",
      "comment" : "Use for ordinal or nominal (Ord/Nom scale) results.",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.dghs.gov.bd/core/ValueSet/loinc-answer-lists"
      }
    },
    {
      "id" : "Observation.interpretation",
      "path" : "Observation.interpretation",
      "definition" : "Clinical interpretation of the result value",
      "comment" : "E.g. H (High), L (Low), N (Normal), A (Abnormal)",
      "mustSupport" : true
    },
    {
      "id" : "Observation.note",
      "path" : "Observation.note",
      "definition" : "Comments about this individual result",
      "mustSupport" : true
    },
    {
      "id" : "Observation.specimen",
      "path" : "Observation.specimen",
      "definition" : "Specimen used for this result observation",
      "comment" : "Should be consistent with the parent panel specimen"
    },
    {
      "id" : "Observation.referenceRange",
      "path" : "Observation.referenceRange",
      "definition" : "Normal reference range for this result",
      "comment" : "Should be present when reference ranges are known",
      "mustSupport" : true
    },
    {
      "id" : "Observation.hasMember",
      "path" : "Observation.hasMember",
      "max" : "0"
    },
    {
      "id" : "Observation.derivedFrom",
      "path" : "Observation.derivedFrom",
      "definition" : "Reference to the parent panel Observation this result belongs to",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-lab-panel-observation"]
      }]
    }]
  }
}

```
