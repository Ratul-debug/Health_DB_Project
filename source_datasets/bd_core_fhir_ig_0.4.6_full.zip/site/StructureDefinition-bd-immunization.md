# Immunization Profile for Bangladesh - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Immunization Profile for Bangladesh**

## Resource Profile: Immunization Profile for Bangladesh 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/StructureDefinition/bd-immunization | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDImmunizationProfile |

 
Bangladesh Immunization Profile 

**Usages:**

* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/bd.fhir.core|current/StructureDefinition/bd-immunization)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-bd-immunization.csv), [Excel](StructureDefinition-bd-immunization.xlsx), [Schematron](StructureDefinition-bd-immunization.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "bd-immunization",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-immunization",
  "version" : "0.4.6",
  "name" : "BDImmunizationProfile",
  "title" : "Immunization Profile for Bangladesh",
  "status" : "draft",
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Bangladesh Immunization Profile",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Immunization",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Immunization",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Immunization",
      "path" : "Immunization"
    },
    {
      "id" : "Immunization.identifier",
      "path" : "Immunization.identifier",
      "short" : "Unique identifier",
      "definition" : "Unique identifier for the vaccination event",
      "min" : 1
    },
    {
      "id" : "Immunization.vaccineCode",
      "path" : "Immunization.vaccineCode",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.dghs.gov.bd/core/ValueSet/bd-vaccine-valueset"
      }
    },
    {
      "id" : "Immunization.patient",
      "path" : "Immunization.patient",
      "definition" : "The patient receiving the vaccine",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-patient"]
      }]
    },
    {
      "id" : "Immunization.encounter",
      "path" : "Immunization.encounter",
      "definition" : "Encounter during which vaccine was administered",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-encounter"]
      }]
    },
    {
      "id" : "Immunization.location",
      "path" : "Immunization.location",
      "definition" : "Location where vaccine was administered",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-location"]
      }]
    },
    {
      "id" : "Immunization.manufacturer",
      "path" : "Immunization.manufacturer",
      "short" : "Manufacturer",
      "definition" : "Vaccine manufacturer",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-organization"]
      }]
    },
    {
      "id" : "Immunization.lotNumber",
      "path" : "Immunization.lotNumber",
      "short" : "Vaccine Lot Number",
      "definition" : "Vaccine lot or batch number"
    },
    {
      "id" : "Immunization.expirationDate",
      "path" : "Immunization.expirationDate",
      "short" : "Expiration Date",
      "definition" : "Expiration date of vaccine lot"
    },
    {
      "id" : "Immunization.site",
      "path" : "Immunization.site",
      "definition" : "Body site of administration",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.dghs.gov.bd/core/ValueSet/bd-immunization-site-valueset"
      }
    },
    {
      "id" : "Immunization.route",
      "path" : "Immunization.route",
      "definition" : "Route of administration",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.dghs.gov.bd/core/ValueSet/bd-immunization-route-valueset"
      }
    },
    {
      "id" : "Immunization.doseQuantity",
      "path" : "Immunization.doseQuantity",
      "definition" : "Amount of vaccine administered"
    },
    {
      "id" : "Immunization.doseQuantity.system",
      "path" : "Immunization.doseQuantity.system",
      "patternUri" : "http://unitsofmeasure.org"
    },
    {
      "id" : "Immunization.performer",
      "path" : "Immunization.performer",
      "definition" : "Individual who performed the immunization"
    },
    {
      "id" : "Immunization.performer.actor",
      "path" : "Immunization.performer.actor",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-practitioner"]
      }]
    },
    {
      "id" : "Immunization.reaction",
      "path" : "Immunization.reaction",
      "definition" : "Adverse reaction following immunization"
    }]
  }
}

```
