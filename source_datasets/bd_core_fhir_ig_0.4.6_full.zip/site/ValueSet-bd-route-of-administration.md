# Route of Administration Value Set - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Route of Administration Value Set**

## ValueSet: Route of Administration Value Set 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/ValueSet/bd-route-of-administration | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDRouteOfAdministrationVS |

 
Value set containing route of administration concepts from the HL7 Version 3 RouteOfAdministration code system. 
This value set is used to code the route by which a medication is administered in MedicationRequest.dosageInstruction.route. HL7 v3 RouteOfAdministration is a license-free, internationally recognised vocabulary already embedded in the FHIR ecosystem. 
Concepts are loaded into the national OCL terminology server at https://tr.ocl.dghs.gov.bd under the MoHFW organisation. 
**Code system canonical:** http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration **Binding:** required on BDMedicationRequest.dosageInstruction.route 

 **References** 

* [Medication Request Profile for Bangladesh](StructureDefinition-bd-medication-request.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "bd-route-of-administration",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/ValueSet/bd-route-of-administration",
  "version" : "0.4.6",
  "name" : "BDRouteOfAdministrationVS",
  "title" : "Route of Administration Value Set",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Value set containing route of administration concepts from the HL7 Version 3\nRouteOfAdministration code system.\n\nThis value set is used to code the route by which a medication is administered\nin MedicationRequest.dosageInstruction.route. HL7 v3 RouteOfAdministration\nis a license-free, internationally recognised vocabulary already embedded in\nthe FHIR ecosystem.\n\nConcepts are loaded into the national OCL terminology server at\nhttps://tr.ocl.dghs.gov.bd under the MoHFW organisation.\n\n**Code system canonical:** http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration\n**Binding:** required on BDMedicationRequest.dosageInstruction.route",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "immutable" : false,
  "compose" : {
    "include" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration"
    }]
  }
}

```
