# Location of Immunization for Bangladesh - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location of Immunization for Bangladesh**

## Resource Profile: Location of Immunization for Bangladesh 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/StructureDefinition/bd-location | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDLocation |

 
Address for Bangladesh Standard 

**Usages:**

* Refer to this Profile: [Immunization Profile for Bangladesh](StructureDefinition-bd-immunization.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/bd.fhir.core|current/StructureDefinition/bd-location)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-bd-location.csv), [Excel](StructureDefinition-bd-location.xlsx), [Schematron](StructureDefinition-bd-location.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "bd-location",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-location",
  "version" : "0.4.6",
  "name" : "BDLocation",
  "title" : "Location of Immunization for Bangladesh",
  "status" : "draft",
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Address for Bangladesh Standard",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Location",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Location",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Location",
      "path" : "Location"
    },
    {
      "id" : "Location.address",
      "path" : "Location.address",
      "min" : 1,
      "type" : [{
        "code" : "Address",
        "profile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-address"]
      }]
    }]
  }
}

```
