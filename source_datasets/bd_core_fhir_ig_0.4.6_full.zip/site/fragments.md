# Fragments - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Detailed BD-Core-FHIR Specification**](spec.md)
* **Fragments**

## Fragments

| |
| :--- |
| *Page standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) |

 This documentation has moved to the [IG Guidance](https://build.fhir.org/ig/FHIR/ig-guidance/fragments.html) IG. 

