# Bangladesh Blood Group CodeSystem - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh Blood Group CodeSystem**

## CodeSystem: Bangladesh Blood Group CodeSystem 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/CodeSystem/bd-blood-groups | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDBloodGroupCS |

 
Blood group codes according to CCDS guideline 

 This Code system is referenced in the content logical definition of the following value sets: 

* [BDBloodGroupVS](ValueSet-bd-blood-group-valueset.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "bd-blood-groups",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-blood-groups",
  "version" : "0.4.6",
  "name" : "BDBloodGroupCS",
  "title" : "Bangladesh Blood Group CodeSystem",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Blood group codes according to CCDS guideline",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 8,
  "concept" : [{
    "code" : "1",
    "display" : "O Positive"
  },
  {
    "code" : "2",
    "display" : "O Negative"
  },
  {
    "code" : "3",
    "display" : "A Positive"
  },
  {
    "code" : "4",
    "display" : "A Negative"
  },
  {
    "code" : "5",
    "display" : "B Positive"
  },
  {
    "code" : "6",
    "display" : "B Negative"
  },
  {
    "code" : "7",
    "display" : "AB Positive"
  },
  {
    "code" : "8",
    "display" : "AB Negative"
  }]
}

```
