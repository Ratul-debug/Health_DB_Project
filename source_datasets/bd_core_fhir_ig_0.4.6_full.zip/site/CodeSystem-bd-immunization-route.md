# Bangladesh Immunization Route Code System - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh Immunization Route Code System**

## CodeSystem: Bangladesh Immunization Route Code System 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/CodeSystem/bd-immunization-route | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDImmunizationRouteCS |

 
Codes for routes of vaccine administration in Bangladesh. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [BDImmunizationRouteVS](ValueSet-bd-immunization-route-valueset.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "bd-immunization-route",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-immunization-route",
  "version" : "0.4.6",
  "name" : "BDImmunizationRouteCS",
  "title" : "Bangladesh Immunization Route Code System",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Codes for routes of vaccine administration in Bangladesh.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 5,
  "concept" : [{
    "code" : "IM",
    "display" : "Intramuscular",
    "definition" : "Vaccine administered into a muscle."
  },
  {
    "code" : "SC",
    "display" : "Subcutaneous",
    "definition" : "Vaccine administered under the skin."
  },
  {
    "code" : "ID",
    "display" : "Intradermal",
    "definition" : "Vaccine administered into the dermis layer of the skin."
  },
  {
    "code" : "ORAL",
    "display" : "Oral",
    "definition" : "Vaccine administered orally."
  },
  {
    "code" : "IN",
    "display" : "Intranasal",
    "definition" : "Vaccine administered via the nose."
  }]
}

```
