# Medication Profile for Bangladesh - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medication Profile for Bangladesh**

## Resource Profile: Medication Profile for Bangladesh 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/StructureDefinition/bd-medication | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDMedication |

 
Profile of the Medication resource for the Bangladesh National Health Information Exchange (HIE). Drug products are coded using the DGDA Drug Registry maintained by the Drug Registration Authority of Bangladesh and served via the national OCL terminology server at https://tr.ocl.dghs.gov.bd. 
Ingredient coding uses ICD-11 MMS substance codes (XM-prefix) to support International Patient Summary (IPS) generation and cross-border data exchange. Ingredient data is system-populated from OCL Has-active-ingredient mappings and is not required to be entered manually by clinicians. 
Combination drugs are supported via the repeating ingredient element. Unmatched ingredients (not yet mapped to ICD-11 substances) may be represented using ingredient.itemCodeableConcept.text without a coded value. 
Dose form is optional and should be coded using EDQM Standard Terms when populated. Dose form is derivable from the DGDA drug concept via OCL lookup. A DGDA plain text dose form to EDQM code mapping is planned for a future IG version. 

**Usages:**

* Refer to this Profile: [Medication Request Profile for Bangladesh](StructureDefinition-bd-medication-request.md)
* Examples for this Profile: [Medication/BDMedicationExample](Medication-BDMedicationExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/bd.fhir.core|current/StructureDefinition/bd-medication)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-bd-medication.csv), [Excel](StructureDefinition-bd-medication.xlsx), [Schematron](StructureDefinition-bd-medication.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "bd-medication",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-medication",
  "version" : "0.4.6",
  "name" : "BDMedication",
  "title" : "Medication Profile for Bangladesh",
  "status" : "draft",
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Profile of the Medication resource for the Bangladesh National Health Information\nExchange (HIE). Drug products are coded using the DGDA Drug Registry maintained\nby the Drug Registration Authority of Bangladesh and served via the national OCL\nterminology server at https://tr.ocl.dghs.gov.bd.\n\nIngredient coding uses ICD-11 MMS substance codes (XM-prefix) to support\nInternational Patient Summary (IPS) generation and cross-border data exchange.\nIngredient data is system-populated from OCL Has-active-ingredient mappings and\nis not required to be entered manually by clinicians.\n\nCombination drugs are supported via the repeating ingredient element.\nUnmatched ingredients (not yet mapped to ICD-11 substances) may be represented\nusing ingredient.itemCodeableConcept.text without a coded value.\n\nDose form is optional and should be coded using EDQM Standard Terms when\npopulated. Dose form is derivable from the DGDA drug concept via OCL lookup.\nA DGDA plain text dose form to EDQM code mapping is planned for a future\nIG version.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "script10.6",
    "uri" : "http://ncpdp.org/SCRIPT10_6",
    "name" : "Mapping to NCPDP SCRIPT 10.6"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Medication",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Medication",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Medication",
      "path" : "Medication"
    },
    {
      "id" : "Medication.code",
      "path" : "Medication.code",
      "short" : "DGDA registered drug product code",
      "definition" : "The DGDA drug registry code identifying the finished pharmaceutical product.\nConcept ID format: {DAR-number}--{trade-name-slug}\nExample: 353-0026-039--marvelous-fe",
      "min" : 1,
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://dgda.gov.bd/fhir/ValueSet/registered-drugs"
      }
    },
    {
      "id" : "Medication.code.text",
      "path" : "Medication.code.text",
      "short" : "Trade name of the drug product",
      "definition" : "The trade name of the drug product as registered with DGDA. Mandatory for\nhuman readability in IPS documents and cross-border data exchange scenarios.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Medication.form",
      "path" : "Medication.form",
      "short" : "Pharmaceutical dose form — EDQM Standard Terms (optional)",
      "definition" : "The pharmaceutical dose form of the drug product. Optional in this profile\nas dose form is carried as plain text in the DGDA drug concept and is\nderivable via OCL lookup. When populated, EDQM Standard Terms codes served\nfrom the national OCL terminology server should be used.\nA DGDA dose form to EDQM mapping is planned for a future IG version.",
      "mustSupport" : true,
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "https://fhir.dghs.gov.bd/core/ValueSet/edqm-dose-forms"
      }
    },
    {
      "id" : "Medication.ingredient",
      "path" : "Medication.ingredient",
      "short" : "Active ingredient(s) of the drug product",
      "definition" : "Active pharmaceutical ingredients of the drug product, coded using ICD-11 MMS\nsubstance codes (XM-prefix). Populated automatically by clinical systems via\nOCL Has-active-ingredient mappings. Combination drugs will carry multiple\ningredient entries. Unmatched ingredients may use text only without a coded value.",
      "mustSupport" : true
    },
    {
      "id" : "Medication.ingredient.item[x]",
      "path" : "Medication.ingredient.item[x]",
      "short" : "ICD-11 substance code for the ingredient",
      "definition" : "ICD-11 MMS substance code (XM-prefix) identifying the active ingredient.\nSource value set: https://fhir.dghs.gov.bd/core/ValueSet/icd11-substances-valueset\nserved from the national OCL terminology server.\nFor ingredients not yet mapped to ICD-11 substances, use text only.",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mustSupport" : true,
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "https://fhir.dghs.gov.bd/core/ValueSet/icd11-substances-valueset"
      }
    },
    {
      "id" : "Medication.ingredient.strength",
      "path" : "Medication.ingredient.strength",
      "short" : "Strength of the ingredient (optional)",
      "definition" : "Strength of the active ingredient. Optional in this profile as strength data\nis maintained in the DGDA registry and accessible via OCL. May be populated\nby dispensing systems for precision medication management."
    }]
  }
}

```
