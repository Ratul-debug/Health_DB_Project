# Bangladesh Observation Profile - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh Observation Profile**

## Resource Profile: Bangladesh Observation Profile 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/StructureDefinition/bd-observation | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDObservationProfile |

 
Base observation profile for Bangladesh. This is an abstract-style base profile from which all BD-Core observation profiles are derived. It is not intended to be used directly in clinical resources — use a derived profile instead. 
Derived profiles (v0.4.0): 
* bd-lab-panel-observation : Laboratory panel/order (hasMember pattern)
* bd-lab-result-observation : Laboratory leaf result (child of hasMember)
 
Planned derived profiles (v0.5.0+): 
* bd-vital-signs-observation
* bd-exam-observation
 

**Usages:**

* Derived from this Profile: [Bangladesh Laboratory Panel Observation](StructureDefinition-bd-lab-panel-observation.md) and [Bangladesh Laboratory Result Observation](StructureDefinition-bd-lab-result-observation.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/bd.fhir.core|current/StructureDefinition/bd-observation)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-bd-observation.csv), [Excel](StructureDefinition-bd-observation.xlsx), [Schematron](StructureDefinition-bd-observation.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "bd-observation",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-observation",
  "version" : "0.4.6",
  "name" : "BDObservationProfile",
  "title" : "Bangladesh Observation Profile",
  "status" : "draft",
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Base observation profile for Bangladesh. This is an abstract-style base profile\nfrom which all BD-Core observation profiles are derived. It is not intended to\nbe used directly in clinical resources — use a derived profile instead.\n\nDerived profiles (v0.4.0):\n  - bd-lab-panel-observation  : Laboratory panel/order (hasMember pattern)\n  - bd-lab-result-observation : Laboratory leaf result (child of hasMember)\n\nPlanned derived profiles (v0.5.0+):\n  - bd-vital-signs-observation\n  - bd-exam-observation",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Observation",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation"
    },
    {
      "id" : "Observation.identifier",
      "path" : "Observation.identifier",
      "mustSupport" : true
    },
    {
      "id" : "Observation.identifier.value",
      "path" : "Observation.identifier.value",
      "min" : 1
    },
    {
      "id" : "Observation.category",
      "path" : "Observation.category",
      "definition" : "Type of observation category",
      "comment" : "E.g. laboratory, vital-signs, exam. Child profiles fix this to a specific value.",
      "min" : 1,
      "mustSupport" : true,
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "http://hl7.org/fhir/ValueSet/observation-category"
      }
    },
    {
      "id" : "Observation.code",
      "path" : "Observation.code",
      "definition" : "Type of observation / test / measurement",
      "comment" : "E.g. Hb, RBS, CBC. Child profiles bind to specific ValueSets.",
      "mustSupport" : true,
      "binding" : {
        "strength" : "example",
        "valueSet" : "http://hl7.org/fhir/ValueSet/observation-codes"
      }
    },
    {
      "id" : "Observation.subject",
      "path" : "Observation.subject",
      "definition" : "Reference to the Patient this observation is about",
      "comment" : "EX: http://mci.mcishr.dghs.gov.bd/api/v1/patients/98002412586",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.subject.reference",
      "path" : "Observation.subject.reference",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Observation.subject.display",
      "path" : "Observation.subject.display",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Observation.encounter",
      "path" : "Observation.encounter",
      "definition" : "Reference to the Encounter during which this observation was made",
      "comment" : "EX: uuid:34c38499-58ab-41e0-8e94-c3931491ad0e",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Observation.encounter.reference",
      "path" : "Observation.encounter.reference",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Observation.issued",
      "path" : "Observation.issued",
      "definition" : "Date/time the result was issued"
    },
    {
      "id" : "Observation.performer",
      "path" : "Observation.performer",
      "min" : 1
    },
    {
      "id" : "Observation.performer.reference",
      "path" : "Observation.performer.reference",
      "min" : 1
    },
    {
      "id" : "Observation.value[x]",
      "path" : "Observation.value[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "definition" : "Result value (Quantity, string, code, boolean, etc.)"
    },
    {
      "id" : "Observation.value[x]:valueQuantity",
      "path" : "Observation.value[x]",
      "sliceName" : "valueQuantity",
      "comment" : "If numeric, must include UCUM unit",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity"
      }]
    },
    {
      "id" : "Observation.value[x]:valueQuantity.system",
      "path" : "Observation.value[x].system",
      "patternUri" : "http://unitsofmeasure.org"
    },
    {
      "id" : "Observation.value[x]:valueString",
      "path" : "Observation.value[x]",
      "sliceName" : "valueString",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "Observation.value[x]:valueCodeableConcept",
      "path" : "Observation.value[x]",
      "sliceName" : "valueCodeableConcept",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "Observation.value[x]:valueBoolean",
      "path" : "Observation.value[x]",
      "sliceName" : "valueBoolean",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "Observation.value[x]:valueInteger",
      "path" : "Observation.value[x]",
      "sliceName" : "valueInteger",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "Observation.value[x]:valueRange",
      "path" : "Observation.value[x]",
      "sliceName" : "valueRange",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Range"
      }]
    },
    {
      "id" : "Observation.value[x]:valueRatio",
      "path" : "Observation.value[x]",
      "sliceName" : "valueRatio",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Ratio"
      }]
    },
    {
      "id" : "Observation.value[x]:valueSampledData",
      "path" : "Observation.value[x]",
      "sliceName" : "valueSampledData",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "SampledData"
      }]
    },
    {
      "id" : "Observation.value[x]:valueTime",
      "path" : "Observation.value[x]",
      "sliceName" : "valueTime",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "time"
      }]
    },
    {
      "id" : "Observation.value[x]:valueDateTime",
      "path" : "Observation.value[x]",
      "sliceName" : "valueDateTime",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "Observation.value[x]:valuePeriod",
      "path" : "Observation.value[x]",
      "sliceName" : "valuePeriod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Period"
      }]
    },
    {
      "id" : "Observation.interpretation",
      "path" : "Observation.interpretation",
      "definition" : "Assessment of the observation result",
      "comment" : "E.g. High, Low, Normal",
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://hl7.org/fhir/ValueSet/observation-interpretation"
      }
    },
    {
      "id" : "Observation.method",
      "path" : "Observation.method",
      "definition" : "Type of observation method",
      "comment" : "E.g. Technique, Total measurement",
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://hl7.org/fhir/ValueSet/observation-methods"
      }
    },
    {
      "id" : "Observation.specimen",
      "path" : "Observation.specimen",
      "definition" : "Specimen used for this observation",
      "mustSupport" : true
    },
    {
      "id" : "Observation.referenceRange",
      "path" : "Observation.referenceRange",
      "definition" : "Normal reference range for the observation"
    },
    {
      "id" : "Observation.hasMember",
      "path" : "Observation.hasMember",
      "definition" : "References to component result Observations that belong to this panel",
      "comment" : "Used in panel-type Observations. Leaf result Observations must not use hasMember.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.derivedFrom",
      "path" : "Observation.derivedFrom",
      "definition" : "References to the panel Observation from which this result is derived",
      "comment" : "Used in leaf result Observations to reference their parent panel.",
      "mustSupport" : true
    }]
  }
}

```
