# Example MedicationRequest - BDMedicationRequestExample - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example MedicationRequest - BDMedicationRequestExample**

## Example MedicationRequest: Example MedicationRequest - BDMedicationRequestExample

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

-------

**English**

-------

Profile: [Medication Request Profile for Bangladesh](StructureDefinition-bd-medication-request.md)

**identifier**: `https://fhir.dghs.gov.bd/identifier/prescription`/RX-2024-BD-000001

**status**: Active

**intent**: Order

**medication**: [Medication Marvelous Fe](Medication-BDMedicationExample.md)

**subject**: [Example Patient](Patient-BDPatientExample.md)

**encounter**: [Example Outpatient Encounter](Encounter-BDEncounterExample.md)

**authoredOn**: 2024-11-01 10:30:00+0600

**requester**: [Example Practitioner](Practitioner-BDPractitionerExample.md)

> **dosageInstruction****text**: Take 1 tablet daily after meals**timing**: Once per 1 day**route**: Swallow, oral

### DoseAndRates

| | |
| :--- | :--- |
| - | **Dose[x]** |
| * | 1 tablet (Details: UCUM code{tbl} = '{tbl}') |


-------

**German**

-------

Profile: [Medication Request Profile for Bangladesh](StructureDefinition-bd-medication-request.md)

**identifier**: `https://fhir.dghs.gov.bd/identifier/prescription`/RX-2024-BD-000001

**status**: Active

**intent**: Order

**medication**: [Medication Marvelous Fe](Medication-BDMedicationExample.md)

**subject**: [Example Patient](Patient-BDPatientExample.md)

**encounter**: [Example Outpatient Encounter](Encounter-BDEncounterExample.md)

**authoredOn**: 2024-11-01 10:30:00+0600

**requester**: [Example Practitioner](Practitioner-BDPractitionerExample.md)

> **dosageInstruction****text**: Take 1 tablet daily after meals**timing**: Once per 1 day**route**: Swallow, oral

### DoseAndRates

| | |
| :--- | :--- |
| - | **Dose[x]** |
| * | 1 tablet (Details: UCUM code{tbl} = '{tbl}') |


-------

**French**

-------

Profil: [Medication Request Profile for Bangladesh](StructureDefinition-bd-medication-request.md)

**identifier**: `https://fhir.dghs.gov.bd/identifier/prescription`/RX-2024-BD-000001

**status**: Active

**intent**: Order

**medication**: [Medication Marvelous Fe](Medication-BDMedicationExample.md)

**subject**: [Example Patient](Patient-BDPatientExample.md)

**encounter**: [Example Outpatient Encounter](Encounter-BDEncounterExample.md)

**authoredOn**: 2024-11-01 10:30:00+0600

**requester**: [Example Practitioner](Practitioner-BDPractitionerExample.md)

> **dosageInstruction****text**: Take 1 tablet daily after meals**timing**: Une fois par 1 day**route**: Swallow, oral

### DoseAndRates

| | |
| :--- | :--- |
| - | **Dose[x]** |
| * | 1 tablet (Détails : code UCUM{tbl} = '{tbl}') |




## Resource Content

```json
{
  "resourceType" : "MedicationRequest",
  "id" : "BDMedicationRequestExample",
  "meta" : {
    "profile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-medication-request"]
  },
  "identifier" : [{
    "system" : "https://fhir.dghs.gov.bd/identifier/prescription",
    "value" : "RX-2024-BD-000001"
  }],
  "status" : "active",
  "intent" : "order",
  "medicationReference" : {
    "reference" : "Medication/BDMedicationExample"
  },
  "subject" : {
    "reference" : "Patient/BDPatientExample",
    "display" : "Example Patient"
  },
  "encounter" : {
    "reference" : "Encounter/BDEncounterExample",
    "display" : "Example Outpatient Encounter"
  },
  "authoredOn" : "2024-11-01T10:30:00+06:00",
  "requester" : {
    "reference" : "Practitioner/BDPractitionerExample",
    "display" : "Example Practitioner"
  },
  "dosageInstruction" : [{
    "text" : "Take 1 tablet daily after meals",
    "timing" : {
      "repeat" : {
        "frequency" : 1,
        "period" : 1,
        "periodUnit" : "d"
      }
    },
    "route" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration",
        "code" : "PO",
        "display" : "Swallow, oral"
      }]
    },
    "doseAndRate" : [{
      "doseQuantity" : {
        "value" : 1,
        "unit" : "tablet",
        "system" : "http://unitsofmeasure.org",
        "code" : "{tbl}"
      }
    }]
  }]
}

```
