# Nationality List - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Nationality List**

## CodeSystem: Nationality List 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/CodeSystem/bd-country-list | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDCountryListCS |

 This Code system is referenced in the content logical definition of the following value sets: 

* [BDCountryListVS](ValueSet-bd-country-list-valueset.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "bd-country-list",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-country-list",
  "version" : "0.4.6",
  "name" : "BDCountryListCS",
  "title" : "Nationality List",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 188,
  "concept" : [{
    "code" : "4",
    "display" : "Afghan"
  },
  {
    "code" : "8",
    "display" : "Albanian"
  },
  {
    "code" : "12",
    "display" : "Algerian"
  },
  {
    "code" : "840",
    "display" : "American"
  },
  {
    "code" : "20",
    "display" : "Andorran"
  },
  {
    "code" : "24",
    "display" : "Angolan"
  },
  {
    "code" : "28",
    "display" : "Antiguans"
  },
  {
    "code" : "32",
    "display" : "Argentine"
  },
  {
    "code" : "51",
    "display" : "Armenian"
  },
  {
    "code" : "36",
    "display" : "Australian"
  },
  {
    "code" : "40",
    "display" : "Austrian"
  },
  {
    "code" : "31",
    "display" : "Azerbaijani"
  },
  {
    "code" : "44",
    "display" : "Bahamian"
  },
  {
    "code" : "48",
    "display" : "Bahraini"
  },
  {
    "code" : "50",
    "display" : "Bangladeshi"
  },
  {
    "code" : "52",
    "display" : "Barbadian"
  },
  {
    "code" : "112",
    "display" : "Belarusian"
  },
  {
    "code" : "56",
    "display" : "Belgian"
  },
  {
    "code" : "84",
    "display" : "Belizean"
  },
  {
    "code" : "204",
    "display" : "Beninese"
  },
  {
    "code" : "64",
    "display" : "Bhutanese"
  },
  {
    "code" : "68",
    "display" : "Bolivian"
  },
  {
    "code" : "70",
    "display" : "Bosnian"
  },
  {
    "code" : "76",
    "display" : "Brazilian"
  },
  {
    "code" : "826",
    "display" : "British (collective)"
  },
  {
    "code" : "96",
    "display" : "Bruneian"
  },
  {
    "code" : "100",
    "display" : "Bulgarian"
  },
  {
    "code" : "854",
    "display" : "Burkinabe"
  },
  {
    "code" : "108",
    "display" : "Burundian"
  },
  {
    "code" : "116",
    "display" : "Cambodian"
  },
  {
    "code" : "120",
    "display" : "Cameroonian"
  },
  {
    "code" : "124",
    "display" : "Canadian"
  },
  {
    "code" : "140",
    "display" : "Central African"
  },
  {
    "code" : "152",
    "display" : "Chilean"
  },
  {
    "code" : "156",
    "display" : "Chinese"
  },
  {
    "code" : "170",
    "display" : "Colombian"
  },
  {
    "code" : "174",
    "display" : "Comoran"
  },
  {
    "code" : "180",
    "display" : "Congolese"
  },
  {
    "code" : "178",
    "display" : "Congolese"
  },
  {
    "code" : "188",
    "display" : "Costa Rican"
  },
  {
    "code" : "191",
    "display" : "Croatian"
  },
  {
    "code" : "192",
    "display" : "Cuban"
  },
  {
    "code" : "196",
    "display" : "Cypriot"
  },
  {
    "code" : "203",
    "display" : "Czech"
  },
  {
    "code" : "208",
    "display" : "Danish"
  },
  {
    "code" : "262",
    "display" : "Djibouti"
  },
  {
    "code" : "212",
    "display" : "Dominican"
  },
  {
    "code" : "214",
    "display" : "Dominican"
  },
  {
    "code" : "528",
    "display" : "Dutch"
  },
  {
    "code" : "218",
    "display" : "Ecuadorean"
  },
  {
    "code" : "818",
    "display" : "Egyptian"
  },
  {
    "code" : "784",
    "display" : "Emirian"
  },
  {
    "code" : "226",
    "display" : "Equatorial Guinean"
  },
  {
    "code" : "232",
    "display" : "Eritrean"
  },
  {
    "code" : "233",
    "display" : "Estonian"
  },
  {
    "code" : "231",
    "display" : "Ethiopian"
  },
  {
    "code" : "242",
    "display" : "Fijian"
  },
  {
    "code" : "608",
    "display" : "Filipino"
  },
  {
    "code" : "246",
    "display" : "Finnish"
  },
  {
    "code" : "250",
    "display" : "French"
  },
  {
    "code" : "266",
    "display" : "Gabonese"
  },
  {
    "code" : "270",
    "display" : "Gambian"
  },
  {
    "code" : "268",
    "display" : "Georgian"
  },
  {
    "code" : "276",
    "display" : "German"
  },
  {
    "code" : "288",
    "display" : "Ghanaian"
  },
  {
    "code" : "300",
    "display" : "Greek"
  },
  {
    "code" : "308",
    "display" : "Grenadian"
  },
  {
    "code" : "320",
    "display" : "Guatemalan"
  },
  {
    "code" : "624",
    "display" : "Guinea-Bissauan"
  },
  {
    "code" : "324",
    "display" : "Guinean"
  },
  {
    "code" : "328",
    "display" : "Guyanese"
  },
  {
    "code" : "332",
    "display" : "Haitian"
  },
  {
    "code" : "340",
    "display" : "Honduran"
  },
  {
    "code" : "348",
    "display" : "Hungarian"
  },
  {
    "code" : "296",
    "display" : "I-Kiribati"
  },
  {
    "code" : "352",
    "display" : "Icelander"
  },
  {
    "code" : "356",
    "display" : "Indian"
  },
  {
    "code" : "360",
    "display" : "Indonesian"
  },
  {
    "code" : "364",
    "display" : "Iranian"
  },
  {
    "code" : "368",
    "display" : "Iraqi"
  },
  {
    "code" : "372",
    "display" : "Irish"
  },
  {
    "code" : "380",
    "display" : "Italian"
  },
  {
    "code" : "384",
    "display" : "Ivorian"
  },
  {
    "code" : "388",
    "display" : "Jamaican"
  },
  {
    "code" : "392",
    "display" : "Japanese"
  },
  {
    "code" : "400",
    "display" : "Jordanian"
  },
  {
    "code" : "398",
    "display" : "Kazakhstani"
  },
  {
    "code" : "404",
    "display" : "Kenyan"
  },
  {
    "code" : "659",
    "display" : "Kittian and Nevisian"
  },
  {
    "code" : "414",
    "display" : "Kuwaiti"
  },
  {
    "code" : "417",
    "display" : "Kyrgyz"
  },
  {
    "code" : "418",
    "display" : "Lao"
  },
  {
    "code" : "428",
    "display" : "Latvian"
  },
  {
    "code" : "422",
    "display" : "Lebanese"
  },
  {
    "code" : "430",
    "display" : "Liberian"
  },
  {
    "code" : "434",
    "display" : "Libyan"
  },
  {
    "code" : "438",
    "display" : "Liechtensteiner"
  },
  {
    "code" : "440",
    "display" : "Lithuanian"
  },
  {
    "code" : "442",
    "display" : "Luxembourger"
  },
  {
    "code" : "807",
    "display" : "Macedonian"
  },
  {
    "code" : "450",
    "display" : "Malagasy"
  },
  {
    "code" : "454",
    "display" : "Malawian"
  },
  {
    "code" : "458",
    "display" : "Malaysian"
  },
  {
    "code" : "462",
    "display" : "Maldivan"
  },
  {
    "code" : "466",
    "display" : "Malian"
  },
  {
    "code" : "470",
    "display" : "Maltese"
  },
  {
    "code" : "584",
    "display" : "Marshallese"
  },
  {
    "code" : "478",
    "display" : "Mauritanian"
  },
  {
    "code" : "480",
    "display" : "Mauritian"
  },
  {
    "code" : "484",
    "display" : "Mexican"
  },
  {
    "code" : "583",
    "display" : "Micronesian"
  },
  {
    "code" : "498",
    "display" : "Moldovan"
  },
  {
    "code" : "492",
    "display" : "Monegasque"
  },
  {
    "code" : "496",
    "display" : "Mongolian"
  },
  {
    "code" : "504",
    "display" : "Moroccan"
  },
  {
    "code" : "426",
    "display" : "Mosotho"
  },
  {
    "code" : "72",
    "display" : "Motswana"
  },
  {
    "code" : "508",
    "display" : "Mozambican"
  },
  {
    "code" : "104",
    "display" : "Myanmarese"
  },
  {
    "code" : "516",
    "display" : "Namibian"
  },
  {
    "code" : "520",
    "display" : "Nauruan"
  },
  {
    "code" : "524",
    "display" : "Nepalese"
  },
  {
    "code" : "554",
    "display" : "New Zealander"
  },
  {
    "code" : "548",
    "display" : "Ni-Vanuatu"
  },
  {
    "code" : "558",
    "display" : "Nicaraguan"
  },
  {
    "code" : "566",
    "display" : "Nigerian"
  },
  {
    "code" : "562",
    "display" : "Nigerien"
  },
  {
    "code" : "408",
    "display" : "North Korean"
  },
  {
    "code" : "578",
    "display" : "Norwegian"
  },
  {
    "code" : "512",
    "display" : "Omani"
  },
  {
    "code" : "586",
    "display" : "Pakistani"
  },
  {
    "code" : "585",
    "display" : "Palauan"
  },
  {
    "code" : "591",
    "display" : "Panamanian"
  },
  {
    "code" : "598",
    "display" : "Papua New Guinean"
  },
  {
    "code" : "600",
    "display" : "Paraguayan"
  },
  {
    "code" : "604",
    "display" : "Peruvian"
  },
  {
    "code" : "616",
    "display" : "Polish"
  },
  {
    "code" : "620",
    "display" : "Portuguese"
  },
  {
    "code" : "634",
    "display" : "Qatari"
  },
  {
    "code" : "642",
    "display" : "Romanian"
  },
  {
    "code" : "643",
    "display" : "Russian"
  },
  {
    "code" : "646",
    "display" : "Rwandan"
  },
  {
    "code" : "662",
    "display" : "Saint Lucian"
  },
  {
    "code" : "222",
    "display" : "Salvadoran"
  },
  {
    "code" : "674",
    "display" : "Sammarinese"
  },
  {
    "code" : "882",
    "display" : "Samoan"
  },
  {
    "code" : "678",
    "display" : "Sao Tomean"
  },
  {
    "code" : "682",
    "display" : "Saudi"
  },
  {
    "code" : "686",
    "display" : "Senegalese"
  },
  {
    "code" : "891",
    "display" : "Serbian"
  },
  {
    "code" : "690",
    "display" : "Seychellois"
  },
  {
    "code" : "694",
    "display" : "Sierra Leonean"
  },
  {
    "code" : "702",
    "display" : "Singaporean"
  },
  {
    "code" : "703",
    "display" : "Slovak"
  },
  {
    "code" : "705",
    "display" : "Slovene"
  },
  {
    "code" : "90",
    "display" : "Solomon Islander"
  },
  {
    "code" : "706",
    "display" : "Somali"
  },
  {
    "code" : "710",
    "display" : "South African"
  },
  {
    "code" : "410",
    "display" : "South Korean"
  },
  {
    "code" : "724",
    "display" : "Spanish"
  },
  {
    "code" : "144",
    "display" : "Sri Lankan"
  },
  {
    "code" : "736",
    "display" : "Sudanese"
  },
  {
    "code" : "740",
    "display" : "Surinamer"
  },
  {
    "code" : "748",
    "display" : "Swazi"
  },
  {
    "code" : "752",
    "display" : "Swedish"
  },
  {
    "code" : "756",
    "display" : "Swiss"
  },
  {
    "code" : "760",
    "display" : "Syrian"
  },
  {
    "code" : "158",
    "display" : "Taiwanese"
  },
  {
    "code" : "762",
    "display" : "Tajik"
  },
  {
    "code" : "834",
    "display" : "Tanzanian"
  },
  {
    "code" : "764",
    "display" : "Thai"
  },
  {
    "code" : "768",
    "display" : "Togolese"
  },
  {
    "code" : "776",
    "display" : "Tongan"
  },
  {
    "code" : "780",
    "display" : "Trinidadian"
  },
  {
    "code" : "788",
    "display" : "Tunisian"
  },
  {
    "code" : "792",
    "display" : "Turkish"
  },
  {
    "code" : "795",
    "display" : "Turkmen(s)"
  },
  {
    "code" : "798",
    "display" : "Tuvaluan"
  },
  {
    "code" : "800",
    "display" : "Ugandan"
  },
  {
    "code" : "804",
    "display" : "Ukrainian"
  },
  {
    "code" : "858",
    "display" : "Uruguayan"
  },
  {
    "code" : "860",
    "display" : "Uzbek"
  },
  {
    "code" : "862",
    "display" : "Venezuelan"
  },
  {
    "code" : "132",
    "display" : "Verdian"
  },
  {
    "code" : "704",
    "display" : "Vietnamese"
  },
  {
    "code" : "887",
    "display" : "Yemeni"
  },
  {
    "code" : "894",
    "display" : "Zambian"
  },
  {
    "code" : "716",
    "display" : "Zimbabwean"
  }]
}

```
