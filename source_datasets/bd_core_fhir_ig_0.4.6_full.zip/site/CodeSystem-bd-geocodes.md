# Bangladesh GeoCodes CodeSystem - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh GeoCodes CodeSystem**

## CodeSystem: Bangladesh GeoCodes CodeSystem 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/CodeSystem/bd-geocodes | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDGeoCodesCS |

 
Bangladesh GeoCodes 

 This Code system is referenced in the content logical definition of the following value sets: 

* [BDCityCorporationsVS](ValueSet-bd-city-corporation-code-valueset.md)
* [BDDistrictsVS](ValueSet-bd-district-code-valueset.md)
* [BDDivisionsVS](ValueSet-bd-division-code-valueset.md)
* [BDMunicipalitiesVS](ValueSet-bd-municipalities-code-valueset.md)
* [BDUpazillasVS](ValueSet-bd-upazilla-code-valueset.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "bd-geocodes",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-geocodes",
  "version" : "0.4.6",
  "name" : "BDGeoCodesCS",
  "title" : "Bangladesh GeoCodes CodeSystem",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Bangladesh GeoCodes",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 1591,
  "concept" : [{
    "code" : "30",
    "display" : "Dhaka"
  },
  {
    "code" : "20",
    "display" : "Chattogram"
  },
  {
    "code" : "50",
    "display" : "Rajshahi"
  },
  {
    "code" : "55",
    "display" : "Rangpur"
  },
  {
    "code" : "40",
    "display" : "Khulna"
  },
  {
    "code" : "10",
    "display" : "Barishal"
  },
  {
    "code" : "60",
    "display" : "Sylhet"
  },
  {
    "code" : "45",
    "display" : "Mymensingh"
  },
  {
    "code" : "3026",
    "display" : "Dhaka"
  },
  {
    "code" : "3029",
    "display" : "Faridpur"
  },
  {
    "code" : "3033",
    "display" : "Gazipur"
  },
  {
    "code" : "3035",
    "display" : "Gopalganj"
  },
  {
    "code" : "4539",
    "display" : "Jamalpur"
  },
  {
    "code" : "3048",
    "display" : "Kishoreganj"
  },
  {
    "code" : "3054",
    "display" : "Madaripur"
  },
  {
    "code" : "3056",
    "display" : "Manikganj"
  },
  {
    "code" : "3059",
    "display" : "Munshiganj"
  },
  {
    "code" : "4561",
    "display" : "Mymensingh"
  },
  {
    "code" : "3067",
    "display" : "Narayanganj"
  },
  {
    "code" : "3068",
    "display" : "Narsingdi"
  },
  {
    "code" : "4572",
    "display" : "Netrakona"
  },
  {
    "code" : "3082",
    "display" : "Rajbari"
  },
  {
    "code" : "3086",
    "display" : "Shariatpur"
  },
  {
    "code" : "4589",
    "display" : "Sherpur"
  },
  {
    "code" : "3093",
    "display" : "Tangail"
  },
  {
    "code" : "2003",
    "display" : "Bandarban"
  },
  {
    "code" : "2012",
    "display" : "Brahmanbaria"
  },
  {
    "code" : "2013",
    "display" : "Chandpur"
  },
  {
    "code" : "2015",
    "display" : "Chattogram"
  },
  {
    "code" : "2019",
    "display" : "Cumilla"
  },
  {
    "code" : "2022",
    "display" : "Cox's Bazar"
  },
  {
    "code" : "2030",
    "display" : "Feni"
  },
  {
    "code" : "2046",
    "display" : "Khagrachari"
  },
  {
    "code" : "2051",
    "display" : "Lakshmipur"
  },
  {
    "code" : "2075",
    "display" : "Noakhali"
  },
  {
    "code" : "2084",
    "display" : "Rangamati"
  },
  {
    "code" : "5010",
    "display" : "Bogura"
  },
  {
    "code" : "5070",
    "display" : "Chapainawabganj"
  },
  {
    "code" : "5527",
    "display" : "Dinajpur"
  },
  {
    "code" : "5532",
    "display" : "Gaibandha"
  },
  {
    "code" : "5038",
    "display" : "Joypurhat"
  },
  {
    "code" : "5549",
    "display" : "Kurigram"
  },
  {
    "code" : "5552",
    "display" : "Lalmonirhat"
  },
  {
    "code" : "5064",
    "display" : "Naogaon"
  },
  {
    "code" : "5069",
    "display" : "Natore"
  },
  {
    "code" : "5573",
    "display" : "Nilphamari"
  },
  {
    "code" : "5076",
    "display" : "Pabna"
  },
  {
    "code" : "5577",
    "display" : "Panchagarh"
  },
  {
    "code" : "5081",
    "display" : "Rajshahi"
  },
  {
    "code" : "5585",
    "display" : "Rangpur"
  },
  {
    "code" : "5088",
    "display" : "Sirajganj"
  },
  {
    "code" : "5594",
    "display" : "Thakurgaon"
  },
  {
    "code" : "4001",
    "display" : "Bagerhat"
  },
  {
    "code" : "4018",
    "display" : "Chuadanga"
  },
  {
    "code" : "4041",
    "display" : "Jashore"
  },
  {
    "code" : "4044",
    "display" : "Jhenaidah"
  },
  {
    "code" : "4047",
    "display" : "Khulna"
  },
  {
    "code" : "4050",
    "display" : "Kushtia"
  },
  {
    "code" : "4055",
    "display" : "Magura"
  },
  {
    "code" : "4057",
    "display" : "Meherpur"
  },
  {
    "code" : "4065",
    "display" : "Narail"
  },
  {
    "code" : "4087",
    "display" : "Satkhira"
  },
  {
    "code" : "1004",
    "display" : "Barguna"
  },
  {
    "code" : "1006",
    "display" : "Barishal"
  },
  {
    "code" : "1009",
    "display" : "Bhola"
  },
  {
    "code" : "1042",
    "display" : "Jhalokathi"
  },
  {
    "code" : "1078",
    "display" : "Patuakhali"
  },
  {
    "code" : "1079",
    "display" : "Pirojpur"
  },
  {
    "code" : "6036",
    "display" : "Habiganj"
  },
  {
    "code" : "6058",
    "display" : "Maulvibazar"
  },
  {
    "code" : "6090",
    "display" : "Sunamganj"
  },
  {
    "code" : "6091",
    "display" : "Sylhet"
  },
  {
    "code" : "302620",
    "display" : "Dhaka South City Corporation"
  },
  {
    "code" : "302625",
    "display" : "Dhaka North City Corperation"
  },
  {
    "code" : "303333",
    "display" : "Gazipur City Corporation"
  },
  {
    "code" : "306744",
    "display" : "Narayanganj City Corporation"
  },
  {
    "code" : "302600",
    "display" : "Dhaka N/A"
  },
  {
    "code" : "303300",
    "display" : "Gazipur N/A"
  },
  {
    "code" : "306700",
    "display" : "Narayanganj N/A"
  },
  {
    "code" : "201516",
    "display" : "Chattogram City Corporation"
  },
  {
    "code" : "201500",
    "display" : "Chattogram N/A"
  },
  {
    "code" : "200300",
    "display" : "Bandarban N/A"
  },
  {
    "code" : "201950",
    "display" : "Cumilla City Corporation"
  },
  {
    "code" : "201900",
    "display" : "Cumilla N/A"
  },
  {
    "code" : "302900",
    "display" : "Faridpur N/A"
  },
  {
    "code" : "303500",
    "display" : "Gopalganj N/A"
  },
  {
    "code" : "304800",
    "display" : "Kishoreganj N/A"
  },
  {
    "code" : "305400",
    "display" : "Madaripur N/A"
  },
  {
    "code" : "305600",
    "display" : "Manikganj N/A"
  },
  {
    "code" : "305900",
    "display" : "Munshiganj N/A"
  },
  {
    "code" : "306800",
    "display" : "Narsingdi N/A"
  },
  {
    "code" : "308200",
    "display" : "Rajbari N/A"
  },
  {
    "code" : "308600",
    "display" : "Shariatpur N/A"
  },
  {
    "code" : "309300",
    "display" : "Tangail N/A"
  },
  {
    "code" : "201200",
    "display" : "Brahmanbaria N/A"
  },
  {
    "code" : "201300",
    "display" : "Chandpur N/A"
  },
  {
    "code" : "202200",
    "display" : "Cox's Bazar N/A"
  },
  {
    "code" : "203000",
    "display" : "Feni N/A"
  },
  {
    "code" : "204600",
    "display" : "Khagrachhari N/A"
  },
  {
    "code" : "205100",
    "display" : "Lakshmipur N/A"
  },
  {
    "code" : "207500",
    "display" : "Noakhali N/A"
  },
  {
    "code" : "208400",
    "display" : "Rangamati N/A"
  },
  {
    "code" : "501000",
    "display" : "Bogura N/A"
  },
  {
    "code" : "507000",
    "display" : "Chapainawabganj N/A"
  },
  {
    "code" : "503800",
    "display" : "Joypurhat N/A"
  },
  {
    "code" : "506400",
    "display" : "Naogaon N/A"
  },
  {
    "code" : "506900",
    "display" : "Natore N/A"
  },
  {
    "code" : "507600",
    "display" : "Pabna N/A"
  },
  {
    "code" : "508166",
    "display" : "Rajshahi City Corporation"
  },
  {
    "code" : "508100",
    "display" : "Rajshahi N/A"
  },
  {
    "code" : "508800",
    "display" : "Sirajganj N/A"
  },
  {
    "code" : "552700",
    "display" : "Dinajpur N/A"
  },
  {
    "code" : "553200",
    "display" : "Gaibandha N/A"
  },
  {
    "code" : "554900",
    "display" : "Kurigram N/A"
  },
  {
    "code" : "555200",
    "display" : "Lalmonirhat N/A"
  },
  {
    "code" : "557300",
    "display" : "Nilphamari N/A"
  },
  {
    "code" : "557700",
    "display" : "Panchagarh N/A"
  },
  {
    "code" : "558575",
    "display" : "Rangpur City Corporation"
  },
  {
    "code" : "558500",
    "display" : "Rangpur N/A"
  },
  {
    "code" : "559400",
    "display" : "Thakurgaon N/A"
  },
  {
    "code" : "400100",
    "display" : "Bagerhat N/A"
  },
  {
    "code" : "401800",
    "display" : "Chuadanga N/A"
  },
  {
    "code" : "404100",
    "display" : "Jashore N/A"
  },
  {
    "code" : "404400",
    "display" : "Jhenaidah N/A"
  },
  {
    "code" : "404733",
    "display" : "Khulna City Corporation"
  },
  {
    "code" : "404700",
    "display" : "Khulna N/A"
  },
  {
    "code" : "405000",
    "display" : "Kushtia N/A"
  },
  {
    "code" : "405500",
    "display" : "Magura N/A"
  },
  {
    "code" : "405700",
    "display" : "Meherpur N/A"
  },
  {
    "code" : "406500",
    "display" : "Narail N/A"
  },
  {
    "code" : "408700",
    "display" : "Satkhira N/A"
  },
  {
    "code" : "100400",
    "display" : "Barguna N/A"
  },
  {
    "code" : "100650",
    "display" : "Barishal City Corporation"
  },
  {
    "code" : "100600",
    "display" : "Barishal N/A"
  },
  {
    "code" : "100900",
    "display" : "Bhola N/A"
  },
  {
    "code" : "104200",
    "display" : "Jhalokati N/A"
  },
  {
    "code" : "107800",
    "display" : "Patuakhali N/A"
  },
  {
    "code" : "107900",
    "display" : "Pirojpur N/A"
  },
  {
    "code" : "603600",
    "display" : "Habiganj N/A"
  },
  {
    "code" : "605800",
    "display" : "Moulvibazar N/A"
  },
  {
    "code" : "609000",
    "display" : "Sunamganj N/A"
  },
  {
    "code" : "609150",
    "display" : "Sylhet City Corporation"
  },
  {
    "code" : "609100",
    "display" : "Sylhet N/A"
  },
  {
    "code" : "453900",
    "display" : "Jamalpur N/A"
  },
  {
    "code" : "456140",
    "display" : "Mymensingh City Corporation"
  },
  {
    "code" : "456100",
    "display" : "Mymensingh N/A"
  },
  {
    "code" : "457200",
    "display" : "Netrakona N/A"
  },
  {
    "code" : "458900",
    "display" : "Sherpur N/A"
  },
  {
    "code" : "10040009",
    "display" : "Amtali"
  },
  {
    "code" : "10040019",
    "display" : "Bamna"
  },
  {
    "code" : "10040028",
    "display" : "Barguna Sadar"
  },
  {
    "code" : "10040047",
    "display" : "Betagi"
  },
  {
    "code" : "10040085",
    "display" : "Patharghata"
  },
  {
    "code" : "10040090",
    "display" : "Taltali"
  },
  {
    "code" : "10060002",
    "display" : "Agailjhara"
  },
  {
    "code" : "10060003",
    "display" : "Babuganj"
  },
  {
    "code" : "10060007",
    "display" : "Bakerganj"
  },
  {
    "code" : "10060010",
    "display" : "Banaripara"
  },
  {
    "code" : "10060032",
    "display" : "Gaurnadi"
  },
  {
    "code" : "10060036",
    "display" : "Hizla"
  },
  {
    "code" : "10065051",
    "display" : "Barishal Sadar"
  },
  {
    "code" : "10060062",
    "display" : "Mehendiganj"
  },
  {
    "code" : "10060069",
    "display" : "Muladi"
  },
  {
    "code" : "10060094",
    "display" : "Wazirpur"
  },
  {
    "code" : "10090018",
    "display" : "Bhola Sadar"
  },
  {
    "code" : "10090021",
    "display" : "Borhanuddin"
  },
  {
    "code" : "10090025",
    "display" : "Charfession"
  },
  {
    "code" : "10090029",
    "display" : "Daulatkhan"
  },
  {
    "code" : "10090054",
    "display" : "Lalmohan"
  },
  {
    "code" : "10090065",
    "display" : "Manpura"
  },
  {
    "code" : "10090091",
    "display" : "Tazumuddin"
  },
  {
    "code" : "10420040",
    "display" : "Jhalokathi Sadar"
  },
  {
    "code" : "10420043",
    "display" : "Kanthalia"
  },
  {
    "code" : "10420073",
    "display" : "Nalchity"
  },
  {
    "code" : "10420084",
    "display" : "Rajapur"
  },
  {
    "code" : "10780038",
    "display" : "Bauphal"
  },
  {
    "code" : "10780052",
    "display" : "Dashmina"
  },
  {
    "code" : "10780055",
    "display" : "Dumki"
  },
  {
    "code" : "10780057",
    "display" : "Galachipa"
  },
  {
    "code" : "10780066",
    "display" : "Kalapara"
  },
  {
    "code" : "10780076",
    "display" : "Mirzaganj"
  },
  {
    "code" : "10780095",
    "display" : "Patuakhali Sadar"
  },
  {
    "code" : "10780097",
    "display" : "Rangabali"
  },
  {
    "code" : "10790014",
    "display" : "Bhandaria"
  },
  {
    "code" : "10790047",
    "display" : "Kawkhali"
  },
  {
    "code" : "10790058",
    "display" : "Mathbaria"
  },
  {
    "code" : "10790076",
    "display" : "Nazirpur"
  },
  {
    "code" : "10790080",
    "display" : "Pirojpur Sadar"
  },
  {
    "code" : "10790087",
    "display" : "Nesarabad"
  },
  {
    "code" : "10790090",
    "display" : "Indurkani"
  },
  {
    "code" : "20030004",
    "display" : "Alikadam"
  },
  {
    "code" : "20030014",
    "display" : "Bandarban Sadar"
  },
  {
    "code" : "20030051",
    "display" : "Lama"
  },
  {
    "code" : "20030073",
    "display" : "Naikhongchari"
  },
  {
    "code" : "20030089",
    "display" : "Rowangchari"
  },
  {
    "code" : "20030091",
    "display" : "Ruma"
  },
  {
    "code" : "20030095",
    "display" : "Thanchi"
  },
  {
    "code" : "20120002",
    "display" : "Akhaura"
  },
  {
    "code" : "20120004",
    "display" : "Banchharampur"
  },
  {
    "code" : "20120007",
    "display" : "Bijoynagar"
  },
  {
    "code" : "20120013",
    "display" : "Brahmanbaria Sadar"
  },
  {
    "code" : "20120033",
    "display" : "Ashuganj"
  },
  {
    "code" : "20120063",
    "display" : "Kasba"
  },
  {
    "code" : "20120085",
    "display" : "Nabinagar"
  },
  {
    "code" : "20120090",
    "display" : "Nasirnagar"
  },
  {
    "code" : "20120094",
    "display" : "Sarail"
  },
  {
    "code" : "20130022",
    "display" : "Chandpur Sadar"
  },
  {
    "code" : "20130045",
    "display" : "Faridganj"
  },
  {
    "code" : "20130047",
    "display" : "Haimchar"
  },
  {
    "code" : "20130049",
    "display" : "Hajiganj"
  },
  {
    "code" : "20130058",
    "display" : "Kachua"
  },
  {
    "code" : "20130076",
    "display" : "Matlab Dakshin"
  },
  {
    "code" : "20130079",
    "display" : "Matlab Uttar"
  },
  {
    "code" : "20130095",
    "display" : "Shahrasti"
  },
  {
    "code" : "20150004",
    "display" : "Anowara"
  },
  {
    "code" : "20151606",
    "display" : "Bayejid Bostami"
  },
  {
    "code" : "20150008",
    "display" : "Banshkhali"
  },
  {
    "code" : "20151610",
    "display" : "Bakalia"
  },
  {
    "code" : "20150012",
    "display" : "Boalkhali"
  },
  {
    "code" : "20150018",
    "display" : "Chandanaish"
  },
  {
    "code" : "20151619",
    "display" : "Chandgaon"
  },
  {
    "code" : "20151620",
    "display" : "Chittogram Port"
  },
  {
    "code" : "20151628",
    "display" : "Double Mooring"
  },
  {
    "code" : "20150033",
    "display" : "Fatikchari"
  },
  {
    "code" : "20151635",
    "display" : "Halishahar"
  },
  {
    "code" : "20150037",
    "display" : "Hathazari"
  },
  {
    "code" : "20151641",
    "display" : "Kotwali"
  },
  {
    "code" : "20151643",
    "display" : "Khulshi"
  },
  {
    "code" : "20150047",
    "display" : "Lohagara"
  },
  {
    "code" : "20150053",
    "display" : "Mirsharai"
  },
  {
    "code" : "20151655",
    "display" : "Pahartali"
  },
  {
    "code" : "20151657",
    "display" : "Panchlaish"
  },
  {
    "code" : "20150061",
    "display" : "Patiya"
  },
  {
    "code" : "20151665",
    "display" : "Patenga"
  },
  {
    "code" : "20150070",
    "display" : "Rangunia"
  },
  {
    "code" : "20150074",
    "display" : "Raozan"
  },
  {
    "code" : "20150078",
    "display" : "Sandwip"
  },
  {
    "code" : "20150082",
    "display" : "Satkania"
  },
  {
    "code" : "20150086",
    "display" : "Sitakunda"
  },
  {
    "code" : "20190009",
    "display" : "Barura"
  },
  {
    "code" : "20190015",
    "display" : "Brahmanpara"
  },
  {
    "code" : "20190018",
    "display" : "Burichang"
  },
  {
    "code" : "20190027",
    "display" : "Chandina"
  },
  {
    "code" : "20190031",
    "display" : "Chauddagram"
  },
  {
    "code" : "20195033",
    "display" : "Cumilla Sadar Dakshin"
  },
  {
    "code" : "20190036",
    "display" : "Daudkandi"
  },
  {
    "code" : "20190040",
    "display" : "Debidwar"
  },
  {
    "code" : "20190054",
    "display" : "Homna"
  },
  {
    "code" : "20195067",
    "display" : "Cumilla Adarsha Sadar"
  },
  {
    "code" : "20190072",
    "display" : "Laksam"
  },
  {
    "code" : "20190074",
    "display" : "Monoharganj"
  },
  {
    "code" : "20190075",
    "display" : "Meghna"
  },
  {
    "code" : "20190081",
    "display" : "Muradnagar"
  },
  {
    "code" : "20190087",
    "display" : "Nangalkot"
  },
  {
    "code" : "20190094",
    "display" : "Titas"
  },
  {
    "code" : "20220016",
    "display" : "Chakaria"
  },
  {
    "code" : "20220024",
    "display" : "Cox's Bazar Sadar"
  },
  {
    "code" : "20220045",
    "display" : "Kutubdia"
  },
  {
    "code" : "20220049",
    "display" : "Maheshkhali"
  },
  {
    "code" : "20220056",
    "display" : "Pekua"
  },
  {
    "code" : "20220066",
    "display" : "Ramu"
  },
  {
    "code" : "20220090",
    "display" : "Teknaf"
  },
  {
    "code" : "20220094",
    "display" : "Ukhia"
  },
  {
    "code" : "20300014",
    "display" : "Chhagalnaiya"
  },
  {
    "code" : "20300025",
    "display" : "Daganbhuiyan"
  },
  {
    "code" : "20300029",
    "display" : "Feni Sadar"
  },
  {
    "code" : "20300041",
    "display" : "Fulgazi"
  },
  {
    "code" : "20300051",
    "display" : "Parshuram"
  },
  {
    "code" : "20300094",
    "display" : "Sonagazi"
  },
  {
    "code" : "20460043",
    "display" : "Dighinala"
  },
  {
    "code" : "20460049",
    "display" : "Khagrachari Sadar"
  },
  {
    "code" : "20460061",
    "display" : "Lakshmichari"
  },
  {
    "code" : "20460065",
    "display" : "Mahalchari"
  },
  {
    "code" : "20460067",
    "display" : "Manikchari"
  },
  {
    "code" : "20460070",
    "display" : "Matiranga"
  },
  {
    "code" : "20460077",
    "display" : "Panchhari"
  },
  {
    "code" : "20460080",
    "display" : "Ramgarh"
  },
  {
    "code" : "20510033",
    "display" : "Kamalnagar"
  },
  {
    "code" : "20510043",
    "display" : "Lakshmipur Sadar"
  },
  {
    "code" : "20510058",
    "display" : "Raipur"
  },
  {
    "code" : "20510065",
    "display" : "Ramganj"
  },
  {
    "code" : "20510073",
    "display" : "Ramgati"
  },
  {
    "code" : "20750007",
    "display" : "Begumganj"
  },
  {
    "code" : "20750010",
    "display" : "Chatkhil"
  },
  {
    "code" : "20750021",
    "display" : "Companiganj"
  },
  {
    "code" : "20750036",
    "display" : "Hatiya"
  },
  {
    "code" : "20750047",
    "display" : "Kabirhat"
  },
  {
    "code" : "20750080",
    "display" : "Senbagh"
  },
  {
    "code" : "20750083",
    "display" : "Sonaimuri"
  },
  {
    "code" : "20750085",
    "display" : "Subarnachar"
  },
  {
    "code" : "20750087",
    "display" : "Noakhali Sadar"
  },
  {
    "code" : "20840007",
    "display" : "Baghaichari"
  },
  {
    "code" : "20840021",
    "display" : "Barkal"
  },
  {
    "code" : "20840025",
    "display" : "Kowkhali"
  },
  {
    "code" : "20840029",
    "display" : "Belaichari"
  },
  {
    "code" : "20840036",
    "display" : "Kaptai"
  },
  {
    "code" : "20840047",
    "display" : "Juraichari"
  },
  {
    "code" : "20840058",
    "display" : "Langadu"
  },
  {
    "code" : "20840075",
    "display" : "Naniarchar"
  },
  {
    "code" : "20840078",
    "display" : "Rajasthali"
  },
  {
    "code" : "20840087",
    "display" : "Rangamati Sadar"
  },
  {
    "code" : "30262502",
    "display" : "Adabor"
  },
  {
    "code" : "30262504",
    "display" : "Badda"
  },
  {
    "code" : "30262005",
    "display" : "Bangshal"
  },
  {
    "code" : "30262506",
    "display" : "Biman Bandar"
  },
  {
    "code" : "30262507",
    "display" : "Banani"
  },
  {
    "code" : "30262508",
    "display" : "Cantonment"
  },
  {
    "code" : "30262009",
    "display" : "Chak Bazar"
  },
  {
    "code" : "30262510",
    "display" : "Dakshinkhan"
  },
  {
    "code" : "30262511",
    "display" : "Darus Salam"
  },
  {
    "code" : "30262012",
    "display" : "Demra"
  },
  {
    "code" : "30260014",
    "display" : "Dhamrai"
  },
  {
    "code" : "30260018",
    "display" : "Dohar"
  },
  {
    "code" : "30262521",
    "display" : "Bhasan Tek"
  },
  {
    "code" : "30262522",
    "display" : "Bhatara"
  },
  {
    "code" : "30262024",
    "display" : "Gendaria"
  },
  {
    "code" : "30262526",
    "display" : "Gulshan"
  },
  {
    "code" : "30262029",
    "display" : "Jatrabari"
  },
  {
    "code" : "30262530",
    "display" : "Kafrul"
  },
  {
    "code" : "30262032",
    "display" : "Kadamtali"
  },
  {
    "code" : "30262033",
    "display" : "Kalabagan"
  },
  {
    "code" : "30262034",
    "display" : "Kamrangir Char"
  },
  {
    "code" : "30262036",
    "display" : "Khilgaon"
  },
  {
    "code" : "30262537",
    "display" : "Khilkhet"
  },
  {
    "code" : "30260038",
    "display" : "Keraniganj"
  },
  {
    "code" : "30262040",
    "display" : "Kotwali"
  },
  {
    "code" : "30262042",
    "display" : "Lalbag"
  },
  {
    "code" : "30262548",
    "display" : "Mirpur"
  },
  {
    "code" : "30262054",
    "display" : "Motijheel"
  },
  {
    "code" : "30262057",
    "display" : "Mugda Para"
  },
  {
    "code" : "30260062",
    "display" : "Nawabganj"
  },
  {
    "code" : "30262063",
    "display" : "New Market"
  },
  {
    "code" : "30262564",
    "display" : "Pallabi"
  },
  {
    "code" : "30262065",
    "display" : "Paltan"
  },
  {
    "code" : "30262567",
    "display" : "Rampura"
  },
  {
    "code" : "30262068",
    "display" : "Sabujbag"
  },
  {
    "code" : "30262570",
    "display" : "Rupnagar"
  },
  {
    "code" : "30260072",
    "display" : "Savar"
  },
  {
    "code" : "30262073",
    "display" : "Shahjahanpur"
  },
  {
    "code" : "30262574",
    "display" : "Shah Ali"
  },
  {
    "code" : "30262075",
    "display" : "Shahbag"
  },
  {
    "code" : "30262076",
    "display" : "Shyampur"
  },
  {
    "code" : "30262580",
    "display" : "Sher-e-bangla Nagar"
  },
  {
    "code" : "30262088",
    "display" : "Sutrapur"
  },
  {
    "code" : "30262590",
    "display" : "Tejgaon"
  },
  {
    "code" : "30262592",
    "display" : "Tejgaon Ind. Area"
  },
  {
    "code" : "30262593",
    "display" : "Turag"
  },
  {
    "code" : "30262594",
    "display" : "Uttara  Paschim"
  },
  {
    "code" : "30262595",
    "display" : "Uttara  Purba"
  },
  {
    "code" : "30262596",
    "display" : "Uttar Khan"
  },
  {
    "code" : "30262098",
    "display" : "Wari"
  },
  {
    "code" : "30290003",
    "display" : "Alfadanga"
  },
  {
    "code" : "30290010",
    "display" : "Bhanga"
  },
  {
    "code" : "30290018",
    "display" : "Boalmari"
  },
  {
    "code" : "30290021",
    "display" : "Char Bhadrasan"
  },
  {
    "code" : "30290047",
    "display" : "Faridpur Sadar"
  },
  {
    "code" : "30290056",
    "display" : "Madhukhali"
  },
  {
    "code" : "30290062",
    "display" : "Nagarkanda"
  },
  {
    "code" : "30290084",
    "display" : "Sadarpur"
  },
  {
    "code" : "30290090",
    "display" : "Saltha"
  },
  {
    "code" : "30333330",
    "display" : "Gazipur Sadar"
  },
  {
    "code" : "30330032",
    "display" : "Kaliakair"
  },
  {
    "code" : "30330034",
    "display" : "Kaliganj"
  },
  {
    "code" : "30330036",
    "display" : "Kapasia"
  },
  {
    "code" : "30330086",
    "display" : "Sreepur"
  },
  {
    "code" : "30350032",
    "display" : "Gopalganj Sadar"
  },
  {
    "code" : "30350043",
    "display" : "Kashiani"
  },
  {
    "code" : "30350051",
    "display" : "Kotalipara"
  },
  {
    "code" : "30350058",
    "display" : "Muksudpur"
  },
  {
    "code" : "30350091",
    "display" : "Tungipara"
  },
  {
    "code" : "45390007",
    "display" : "Bakshiganj"
  },
  {
    "code" : "45390015",
    "display" : "Dewanganj"
  },
  {
    "code" : "45390029",
    "display" : "Islampur"
  },
  {
    "code" : "45390036",
    "display" : "Jamalpur Sadar"
  },
  {
    "code" : "45390058",
    "display" : "Madarganj"
  },
  {
    "code" : "45390061",
    "display" : "Melandaha"
  },
  {
    "code" : "45390085",
    "display" : "Sarishabari"
  },
  {
    "code" : "30480002",
    "display" : "Austagram"
  },
  {
    "code" : "30480006",
    "display" : "Bajitpur"
  },
  {
    "code" : "30480011",
    "display" : "Bhairab"
  },
  {
    "code" : "30480027",
    "display" : "Hossainpur"
  },
  {
    "code" : "30480033",
    "display" : "Itna"
  },
  {
    "code" : "30480042",
    "display" : "Karimganj"
  },
  {
    "code" : "30480045",
    "display" : "Katiadi"
  },
  {
    "code" : "30480049",
    "display" : "Kishoreganj Sadar"
  },
  {
    "code" : "30480054",
    "display" : "Kuliarchar"
  },
  {
    "code" : "30480059",
    "display" : "Mithamain"
  },
  {
    "code" : "30480076",
    "display" : "Nikli"
  },
  {
    "code" : "30480079",
    "display" : "Pakundia"
  },
  {
    "code" : "30480092",
    "display" : "Tarail"
  },
  {
    "code" : "30540040",
    "display" : "Kalkini"
  },
  {
    "code" : "30540054",
    "display" : "Madaripur Sadar"
  },
  {
    "code" : "30540080",
    "display" : "Rajoir"
  },
  {
    "code" : "30540087",
    "display" : "Shibchar"
  },
  {
    "code" : "30560010",
    "display" : "Daulatpur"
  },
  {
    "code" : "30560022",
    "display" : "Ghior"
  },
  {
    "code" : "30560028",
    "display" : "Harirampur"
  },
  {
    "code" : "30560046",
    "display" : "Manikganj Sadar"
  },
  {
    "code" : "30560070",
    "display" : "Saturia"
  },
  {
    "code" : "30560078",
    "display" : "Shibalaya"
  },
  {
    "code" : "30560082",
    "display" : "Singair"
  },
  {
    "code" : "30590024",
    "display" : "Gazaria"
  },
  {
    "code" : "30590044",
    "display" : "Lohajang"
  },
  {
    "code" : "30590056",
    "display" : "Munshiganj Sadar"
  },
  {
    "code" : "30590074",
    "display" : "Serajdikhan"
  },
  {
    "code" : "30590084",
    "display" : "Sreenagar"
  },
  {
    "code" : "30590094",
    "display" : "Tongibari"
  },
  {
    "code" : "45610013",
    "display" : "Bhaluka"
  },
  {
    "code" : "45610016",
    "display" : "Dhobaura"
  },
  {
    "code" : "45610020",
    "display" : "Fulbaria"
  },
  {
    "code" : "30260022",
    "display" : "Gaffargaon"
  },
  {
    "code" : "30260023",
    "display" : "Gauripur"
  },
  {
    "code" : "45610024",
    "display" : "Haluaghat"
  },
  {
    "code" : "45610031",
    "display" : "Ishwarganj"
  },
  {
    "code" : "45614052",
    "display" : "Mymensingh Sadar"
  },
  {
    "code" : "45610065",
    "display" : "Muktagacha"
  },
  {
    "code" : "45610072",
    "display" : "Nandail"
  },
  {
    "code" : "45610081",
    "display" : "Phulpur"
  },
  {
    "code" : "45610088",
    "display" : "Tarakanda"
  },
  {
    "code" : "45610094",
    "display" : "Trishal"
  },
  {
    "code" : "30670002",
    "display" : "Araihazar"
  },
  {
    "code" : "30670004",
    "display" : "Sonargaon"
  },
  {
    "code" : "30674406",
    "display" : "Bandar"
  },
  {
    "code" : "30674458",
    "display" : "Narayanganj Sadar"
  },
  {
    "code" : "30670068",
    "display" : "Rupganj"
  },
  {
    "code" : "30680007",
    "display" : "Belabo"
  },
  {
    "code" : "30680052",
    "display" : "Manohardi"
  },
  {
    "code" : "30680060",
    "display" : "Narsingdi Sadar"
  },
  {
    "code" : "30680063",
    "display" : "Palash"
  },
  {
    "code" : "30680064",
    "display" : "Roypura"
  },
  {
    "code" : "30680076",
    "display" : "Shibpur"
  },
  {
    "code" : "45720004",
    "display" : "Atpara"
  },
  {
    "code" : "45720009",
    "display" : "Barhatta"
  },
  {
    "code" : "45720018",
    "display" : "Durgapur"
  },
  {
    "code" : "45720038",
    "display" : "Khaliajuri"
  },
  {
    "code" : "45720040",
    "display" : "Kalmakanda"
  },
  {
    "code" : "45720047",
    "display" : "Kendua"
  },
  {
    "code" : "45720056",
    "display" : "Madan"
  },
  {
    "code" : "45720063",
    "display" : "Mohanganj"
  },
  {
    "code" : "45720074",
    "display" : "Netrokona Sadar"
  },
  {
    "code" : "45720083",
    "display" : "Purbadhala"
  },
  {
    "code" : "30820007",
    "display" : "Baliakandi"
  },
  {
    "code" : "30820029",
    "display" : "Goalanda"
  },
  {
    "code" : "30820047",
    "display" : "Kalukhali"
  },
  {
    "code" : "30820073",
    "display" : "Pangsha"
  },
  {
    "code" : "30820076",
    "display" : "Rajbari Sadar"
  },
  {
    "code" : "30860014",
    "display" : "Bhedarganj"
  },
  {
    "code" : "30860025",
    "display" : "Damudya"
  },
  {
    "code" : "30860036",
    "display" : "Gosairhat"
  },
  {
    "code" : "30860065",
    "display" : "Naria"
  },
  {
    "code" : "30860069",
    "display" : "Shariatpur Sadar"
  },
  {
    "code" : "30860094",
    "display" : "Zanjira"
  },
  {
    "code" : "45890037",
    "display" : "Jhenaigati"
  },
  {
    "code" : "45890067",
    "display" : "Nakla"
  },
  {
    "code" : "45890070",
    "display" : "Nalitabari"
  },
  {
    "code" : "45890088",
    "display" : "Sherpur Sadar"
  },
  {
    "code" : "30260090",
    "display" : "Sreebardi"
  },
  {
    "code" : "30930009",
    "display" : "Basail"
  },
  {
    "code" : "30930019",
    "display" : "Bhuapur"
  },
  {
    "code" : "30930023",
    "display" : "Delduar"
  },
  {
    "code" : "30930025",
    "display" : "Dhanbari"
  },
  {
    "code" : "30930028",
    "display" : "Ghatail"
  },
  {
    "code" : "30930038",
    "display" : "Gopalpur"
  },
  {
    "code" : "30930047",
    "display" : "Kalihati"
  },
  {
    "code" : "30930057",
    "display" : "Madhupur"
  },
  {
    "code" : "30930066",
    "display" : "Mirzapur"
  },
  {
    "code" : "30930076",
    "display" : "Nagarpur"
  },
  {
    "code" : "30930085",
    "display" : "Sakhipur"
  },
  {
    "code" : "30930095",
    "display" : "Tangail Sadar"
  },
  {
    "code" : "40010008",
    "display" : "Bagerhat Sadar"
  },
  {
    "code" : "40010014",
    "display" : "Chitalmari"
  },
  {
    "code" : "40010034",
    "display" : "Fakirhat"
  },
  {
    "code" : "40010038",
    "display" : "Kachua"
  },
  {
    "code" : "40010056",
    "display" : "Mollahat"
  },
  {
    "code" : "40010058",
    "display" : "Mongla"
  },
  {
    "code" : "40010060",
    "display" : "Morrelganj"
  },
  {
    "code" : "40010073",
    "display" : "Rampal"
  },
  {
    "code" : "40010077",
    "display" : "Sarankhola"
  },
  {
    "code" : "40180007",
    "display" : "Alamdanga"
  },
  {
    "code" : "40180023",
    "display" : "Chuadanga Sadar"
  },
  {
    "code" : "40180031",
    "display" : "Damurhuda"
  },
  {
    "code" : "40180055",
    "display" : "Jibannagar"
  },
  {
    "code" : "40410004",
    "display" : "Abhaynagar"
  },
  {
    "code" : "40410009",
    "display" : "Bagherpara"
  },
  {
    "code" : "40410011",
    "display" : "Chaugacha"
  },
  {
    "code" : "40410023",
    "display" : "Jhikargacha"
  },
  {
    "code" : "40410038",
    "display" : "Keshabpur"
  },
  {
    "code" : "40410047",
    "display" : "Jashore Sadar"
  },
  {
    "code" : "40410061",
    "display" : "Monirampur"
  },
  {
    "code" : "40410090",
    "display" : "Sharsha"
  },
  {
    "code" : "40440014",
    "display" : "Harinakunda"
  },
  {
    "code" : "40440019",
    "display" : "Jhenaidah Sadar"
  },
  {
    "code" : "40440033",
    "display" : "Kaliganj"
  },
  {
    "code" : "40440042",
    "display" : "Kotchandpur"
  },
  {
    "code" : "40440071",
    "display" : "Maheshpur"
  },
  {
    "code" : "40440080",
    "display" : "Shailkupa"
  },
  {
    "code" : "40470012",
    "display" : "Batiaghata"
  },
  {
    "code" : "40470017",
    "display" : "Dacope"
  },
  {
    "code" : "40473321",
    "display" : "Daulatpur"
  },
  {
    "code" : "40470030",
    "display" : "Dumuria"
  },
  {
    "code" : "40470040",
    "display" : "Dighalia"
  },
  {
    "code" : "40473345",
    "display" : "Khalishpur"
  },
  {
    "code" : "40473348",
    "display" : "Khan Jahan Ali"
  },
  {
    "code" : "40473351",
    "display" : "Khulna Sadar"
  },
  {
    "code" : "40470053",
    "display" : "Koyra"
  },
  {
    "code" : "40470064",
    "display" : "Paikgacha"
  },
  {
    "code" : "40470069",
    "display" : "Phultala"
  },
  {
    "code" : "40470075",
    "display" : "Rupsa"
  },
  {
    "code" : "40473385",
    "display" : "Sonadanga"
  },
  {
    "code" : "40470094",
    "display" : "Terokhada"
  },
  {
    "code" : "40500015",
    "display" : "Bheramara"
  },
  {
    "code" : "40500039",
    "display" : "Daulatpur"
  },
  {
    "code" : "40500063",
    "display" : "Khoksa"
  },
  {
    "code" : "40500071",
    "display" : "Kumarkhali"
  },
  {
    "code" : "40500079",
    "display" : "Kushtia Sadar"
  },
  {
    "code" : "40500094",
    "display" : "Mirpur"
  },
  {
    "code" : "40550057",
    "display" : "Magura Sadar"
  },
  {
    "code" : "40550066",
    "display" : "Mohammadpur"
  },
  {
    "code" : "40550085",
    "display" : "Shalikha"
  },
  {
    "code" : "40550095",
    "display" : "Sreepur"
  },
  {
    "code" : "40570047",
    "display" : "Gangni"
  },
  {
    "code" : "40570060",
    "display" : "Mujibnagar"
  },
  {
    "code" : "40570087",
    "display" : "Meherpur Sadar"
  },
  {
    "code" : "40650028",
    "display" : "Kalia"
  },
  {
    "code" : "40650052",
    "display" : "Lohagara"
  },
  {
    "code" : "40650076",
    "display" : "Narail Sadar"
  },
  {
    "code" : "40870004",
    "display" : "Assasuni"
  },
  {
    "code" : "40870025",
    "display" : "Debhata"
  },
  {
    "code" : "40870043",
    "display" : "Kalaroa"
  },
  {
    "code" : "40870047",
    "display" : "Kaliganj"
  },
  {
    "code" : "40870082",
    "display" : "Satkhira Sadar"
  },
  {
    "code" : "40870086",
    "display" : "Shyamnagar"
  },
  {
    "code" : "40870090",
    "display" : "Tala"
  },
  {
    "code" : "50100006",
    "display" : "Adamdighi"
  },
  {
    "code" : "50100020",
    "display" : "Bogura Sadar"
  },
  {
    "code" : "50100027",
    "display" : "Dhunat"
  },
  {
    "code" : "50100033",
    "display" : "Dhupchanchia"
  },
  {
    "code" : "50100040",
    "display" : "Gabtali"
  },
  {
    "code" : "50100054",
    "display" : "Kahaloo"
  },
  {
    "code" : "50100067",
    "display" : "Nandigram"
  },
  {
    "code" : "50100081",
    "display" : "Sariakandi"
  },
  {
    "code" : "50100085",
    "display" : "Shajahanpur"
  },
  {
    "code" : "50100088",
    "display" : "Sherpur"
  },
  {
    "code" : "50100094",
    "display" : "Shibganj"
  },
  {
    "code" : "50100095",
    "display" : "Sonatola"
  },
  {
    "code" : "50380013",
    "display" : "Akkelpur"
  },
  {
    "code" : "50380047",
    "display" : "Joypurhat Sadar"
  },
  {
    "code" : "50380058",
    "display" : "Kalai"
  },
  {
    "code" : "50380061",
    "display" : "Khetlal"
  },
  {
    "code" : "50380074",
    "display" : "Panchbibi"
  },
  {
    "code" : "50640003",
    "display" : "Atrai"
  },
  {
    "code" : "50640006",
    "display" : "Badalgachhi"
  },
  {
    "code" : "50640028",
    "display" : "Dhamoirhat"
  },
  {
    "code" : "50640047",
    "display" : "Manda"
  },
  {
    "code" : "50640050",
    "display" : "Mahadebpur"
  },
  {
    "code" : "50640060",
    "display" : "Naogaon Sadar"
  },
  {
    "code" : "50640069",
    "display" : "Niamatpur"
  },
  {
    "code" : "50640075",
    "display" : "Patnitala"
  },
  {
    "code" : "50640079",
    "display" : "Porsha"
  },
  {
    "code" : "50640085",
    "display" : "Raninagar"
  },
  {
    "code" : "50640086",
    "display" : "Sapahar"
  },
  {
    "code" : "50690009",
    "display" : "Bagatipara"
  },
  {
    "code" : "50690015",
    "display" : "Baraigram"
  },
  {
    "code" : "50690041",
    "display" : "Gurudaspur"
  },
  {
    "code" : "50690044",
    "display" : "Lalpur"
  },
  {
    "code" : "50690055",
    "display" : "Naldanga"
  },
  {
    "code" : "50690063",
    "display" : "Natore Sadar"
  },
  {
    "code" : "50690091",
    "display" : "Singra"
  },
  {
    "code" : "50700018",
    "display" : "Bholahat"
  },
  {
    "code" : "50700037",
    "display" : "Gomastapur"
  },
  {
    "code" : "50700056",
    "display" : "Nachole"
  },
  {
    "code" : "50700066",
    "display" : "Chapainawabganj Sadar"
  },
  {
    "code" : "50700088",
    "display" : "Shibganj"
  },
  {
    "code" : "50760005",
    "display" : "Atgharia"
  },
  {
    "code" : "50760016",
    "display" : "Bera"
  },
  {
    "code" : "50760019",
    "display" : "Bhangura"
  },
  {
    "code" : "50760022",
    "display" : "Chatmohar"
  },
  {
    "code" : "50760033",
    "display" : "Faridpur"
  },
  {
    "code" : "50760039",
    "display" : "Ishwardi"
  },
  {
    "code" : "50760055",
    "display" : "Pabna Sadar"
  },
  {
    "code" : "50760072",
    "display" : "Santhia"
  },
  {
    "code" : "50760083",
    "display" : "Sujanagar"
  },
  {
    "code" : "50810010",
    "display" : "Bagha"
  },
  {
    "code" : "50810012",
    "display" : "Baghmara"
  },
  {
    "code" : "50816622",
    "display" : "Boalia"
  },
  {
    "code" : "50810025",
    "display" : "Charghat"
  },
  {
    "code" : "50810031",
    "display" : "Durgapur"
  },
  {
    "code" : "50810034",
    "display" : "Godagari"
  },
  {
    "code" : "50816640",
    "display" : "Matihar"
  },
  {
    "code" : "50810053",
    "display" : "Mohanpur"
  },
  {
    "code" : "50810072",
    "display" : "Paba"
  },
  {
    "code" : "50810082",
    "display" : "Puthia"
  },
  {
    "code" : "50816685",
    "display" : "Rajpara"
  },
  {
    "code" : "50816690",
    "display" : "Shah Makhdum"
  },
  {
    "code" : "50810094",
    "display" : "Tanore"
  },
  {
    "code" : "50880011",
    "display" : "Belkuchi"
  },
  {
    "code" : "50880027",
    "display" : "Chauhali"
  },
  {
    "code" : "50880044",
    "display" : "Kamarkhanda"
  },
  {
    "code" : "50880050",
    "display" : "Kazipur"
  },
  {
    "code" : "50880061",
    "display" : "Royganj"
  },
  {
    "code" : "50880067",
    "display" : "Shahjadpur"
  },
  {
    "code" : "50880078",
    "display" : "Sirajganj Sadar"
  },
  {
    "code" : "50880089",
    "display" : "Tarash"
  },
  {
    "code" : "50880094",
    "display" : "Ullahpara"
  },
  {
    "code" : "55270010",
    "display" : "Birampur"
  },
  {
    "code" : "55270012",
    "display" : "Birganj"
  },
  {
    "code" : "55270017",
    "display" : "Biral"
  },
  {
    "code" : "55270021",
    "display" : "Bochaganj"
  },
  {
    "code" : "55270030",
    "display" : "Chirirbandar"
  },
  {
    "code" : "55270038",
    "display" : "Fulbari"
  },
  {
    "code" : "55270043",
    "display" : "Ghoraghat"
  },
  {
    "code" : "55270047",
    "display" : "Hakimpur"
  },
  {
    "code" : "55270056",
    "display" : "Kaharole"
  },
  {
    "code" : "55270060",
    "display" : "Khansama"
  },
  {
    "code" : "55270064",
    "display" : "Dinajpur Sadar"
  },
  {
    "code" : "55270069",
    "display" : "Nawabganj"
  },
  {
    "code" : "55270077",
    "display" : "Parbatipur"
  },
  {
    "code" : "55320021",
    "display" : "Fulchhari"
  },
  {
    "code" : "55320024",
    "display" : "Gaibandha Sadar"
  },
  {
    "code" : "55320030",
    "display" : "Gobindaganj"
  },
  {
    "code" : "55320067",
    "display" : "Palashbari"
  },
  {
    "code" : "55320082",
    "display" : "Sadullapur"
  },
  {
    "code" : "55320088",
    "display" : "Saghata"
  },
  {
    "code" : "55320091",
    "display" : "Sundarganj"
  },
  {
    "code" : "55490006",
    "display" : "Bhurungamari"
  },
  {
    "code" : "55490008",
    "display" : "Rajibpur"
  },
  {
    "code" : "55490009",
    "display" : "Chilmari"
  },
  {
    "code" : "55490018",
    "display" : "Phulbari"
  },
  {
    "code" : "55490052",
    "display" : "Kurigram Sadar"
  },
  {
    "code" : "55490061",
    "display" : "Nageshwari"
  },
  {
    "code" : "55490077",
    "display" : "Rajarhat"
  },
  {
    "code" : "55490079",
    "display" : "Raumari"
  },
  {
    "code" : "55490094",
    "display" : "Ulipur"
  },
  {
    "code" : "55520002",
    "display" : "Aditmari"
  },
  {
    "code" : "55520033",
    "display" : "Hatibandha"
  },
  {
    "code" : "55520039",
    "display" : "Kaliganj"
  },
  {
    "code" : "55520055",
    "display" : "Lalmonirhat Sadar"
  },
  {
    "code" : "55520070",
    "display" : "Patgram"
  },
  {
    "code" : "55730012",
    "display" : "Dimla"
  },
  {
    "code" : "55730015",
    "display" : "Domar"
  },
  {
    "code" : "55730036",
    "display" : "Jaldhaka"
  },
  {
    "code" : "55730045",
    "display" : "Kishoreganj"
  },
  {
    "code" : "55730064",
    "display" : "Nilphamari Sadar"
  },
  {
    "code" : "55730085",
    "display" : "Saidpur"
  },
  {
    "code" : "55770004",
    "display" : "Atwari"
  },
  {
    "code" : "55770025",
    "display" : "Boda"
  },
  {
    "code" : "55770034",
    "display" : "Debiganj"
  },
  {
    "code" : "55770073",
    "display" : "Panchagarh Sadar"
  },
  {
    "code" : "55770090",
    "display" : "Tentulia"
  },
  {
    "code" : "55850003",
    "display" : "Badarganj"
  },
  {
    "code" : "55850027",
    "display" : "Gangachara"
  },
  {
    "code" : "55850042",
    "display" : "Kaunia"
  },
  {
    "code" : "55857549",
    "display" : "Rangpur Sadar"
  },
  {
    "code" : "55850058",
    "display" : "Mithapukur"
  },
  {
    "code" : "55850073",
    "display" : "Pirgachha"
  },
  {
    "code" : "55850076",
    "display" : "Pirganj"
  },
  {
    "code" : "55850092",
    "display" : "Taraganj"
  },
  {
    "code" : "55940008",
    "display" : "Baliadangi"
  },
  {
    "code" : "55940051",
    "display" : "Haripur"
  },
  {
    "code" : "55940082",
    "display" : "Pirganj"
  },
  {
    "code" : "55940086",
    "display" : "Ranisankail"
  },
  {
    "code" : "55940094",
    "display" : "Thakurgaon Sadar"
  },
  {
    "code" : "60360002",
    "display" : "Ajmiriganj"
  },
  {
    "code" : "60360005",
    "display" : "Bahubal"
  },
  {
    "code" : "60360011",
    "display" : "Baniachong"
  },
  {
    "code" : "60360026",
    "display" : "Chunarughat"
  },
  {
    "code" : "60360044",
    "display" : "Habiganj Sadar"
  },
  {
    "code" : "60360068",
    "display" : "Lakhai"
  },
  {
    "code" : "60360071",
    "display" : "Madhabpur"
  },
  {
    "code" : "60360077",
    "display" : "Nabiganj"
  },
  {
    "code" : "60580014",
    "display" : "Barlekha"
  },
  {
    "code" : "60580035",
    "display" : "Juri"
  },
  {
    "code" : "60580056",
    "display" : "Kamalganj"
  },
  {
    "code" : "60580065",
    "display" : "Kulaura"
  },
  {
    "code" : "60580074",
    "display" : "Maulvibazar Sadar"
  },
  {
    "code" : "60580080",
    "display" : "Rajnagar"
  },
  {
    "code" : "60580083",
    "display" : "Sreemangal"
  },
  {
    "code" : "60900018",
    "display" : "Bishwambarpur"
  },
  {
    "code" : "60900023",
    "display" : "Chhatak"
  },
  {
    "code" : "60900087",
    "display" : "Shantiganj"
  },
  {
    "code" : "60900029",
    "display" : "Derai"
  },
  {
    "code" : "60900032",
    "display" : "Dharampasha"
  },
  {
    "code" : "60900033",
    "display" : "Dowarabazar"
  },
  {
    "code" : "60900047",
    "display" : "Jagannathpur"
  },
  {
    "code" : "60900050",
    "display" : "Jamalganj"
  },
  {
    "code" : "60900086",
    "display" : "Sulla"
  },
  {
    "code" : "60900089",
    "display" : "Sunamganj Sadar"
  },
  {
    "code" : "60900092",
    "display" : "Tahirpur"
  },
  {
    "code" : "60910008",
    "display" : "Balaganj"
  },
  {
    "code" : "60910017",
    "display" : "Beanibazar"
  },
  {
    "code" : "60910020",
    "display" : "Bishwanath"
  },
  {
    "code" : "60910027",
    "display" : "Companiganj"
  },
  {
    "code" : "60910031",
    "display" : "Dakshin Surma"
  },
  {
    "code" : "60910035",
    "display" : "Fenchuganj"
  },
  {
    "code" : "60910038",
    "display" : "Golapganj"
  },
  {
    "code" : "60910041",
    "display" : "Gowainghat"
  },
  {
    "code" : "60910053",
    "display" : "Jaintiapur"
  },
  {
    "code" : "60910059",
    "display" : "Kanaighat"
  },
  {
    "code" : "60915062",
    "display" : "Sylhet Sadar"
  },
  {
    "code" : "60910094",
    "display" : "Zakiganj"
  },
  {
    "code" : "30262550",
    "display" : "Mohammadpur"
  },
  {
    "code" : "30262097",
    "display" : "Dhanmondi"
  },
  {
    "code" : "20190073",
    "display" : "Lalmi"
  },
  {
    "code" : "60360087",
    "display" : "Shayestaganj"
  },
  {
    "code" : "20150039",
    "display" : "Karnaphuli"
  },
  {
    "code" : "60915068",
    "display" : "Shahparan"
  },
  {
    "code" : "30262527",
    "display" : "Hatirjheel"
  },
  {
    "code" : "30262028",
    "display" : "Hazaribag"
  },
  {
    "code" : "30262066",
    "display" : "Ramna"
  },
  {
    "code" : "30333315",
    "display" : "Basan"
  },
  {
    "code" : "30333318",
    "display" : "Gachha"
  },
  {
    "code" : "30333399",
    "display" : "Joydebpur"
  },
  {
    "code" : "30333340",
    "display" : "Kashimpur"
  },
  {
    "code" : "30333345",
    "display" : "Konabari"
  },
  {
    "code" : "30333350",
    "display" : "Pubail"
  },
  {
    "code" : "30333390",
    "display" : "Tongi Pashchim"
  },
  {
    "code" : "30333393",
    "display" : "Tongi Purba"
  },
  {
    "code" : "30540018",
    "display" : "Dasar"
  },
  {
    "code" : "20151602",
    "display" : "Akbarshah"
  },
  {
    "code" : "20151616",
    "display" : "Chalk Bazar"
  },
  {
    "code" : "20151631",
    "display" : "EPZ"
  },
  {
    "code" : "20151677",
    "display" : "Sadarghat"
  },
  {
    "code" : "20220032",
    "display" : "Eidgaon"
  },
  {
    "code" : "20460047",
    "display" : "Guimara"
  },
  {
    "code" : "45610022",
    "display" : "Gafargaon"
  },
  {
    "code" : "45610023",
    "display" : "Gouripur"
  },
  {
    "code" : "45890090",
    "display" : "Sreebardi"
  },
  {
    "code" : "50816624",
    "display" : "Chandrima"
  },
  {
    "code" : "50816638",
    "display" : "Kashiadanga"
  },
  {
    "code" : "55857531",
    "display" : "Hajirhat"
  },
  {
    "code" : "55857533",
    "display" : "Haragachh"
  },
  {
    "code" : "55857544",
    "display" : "Kotwali"
  },
  {
    "code" : "55857555",
    "display" : "Mahiganj"
  },
  {
    "code" : "55857569",
    "display" : "Parshuram"
  },
  {
    "code" : "55857589",
    "display" : "Tajhat"
  },
  {
    "code" : "60900063",
    "display" : "Madhyanagar"
  },
  {
    "code" : "60915005",
    "display" : "Airport"
  },
  {
    "code" : "60915048",
    "display" : "Jalalabad"
  },
  {
    "code" : "60915055",
    "display" : "Kotwali"
  },
  {
    "code" : "60915057",
    "display" : "Moglabazar"
  },
  {
    "code" : "60910060",
    "display" : "Osmaninagar"
  },
  {
    "code" : "50690066",
    "display" : "Naldanga"
  },
  {
    "code" : "20220075",
    "display" : "Eidgaon"
  },
  {
    "code" : "1004000920",
    "display" : "Amtali Paurasava"
  },
  {
    "code" : "1004002840",
    "display" : "Barguna Paurasava"
  },
  {
    "code" : "1004004760",
    "display" : "Betagi Paurasava"
  },
  {
    "code" : "1004008580",
    "display" : "Patharghata Paurasava"
  },
  {
    "code" : "1006000716",
    "display" : "Bakerganj Paurasava"
  },
  {
    "code" : "1006001033",
    "display" : "Banari Para Paurasava"
  },
  {
    "code" : "1006003267",
    "display" : "Gaurnadi Paurasava"
  },
  {
    "code" : "1006505150",
    "display" : "Barisal City Corp."
  },
  {
    "code" : "1006006283",
    "display" : "Mhendiganj Paurasava"
  },
  {
    "code" : "1006006987",
    "display" : "Muladi Paurashava"
  },
  {
    "code" : "1009001816",
    "display" : "Bhola Paurasava"
  },
  {
    "code" : "1009002133",
    "display" : "Burhanuddin Paurasava"
  },
  {
    "code" : "1009002550",
    "display" : "Char Fasson Paurasava"
  },
  {
    "code" : "1009002967",
    "display" : "Daulatkhan Paurasava"
  },
  {
    "code" : "1009005483",
    "display" : "Lalmohan Paurasava"
  },
  {
    "code" : "1042004033",
    "display" : "Jhalokati Paurasava"
  },
  {
    "code" : "1042007366",
    "display" : "Nalchity Paurasava"
  },
  {
    "code" : "1078003816",
    "display" : "Bauphal Paurashava"
  },
  {
    "code" : "1078005725",
    "display" : "Galachipa Paurasava"
  },
  {
    "code" : "1078006650",
    "display" : "Kalapara Paurasava"
  },
  {
    "code" : "1078006660",
    "display" : "Kuakata Paurasava"
  },
  {
    "code" : "1078009575",
    "display" : "Patuakhali Paurashava"
  },
  {
    "code" : "1079005825",
    "display" : "Mathbaria Paurasava"
  },
  {
    "code" : "1079008050",
    "display" : "Pirojpur Paurasava"
  },
  {
    "code" : "1079008775",
    "display" : "Swarupkati Paurasava"
  },
  {
    "code" : "2003001450",
    "display" : "Bandarban Paurashava"
  },
  {
    "code" : "2003005162",
    "display" : "Lama Paurashava"
  },
  {
    "code" : "2012000222",
    "display" : "Akhaura Paurasava"
  },
  {
    "code" : "2012001366",
    "display" : "Brahmanbaria Paurasava"
  },
  {
    "code" : "2012006376",
    "display" : "Kasba Paurasava"
  },
  {
    "code" : "2012008588",
    "display" : "Nabinagar Paurasava"
  },
  {
    "code" : "2013002214",
    "display" : "Chandpur Paurasava"
  },
  {
    "code" : "2013004535",
    "display" : "Faridganj Paurashava"
  },
  {
    "code" : "2013004942",
    "display" : "Hajiganj Paurasava"
  },
  {
    "code" : "2013005857",
    "display" : "Kachua Paurasava"
  },
  {
    "code" : "2013007671",
    "display" : "Matlab Paurasava"
  },
  {
    "code" : "2013007928",
    "display" : "Sengarchar Paurasava"
  },
  {
    "code" : "2013009585",
    "display" : "Shahrasti Paurasava"
  },
  {
    "code" : "2015160616",
    "display" : "Chittagong City Corp."
  },
  {
    "code" : "2015000805",
    "display" : "Banshkhali Paurashava"
  },
  {
    "code" : "2015161016",
    "display" : "Chittagong City Corp."
  },
  {
    "code" : "2015001210",
    "display" : "Boalkhali Paurashava"
  },
  {
    "code" : "2015001812",
    "display" : "Chandanaish Paurashava"
  },
  {
    "code" : "2015161916",
    "display" : "Chittagong City Corp."
  },
  {
    "code" : "2015162016",
    "display" : "Chittagong City Corp."
  },
  {
    "code" : "2015162816",
    "display" : "Chittagong City Corp."
  },
  {
    "code" : "2015003322",
    "display" : "Fatikchhari Paurasava"
  },
  {
    "code" : "2015163516",
    "display" : "Chittagong City Corp."
  },
  {
    "code" : "2015164116",
    "display" : "Chittagong City Corp."
  },
  {
    "code" : "2015164316",
    "display" : "Chittagong City Corp."
  },
  {
    "code" : "2015005308",
    "display" : "Baroiar Hat Paurashava"
  },
  {
    "code" : "2015005325",
    "display" : "Mirsharai Paurashava"
  },
  {
    "code" : "2015165516",
    "display" : "Chittagong City Corp."
  },
  {
    "code" : "2015165716",
    "display" : "Chittagong City Corp."
  },
  {
    "code" : "2015006133",
    "display" : "Patiya Paurashava"
  },
  {
    "code" : "2015166516",
    "display" : "Chittagong City Corp."
  },
  {
    "code" : "2015007041",
    "display" : "Rangunia Paurashava"
  },
  {
    "code" : "2015007450",
    "display" : "Raozan Paurashava"
  },
  {
    "code" : "2015007867",
    "display" : "Sandwip Paurashava"
  },
  {
    "code" : "2015008275",
    "display" : "Satkania Paurashava"
  },
  {
    "code" : "2015008683",
    "display" : "Sitakunda Paurashava"
  },
  {
    "code" : "2019000916",
    "display" : "Barura Paurasava"
  },
  {
    "code" : "2019000950",
    "display" : "Comilla City Corp."
  },
  {
    "code" : "2019002733",
    "display" : "Chandina Paurasava"
  },
  {
    "code" : "2019003137",
    "display" : "Chauddagram Paurashava"
  },
  {
    "code" : "2019003667",
    "display" : "Daudkandi Paurasava"
  },
  {
    "code" : "2019004070",
    "display" : "Debidwar Paurashava"
  },
  {
    "code" : "2019005475",
    "display" : "Homna Paurashava"
  },
  {
    "code" : "2019007283",
    "display" : "Laksam Paurasava"
  },
  {
    "code" : "2019008787",
    "display" : "Nangalkot Paurashava"
  },
  {
    "code" : "2022001633",
    "display" : "Chakaria Paurashava"
  },
  {
    "code" : "2022002466",
    "display" : "COX'S BAZAR PAURASHAVA"
  },
  {
    "code" : "2022004977",
    "display" : "Maheshkhali Paurashava"
  },
  {
    "code" : "2022009088",
    "display" : "Teknaf Paurashava"
  },
  {
    "code" : "2030001415",
    "display" : "Chhagalnaiya Paurashava"
  },
  {
    "code" : "2030002530",
    "display" : "Daganbhuiyan Paurasava"
  },
  {
    "code" : "2030002950",
    "display" : "Feni Paurasava"
  },
  {
    "code" : "2030005165",
    "display" : "Parshuram Paurashava"
  },
  {
    "code" : "2030009480",
    "display" : "Sonagazi Paurashava"
  },
  {
    "code" : "2046004950",
    "display" : "Khagrachhari Paurasava"
  },
  {
    "code" : "2046007062",
    "display" : "Matiranga Paurashava"
  },
  {
    "code" : "2046008075",
    "display" : "Ramgarh Paurashava"
  },
  {
    "code" : "2051004325",
    "display" : "Lakshmipur Paurasava"
  },
  {
    "code" : "2051005850",
    "display" : "Roypur Paurasava"
  },
  {
    "code" : "2051006575",
    "display" : "Ramganj Paurasava"
  },
  {
    "code" : "2051007387",
    "display" : "Ramgati Paurashava"
  },
  {
    "code" : "2075000733",
    "display" : "Chaumohani Paurasava"
  },
  {
    "code" : "2075001050",
    "display" : "Chatkhil Paurasava"
  },
  {
    "code" : "2075002116",
    "display" : "Basurhat Paurasava"
  },
  {
    "code" : "2075003660",
    "display" : "Hatiya Paurashava"
  },
  {
    "code" : "2075004766",
    "display" : "Kabirhat Paurasava"
  },
  {
    "code" : "2075008075",
    "display" : "Senbagh Paurashava"
  },
  {
    "code" : "2075008390",
    "display" : "Sonaimuri Paurasava"
  },
  {
    "code" : "2075008783",
    "display" : "Noakhali Paurasava"
  },
  {
    "code" : "2084000720",
    "display" : "Baghaichhari Paurashava"
  },
  {
    "code" : "2084008750",
    "display" : "Rangamati Paurashava"
  },
  {
    "code" : "3026001440",
    "display" : "Dhamrai Paurashava"
  },
  {
    "code" : "3026001860",
    "display" : "Dohar Paurashava"
  },
  {
    "code" : "3026007280",
    "display" : "Savar Paurashava"
  },
  {
    "code" : "3029001020",
    "display" : "Bhanga Paurashava"
  },
  {
    "code" : "3029001840",
    "display" : "Boalmari Paurashava"
  },
  {
    "code" : "3029004760",
    "display" : "Faridpur Paurashava"
  },
  {
    "code" : "3029005670",
    "display" : "Madhukhali Paurasava"
  },
  {
    "code" : "3029006280",
    "display" : "Nagarkanda Paurashava"
  },
  {
    "code" : "3033333033",
    "display" : "Gazipur City Corporation"
  },
  {
    "code" : "3033003244",
    "display" : "Kaliakair Paurashava"
  },
  {
    "code" : "3033003449",
    "display" : "Kaliganj Paurashava"
  },
  {
    "code" : "3033008655",
    "display" : "Sreepur Paurashava"
  },
  {
    "code" : "3035003225",
    "display" : "Gopalganj Paurashava"
  },
  {
    "code" : "3035005150",
    "display" : "Kotalipara Paurashava"
  },
  {
    "code" : "3035005865",
    "display" : "Muksudpur Paurashava"
  },
  {
    "code" : "3035009175",
    "display" : "Tungipara Paurashava"
  },
  {
    "code" : "4539000710",
    "display" : "Bakshiganj Paurashava"
  },
  {
    "code" : "4539001516",
    "display" : "Dewanganj Paurashava"
  },
  {
    "code" : "4539002933",
    "display" : "Islampur Paurashava"
  },
  {
    "code" : "4539003650",
    "display" : "Jamalpur Paurashava"
  },
  {
    "code" : "4539005860",
    "display" : "Madarganj Paurashava"
  },
  {
    "code" : "4539006167",
    "display" : "Melandaha Paurashava"
  },
  {
    "code" : "4539008583",
    "display" : "Sarishabari Paurashava"
  },
  {
    "code" : "3048000625",
    "display" : "Bajitpur Paurashava"
  },
  {
    "code" : "3048001150",
    "display" : "Bhairab Paurashava"
  },
  {
    "code" : "3048002762",
    "display" : "Hossainpur Paurashava"
  },
  {
    "code" : "3048004266",
    "display" : "Karimganj Paurashava"
  },
  {
    "code" : "3048004570",
    "display" : "Katiadi Paurashava"
  },
  {
    "code" : "3048004975",
    "display" : "Kishoreganj Paurashava"
  },
  {
    "code" : "3048005488",
    "display" : "Kuliar Char Paurashava"
  },
  {
    "code" : "3048007992",
    "display" : "Pakundia Paurashava"
  },
  {
    "code" : "3054004025",
    "display" : "Kalkini Paurashava"
  },
  {
    "code" : "3054005450",
    "display" : "Madaripur Paurashava"
  },
  {
    "code" : "3054008068",
    "display" : "Rajoir Paurashava"
  },
  {
    "code" : "3054008775",
    "display" : "Shibchar Paurashava"
  },
  {
    "code" : "3056004650",
    "display" : "Manikganj Paurashava"
  },
  {
    "code" : "3056008287",
    "display" : "Singair Paurashava"
  },
  {
    "code" : "3059005633",
    "display" : "Mirkadim Paurashava"
  },
  {
    "code" : "3059005666",
    "display" : "Munshiganj Paurashava"
  },
  {
    "code" : "4561001311",
    "display" : "Bhaluka Paurashava"
  },
  {
    "code" : "4561002018",
    "display" : "Fulbaria Paurashava"
  },
  {
    "code" : "3026002222",
    "display" : "Gaffargaon Paurashava"
  },
  {
    "code" : "4561002333",
    "display" : "Gauripur Paurashava"
  },
  {
    "code" : "4561003144",
    "display" : "Ishwarganj Paurashava"
  },
  {
    "code" : "4561405255",
    "display" : "Mymensingh Paurashava"
  },
  {
    "code" : "4561006566",
    "display" : "Muktagachha Paurashava"
  },
  {
    "code" : "4561007277",
    "display" : "Nandail Paurashava"
  },
  {
    "code" : "4561008183",
    "display" : "Phulpur Paurashava"
  },
  {
    "code" : "4561009488",
    "display" : "Trishal Paurashava"
  },
  {
    "code" : "3067000215",
    "display" : "Araihazar Paurashava"
  },
  {
    "code" : "3067000235",
    "display" : "Gopaldi Paurashava"
  },
  {
    "code" : "3067000466",
    "display" : "Sonargaon Paurashava"
  },
  {
    "code" : "3067445844",
    "display" : "Narayanganj City Corp."
  },
  {
    "code" : "3067006833",
    "display" : "Kanchan Paurashava"
  },
  {
    "code" : "3067006877",
    "display" : "Tarabo Paurashava"
  },
  {
    "code" : "3068005237",
    "display" : "Manohardi Paurashava"
  },
  {
    "code" : "3068006025",
    "display" : "Madhabdi Paurashava"
  },
  {
    "code" : "3068006050",
    "display" : "Narsingdi Paurashava"
  },
  {
    "code" : "3068006315",
    "display" : "Ghorashal Paurashava"
  },
  {
    "code" : "3068006480",
    "display" : "Roypura Paurashava"
  },
  {
    "code" : "3068007687",
    "display" : "Shibpur Paurashava"
  },
  {
    "code" : "4572001820",
    "display" : "Durgapur Paurasava"
  },
  {
    "code" : "4572004740",
    "display" : "Kendua Paurasava"
  },
  {
    "code" : "4572005650",
    "display" : "Madan Paurasava"
  },
  {
    "code" : "4572006360",
    "display" : "Mohanganj Paurasava"
  },
  {
    "code" : "4572007480",
    "display" : "Netrokona Paurasava"
  },
  {
    "code" : "3082002922",
    "display" : "Goalandaghat Paurashava"
  },
  {
    "code" : "3082007333",
    "display" : "Pangsha Paurashava"
  },
  {
    "code" : "3082007666",
    "display" : "Rajbari Paurashava"
  },
  {
    "code" : "3086001416",
    "display" : "Bhedarganj Paurashava"
  },
  {
    "code" : "3086002533",
    "display" : "Damudya Paurashava"
  },
  {
    "code" : "3086006550",
    "display" : "Naria Paurashava"
  },
  {
    "code" : "3086006966",
    "display" : "Shariatpur Paurashava"
  },
  {
    "code" : "3086009483",
    "display" : "Zanjira Paurashava"
  },
  {
    "code" : "4589006722",
    "display" : "Nakla Paurashava"
  },
  {
    "code" : "4589007033",
    "display" : "Nalitabari Paurashava"
  },
  {
    "code" : "4589008866",
    "display" : "Sherpur Paurashava"
  },
  {
    "code" : "3026009077",
    "display" : "Sreebardi Paurashava"
  },
  {
    "code" : "3093000908",
    "display" : "Basail Paurashava"
  },
  {
    "code" : "3093001912",
    "display" : "Bhuapur Paurashava"
  },
  {
    "code" : "3093002525",
    "display" : "Dhanbari Paurasava"
  },
  {
    "code" : "3093002837",
    "display" : "Ghatail Paurashava"
  },
  {
    "code" : "3093003850",
    "display" : "Gopalpur Paurashava"
  },
  {
    "code" : "3093004730",
    "display" : "Elenga Paurashava"
  },
  {
    "code" : "3093004762",
    "display" : "Kalihati Paurashava"
  },
  {
    "code" : "3093005775",
    "display" : "Madhupur Paurashava"
  },
  {
    "code" : "3093006670",
    "display" : "Mirzapur Paurashava"
  },
  {
    "code" : "3093008580",
    "display" : "Sakhipur Paurashava"
  },
  {
    "code" : "3093009587",
    "display" : "Tangail Paurashava"
  },
  {
    "code" : "4001000825",
    "display" : "Bagerhat Paurasava"
  },
  {
    "code" : "4001005850",
    "display" : "Mongla Port Paurasava"
  },
  {
    "code" : "4001006075",
    "display" : "Morrelganj Paurasava"
  },
  {
    "code" : "4018000720",
    "display" : "Alamdanga Paurasava"
  },
  {
    "code" : "4018002340",
    "display" : "Chuadanga Paurasava"
  },
  {
    "code" : "4018003160",
    "display" : "Darshana Paurasava"
  },
  {
    "code" : "4018005580",
    "display" : "Jiban Nagar Paurasava"
  },
  {
    "code" : "4041000483",
    "display" : "Noapara Paurasava"
  },
  {
    "code" : "4041000905",
    "display" : "Bagher Para Paurasava"
  },
  {
    "code" : "4041001113",
    "display" : "Chaugachha Paurasava"
  },
  {
    "code" : "4041002333",
    "display" : "Jhikargachha Paurasava"
  },
  {
    "code" : "4041003837",
    "display" : "Keshabpur Paurashava"
  },
  {
    "code" : "4041004716",
    "display" : "Jessore Paurasava"
  },
  {
    "code" : "4041006166",
    "display" : "Manirampur Paurasava"
  },
  {
    "code" : "4041009008",
    "display" : "Benapole Paurashava"
  },
  {
    "code" : "4044001412",
    "display" : "Harinakunda Paurashava"
  },
  {
    "code" : "4044001916",
    "display" : "Jhenaidah Paurasava"
  },
  {
    "code" : "4044003332",
    "display" : "Kaliganj Paurasava"
  },
  {
    "code" : "4044004250",
    "display" : "Kotchandpur Paurasava"
  },
  {
    "code" : "4044007166",
    "display" : "Maheshpur Paurasava"
  },
  {
    "code" : "4044008083",
    "display" : "Shailkupa Paurasava"
  },
  {
    "code" : "4047001722",
    "display" : "Chalna Paurasava"
  },
  {
    "code" : "4047332133",
    "display" : "Khulna City Corp."
  },
  {
    "code" : "4047334533",
    "display" : "Khulna City Corp."
  },
  {
    "code" : "4047334833",
    "display" : "Khulna City Corp."
  },
  {
    "code" : "4047335133",
    "display" : "Khulna City Corp."
  },
  {
    "code" : "4047006466",
    "display" : "Paikgachha Paurashava"
  },
  {
    "code" : "4047338533",
    "display" : "Khulna City Corp."
  },
  {
    "code" : "4050001520",
    "display" : "Bheramara Paurashava"
  },
  {
    "code" : "4050006330",
    "display" : "Khoksa Paurashava"
  },
  {
    "code" : "4050007140",
    "display" : "Kumarkhali Paurashava"
  },
  {
    "code" : "4050007960",
    "display" : "Kushtia Paurashava"
  },
  {
    "code" : "4050009480",
    "display" : "Mirpur Paurashava"
  },
  {
    "code" : "4055005750",
    "display" : "Magura Paurasava"
  },
  {
    "code" : "4057004722",
    "display" : "Gangni Paurashava"
  },
  {
    "code" : "4057008733",
    "display" : "Meherpur Paurashava"
  },
  {
    "code" : "4065002833",
    "display" : "Kalia Paurasava"
  },
  {
    "code" : "4065005244",
    "display" : "Lohagara Paurasava"
  },
  {
    "code" : "4065007666",
    "display" : "Narail Paurasava"
  },
  {
    "code" : "4087004333",
    "display" : "Kalaroa Paurasava"
  },
  {
    "code" : "4087008266",
    "display" : "Satkhira Paurasava"
  },
  {
    "code" : "5010000650",
    "display" : "Santahar Paurasava"
  },
  {
    "code" : "5010002020",
    "display" : "Bogra Paurasava"
  },
  {
    "code" : "5010002730",
    "display" : "Dhunat Paurashava"
  },
  {
    "code" : "5010003337",
    "display" : "Dhupchanchia Paurasava"
  },
  {
    "code" : "5010003370",
    "display" : "Talora  Paurashava"
  },
  {
    "code" : "5010004040",
    "display" : "Gabtali Paurashava"
  },
  {
    "code" : "5010005442",
    "display" : "Kahaloo Paurashava"
  },
  {
    "code" : "5010006745",
    "display" : "Nandigram Paurashava"
  },
  {
    "code" : "5010008165",
    "display" : "Sariakandi Paurasava"
  },
  {
    "code" : "5010008875",
    "display" : "Sherpur Paurasava"
  },
  {
    "code" : "5010009482",
    "display" : "Shibganj Paurashava"
  },
  {
    "code" : "5010009587",
    "display" : "Sonatola Paurashava"
  },
  {
    "code" : "5038001325",
    "display" : "Akkelpur Paurasava"
  },
  {
    "code" : "5038004750",
    "display" : "Joypurhat Paurasava"
  },
  {
    "code" : "5038005860",
    "display" : "Kalai Paurasava"
  },
  {
    "code" : "5038006167",
    "display" : "Khetlal Paurasava"
  },
  {
    "code" : "5038007475",
    "display" : "Panchbibi Paurasava"
  },
  {
    "code" : "5064002830",
    "display" : "Dhamoirhat Paurasava"
  },
  {
    "code" : "5064006050",
    "display" : "Naogaon Paurasava"
  },
  {
    "code" : "5064007570",
    "display" : "Nozipur Paurasava"
  },
  {
    "code" : "5069000921",
    "display" : "Bagatipara Paurasava"
  },
  {
    "code" : "5069001525",
    "display" : "Banpara Paurasava"
  },
  {
    "code" : "5069001531",
    "display" : "Baraigram Paurasava"
  },
  {
    "code" : "5069004140",
    "display" : "Gurudaspur Paurasava"
  },
  {
    "code" : "5069004435",
    "display" : "Gopalpur (lalpur) Paurasava"
  },
  {
    "code" : "5069005545",
    "display" : "Naldanga Paurasava"
  },
  {
    "code" : "5069006350",
    "display" : "Natore Paurasava"
  },
  {
    "code" : "5069009175",
    "display" : "Singra Paurasava"
  },
  {
    "code" : "5070003744",
    "display" : "Rahanpur Paurashava"
  },
  {
    "code" : "5070005622",
    "display" : "Nachole Paurashava"
  },
  {
    "code" : "5070006633",
    "display" : "Chapai Nababganj Paurashava"
  },
  {
    "code" : "5070008866",
    "display" : "Shibganj Paurashava"
  },
  {
    "code" : "5076000508",
    "display" : "Atgharia Paurasava"
  },
  {
    "code" : "5076001612",
    "display" : "Bera Paurasava"
  },
  {
    "code" : "5076001918",
    "display" : "Bhangura Paurasava"
  },
  {
    "code" : "5076002225",
    "display" : "Chatmohar Paurasava"
  },
  {
    "code" : "5076003337",
    "display" : "Faridpur Paurasava"
  },
  {
    "code" : "5076003950",
    "display" : "Ishwardi Paurasava"
  },
  {
    "code" : "5076005562",
    "display" : "Pabna Paurasava"
  },
  {
    "code" : "5076007275",
    "display" : "Santhia Paurasava"
  },
  {
    "code" : "5076008387",
    "display" : "Sujanagar Paurasava"
  },
  {
    "code" : "5081001008",
    "display" : "Arani Paurasava"
  },
  {
    "code" : "5081001016",
    "display" : "Bagha Paurasava"
  },
  {
    "code" : "5081001225",
    "display" : "Bhabanigonj Paurasava"
  },
  {
    "code" : "5081001285",
    "display" : "Tahirpur Paurasava"
  },
  {
    "code" : "5081662266",
    "display" : "Rajshahi City Corp."
  },
  {
    "code" : "5081002533",
    "display" : "Charghat Paurasava"
  },
  {
    "code" : "5081003143",
    "display" : "Durgapur Paurasava"
  },
  {
    "code" : "5081003450",
    "display" : "Godagari Paurasava"
  },
  {
    "code" : "5081003455",
    "display" : "Kakanhat Paurasava"
  },
  {
    "code" : "5081664066",
    "display" : "Rajshahi City Corp."
  },
  {
    "code" : "5081005365",
    "display" : "Kesharhat Paurasava"
  },
  {
    "code" : "5081007260",
    "display" : "Katakhali Paurasava"
  },
  {
    "code" : "5081007275",
    "display" : "Noahata Paurasava"
  },
  {
    "code" : "5081008280",
    "display" : "Puthia Paurasava"
  },
  {
    "code" : "5081668566",
    "display" : "Rajshahi City Corp."
  },
  {
    "code" : "5081669066",
    "display" : "Rajshahi City Corp."
  },
  {
    "code" : "5081009470",
    "display" : "Mundumala Paurasava"
  },
  {
    "code" : "5081009483",
    "display" : "Tanore Paurasava"
  },
  {
    "code" : "5088001116",
    "display" : "Belkuchi Paurashava"
  },
  {
    "code" : "5088005020",
    "display" : "Kazipur Paurasava"
  },
  {
    "code" : "5088006123",
    "display" : "Royganj Paurashava"
  },
  {
    "code" : "5088006725",
    "display" : "Shahjadpur Paurasava"
  },
  {
    "code" : "5088007850",
    "display" : "Sirajganj Paurasava"
  },
  {
    "code" : "5088009475",
    "display" : "Ullah Para Paurasava"
  },
  {
    "code" : "5527001012",
    "display" : "Birampur Paurasava"
  },
  {
    "code" : "5527001218",
    "display" : "Birganj Paurashava"
  },
  {
    "code" : "5527002185",
    "display" : "Setabganj Paurasava"
  },
  {
    "code" : "5527003842",
    "display" : "Fulbari Paurasava"
  },
  {
    "code" : "5527004353",
    "display" : "Ghoraghat Paurashava"
  },
  {
    "code" : "5527004757",
    "display" : "Hakimpur Paurasava"
  },
  {
    "code" : "5527006428",
    "display" : "Dinajpur Paurasava"
  },
  {
    "code" : "5527007771",
    "display" : "Parbatipur Paurasava"
  },
  {
    "code" : "5532002422",
    "display" : "Gaibandha Paurasava"
  },
  {
    "code" : "5532003033",
    "display" : "Gobindaganj Paurasava"
  },
  {
    "code" : "5532006766",
    "display" : "Palashbari Paurashav"
  },
  {
    "code" : "5532009177",
    "display" : "Sundarganj Paurashava"
  },
  {
    "code" : "5549005233",
    "display" : "Kurigram Paurasava"
  },
  {
    "code" : "5549006155",
    "display" : "Nageshwari Paurashava"
  },
  {
    "code" : "5549009466",
    "display" : "Ulipur Paurasava"
  },
  {
    "code" : "5552005533",
    "display" : "Lalmonirhat Paurasava"
  },
  {
    "code" : "5552007066",
    "display" : "Patgram Paurasava"
  },
  {
    "code" : "5573001525",
    "display" : "Domar Paurasava"
  },
  {
    "code" : "5573003637",
    "display" : "Jaldhaka Paurashava"
  },
  {
    "code" : "5573006450",
    "display" : "Nilphamari Paurasava"
  },
  {
    "code" : "5573008575",
    "display" : "Saidpur Paurasava"
  },
  {
    "code" : "5577002520",
    "display" : "Boda Paurashava"
  },
  {
    "code" : "5577007350",
    "display" : "Panchagarh Paurasava"
  },
  {
    "code" : "5585000313",
    "display" : "Badarganj Paurasava"
  },
  {
    "code" : "5585004225",
    "display" : "Haragachh (kaunia) Paurasava"
  },
  {
    "code" : "5585754975",
    "display" : "Rangpur City Corporation"
  },
  {
    "code" : "5594008233",
    "display" : "Pirganj Paurasava"
  },
  {
    "code" : "5594008655",
    "display" : "Ranisankail Paurashava"
  },
  {
    "code" : "5594009466",
    "display" : "Thakurgaon Paurasava"
  },
  {
    "code" : "6036000212",
    "display" : "Ajmiriganj Paurashava"
  },
  {
    "code" : "6036002616",
    "display" : "Chunarughat Paurashava"
  },
  {
    "code" : "6036004420",
    "display" : "Habiganj Paurashava"
  },
  {
    "code" : "6036008780",
    "display" : "Shayestagang Paurashava"
  },
  {
    "code" : "6036007140",
    "display" : "Madhabpur Paurashava"
  },
  {
    "code" : "6036007760",
    "display" : "Nabiganj Paurashava"
  },
  {
    "code" : "6058001413",
    "display" : "Barlekha Paurashava"
  },
  {
    "code" : "6058005615",
    "display" : "Kamalganj Paurashava"
  },
  {
    "code" : "6058006525",
    "display" : "Kulaura Paurashava"
  },
  {
    "code" : "6058007450",
    "display" : "Maulvibazar Paurashava"
  },
  {
    "code" : "6058008375",
    "display" : "Sreemangal Paurashava"
  },
  {
    "code" : "6090002320",
    "display" : "Chhatak Paurashava"
  },
  {
    "code" : "6090002940",
    "display" : "Derai Paurashava"
  },
  {
    "code" : "6090004750",
    "display" : "Jagannathpur Paurashava"
  },
  {
    "code" : "6090008960",
    "display" : "Sunamganj Paurashava"
  },
  {
    "code" : "6091001716",
    "display" : "Beani Bazar Paurashava"
  },
  {
    "code" : "6091003825",
    "display" : "Golapganj Paurashava"
  },
  {
    "code" : "6091005937",
    "display" : "Kanaighat Paurashava"
  },
  {
    "code" : "6091506250",
    "display" : "Sylhet City Corp."
  },
  {
    "code" : "6091009475",
    "display" : "Zakiganj Paurashava"
  },
  {
    "code" : "1004000999",
    "display" : "Unions Of Amtali Upazila"
  },
  {
    "code" : "1004001999",
    "display" : "Unions Of Bamna Upazila"
  },
  {
    "code" : "1004002899",
    "display" : "Unions Of Barguna Sadar Upazila"
  },
  {
    "code" : "1004004799",
    "display" : "Unions Of Betagi Upazila"
  },
  {
    "code" : "1004008599",
    "display" : "Unions Of Patharghata Upazila"
  },
  {
    "code" : "1004009099",
    "display" : "Unions Of Taltali Upazila"
  },
  {
    "code" : "1006000299",
    "display" : "Unions Of Agailjhara Upazila"
  },
  {
    "code" : "1006000399",
    "display" : "Unions Of Babuganj Upazila"
  },
  {
    "code" : "1006000799",
    "display" : "Unions Of Bakerganj Upazila"
  },
  {
    "code" : "1006001099",
    "display" : "Unions Of Banari Para Upazila"
  },
  {
    "code" : "1006003299",
    "display" : "Unions Of Gaurnadi Upazila"
  },
  {
    "code" : "1006003699",
    "display" : "Unions Of Hizla Upazila"
  },
  {
    "code" : "1006505199",
    "display" : "Unions Of Barisal Sadar (kotwali) Upazila"
  },
  {
    "code" : "1006006299",
    "display" : "Unions Of Mhendiganj Upazila"
  },
  {
    "code" : "1006006999",
    "display" : "Unions Of Muladi Upazila"
  },
  {
    "code" : "1006009499",
    "display" : "Unions Of Wazirpur Upazila"
  },
  {
    "code" : "1009001899",
    "display" : "Unions Of Bhola Sadar Upazila"
  },
  {
    "code" : "1009002199",
    "display" : "Unions Of Burhanuddin Upazila"
  },
  {
    "code" : "1009002599",
    "display" : "Unions Of Char Fasson Upazila"
  },
  {
    "code" : "1009002999",
    "display" : "Unions Of Daulat Khan Upazila"
  },
  {
    "code" : "1009005499",
    "display" : "Unions Of Lalmohan Upazila"
  },
  {
    "code" : "1009006599",
    "display" : "Unions Of Manpura Upazila"
  },
  {
    "code" : "1009009199",
    "display" : "Unions Of Tazumuddin Upazila"
  },
  {
    "code" : "1042004099",
    "display" : "Unions Of Jhalokati Sadar Upazila"
  },
  {
    "code" : "1042004399",
    "display" : "Unions Of Kanthalia Upazila"
  },
  {
    "code" : "1042007399",
    "display" : "Unions Of Nalchity Upazila"
  },
  {
    "code" : "1042008499",
    "display" : "Unions Of Rajapur Upazila"
  },
  {
    "code" : "1078003899",
    "display" : "Unions Of Bauphal Upazila"
  },
  {
    "code" : "1078005299",
    "display" : "Unions Of Dashmina Upazila"
  },
  {
    "code" : "1078005599",
    "display" : "Unions Of Dumki Upazila"
  },
  {
    "code" : "1078005799",
    "display" : "Unions Of Galachipa Upazila"
  },
  {
    "code" : "1078006699",
    "display" : "Unions Of Kalapara Upazila"
  },
  {
    "code" : "1078007699",
    "display" : "Unions Of Mirzaganj Upazila"
  },
  {
    "code" : "1078009599",
    "display" : "Unions Of Patuakhali Sadar Upazila"
  },
  {
    "code" : "1078009799",
    "display" : "Unions Of Rangabali Upazila"
  },
  {
    "code" : "1079001499",
    "display" : "Unions Of Bhandaria Upazila"
  },
  {
    "code" : "1079004799",
    "display" : "Unions Of Kawkhali Upazila"
  },
  {
    "code" : "1079005899",
    "display" : "Unions Of Mathbaria Upazila"
  },
  {
    "code" : "1079007699",
    "display" : "Unions Of Nazirpur Upazila"
  },
  {
    "code" : "1079008099",
    "display" : "Unions Of Pirojpur Sadar Upazila"
  },
  {
    "code" : "1079008799",
    "display" : "Unions Of Nesarabad (swarupkati) Upazila"
  },
  {
    "code" : "1079009099",
    "display" : "Unions Of Indurkani Upazila"
  },
  {
    "code" : "2003000499",
    "display" : "Unions Of Alikadam Upazila"
  },
  {
    "code" : "2003001499",
    "display" : "Unions Of Bandarban Sadar Upazila"
  },
  {
    "code" : "2003005199",
    "display" : "Unions Of Lama Upazila"
  },
  {
    "code" : "2003007399",
    "display" : "Unions Of Naikhongchhari Upazila"
  },
  {
    "code" : "2003008999",
    "display" : "Unions Of Rowangchhari Upazila"
  },
  {
    "code" : "2003009199",
    "display" : "Unions Of Ruma Upazila"
  },
  {
    "code" : "2003009599",
    "display" : "Unions Of Thanchi Upazila"
  },
  {
    "code" : "2012000299",
    "display" : "Unions Of Akhaura Upazila"
  },
  {
    "code" : "2012000499",
    "display" : "Unions Of Banchharampur Upazila"
  },
  {
    "code" : "2012000799",
    "display" : "Unions Of Bijoynagar Upazila"
  },
  {
    "code" : "2012001399",
    "display" : "Unions Of Brahmanbaria Sadar Upazila"
  },
  {
    "code" : "2012003399",
    "display" : "Unions Of Ashuganj Upazila"
  },
  {
    "code" : "2012006399",
    "display" : "Unions Of Kasba Upazila"
  },
  {
    "code" : "2012008599",
    "display" : "Unions Of Nabinagar Upazila"
  },
  {
    "code" : "2012009099",
    "display" : "Unions Of Nasirnagar Upazila"
  },
  {
    "code" : "2012009499",
    "display" : "Unions Of Sarail Upazila"
  },
  {
    "code" : "2013002299",
    "display" : "Unions Of Chandpur Sadar Upazila"
  },
  {
    "code" : "2013004599",
    "display" : "Unions Of Faridganj Upazila"
  },
  {
    "code" : "2013004799",
    "display" : "Unions Of Haim Char Upazila"
  },
  {
    "code" : "2013004999",
    "display" : "Unions Of Hajiganj Upazila"
  },
  {
    "code" : "2013005899",
    "display" : "Unions Of Kachua Upazila"
  },
  {
    "code" : "2013007699",
    "display" : "Unions Of Matlab Dakshin Upazila"
  },
  {
    "code" : "2013007999",
    "display" : "Unions Of Matlab Uttar Upazila"
  },
  {
    "code" : "2013009599",
    "display" : "Unions Of Shahrasti Upazila"
  },
  {
    "code" : "2015000499",
    "display" : "Unions Of Anowara Upazila"
  },
  {
    "code" : "2015000899",
    "display" : "Unions Of Banshkhali Upazila"
  },
  {
    "code" : "2015001299",
    "display" : "Unions Of Boalkhali Upazila"
  },
  {
    "code" : "2015001899",
    "display" : "Unions Of Chandanaish Upazila"
  },
  {
    "code" : "2015003399",
    "display" : "Unions Of Fatikchhari Upazila"
  },
  {
    "code" : "2015003799",
    "display" : "Unions Of Hathazari Upazila"
  },
  {
    "code" : "2015004799",
    "display" : "Unions Of Lohagara Upazila"
  },
  {
    "code" : "2015005399",
    "display" : "Unions Of Mirsharai Upazila"
  },
  {
    "code" : "2015006199",
    "display" : "Unions Of Patiya Upazila"
  },
  {
    "code" : "2015007099",
    "display" : "Unions Of Rangunia Upazila"
  },
  {
    "code" : "2015007499",
    "display" : "Unions Of Raozan Upazila"
  },
  {
    "code" : "2015007899",
    "display" : "Unions Of Sandwip Upazila"
  },
  {
    "code" : "2015008299",
    "display" : "Unions Of Satkania Upazila"
  },
  {
    "code" : "2015008699",
    "display" : "Unions Of Sitakunda Upazila"
  },
  {
    "code" : "2019000999",
    "display" : "Unions Of Barura Upazila"
  },
  {
    "code" : "2019001599",
    "display" : "Unions Of Brahman Para Upazila"
  },
  {
    "code" : "2019001899",
    "display" : "Unions Of Burichang Upazila"
  },
  {
    "code" : "2019002799",
    "display" : "Unions Of Chandina Upazila"
  },
  {
    "code" : "2019003199",
    "display" : "Unions Of Chauddagram Upazila"
  },
  {
    "code" : "2019007373",
    "display" : "Unions Of Lalmi Upazila"
  },
  {
    "code" : "2019003699",
    "display" : "Unions Of Daudkandi Upazila"
  },
  {
    "code" : "2019004099",
    "display" : "Unions Of Debidwar Upazila"
  },
  {
    "code" : "2019005499",
    "display" : "Unions Of Homna Upazila"
  },
  {
    "code" : "2019506799",
    "display" : "Unions Of Comilla Adarsha Sadar Upazila"
  },
  {
    "code" : "2019007299",
    "display" : "Unions Of Laksam Upazila"
  },
  {
    "code" : "2019007499",
    "display" : "Unions Of Manoharganj Upazila"
  },
  {
    "code" : "2019007599",
    "display" : "Unions Of Meghna Upazila"
  },
  {
    "code" : "2019008199",
    "display" : "Unions Of Muradnagar Upazila"
  },
  {
    "code" : "2019008799",
    "display" : "Unions Of Nangalkot Upazila"
  },
  {
    "code" : "2019009499",
    "display" : "Unions Of Titas Upazila"
  },
  {
    "code" : "2022001699",
    "display" : "Unions Of Chakaria Upazila"
  },
  {
    "code" : "2022002499",
    "display" : "Unions of Cox's Bazar Sadar Upazila"
  },
  {
    "code" : "2022004599",
    "display" : "Unions Of Kutubdia Upazila"
  },
  {
    "code" : "2022004999",
    "display" : "Unions Of Maheshkhali Upazila"
  },
  {
    "code" : "2022005699",
    "display" : "Unions Of Pekua Upazila"
  },
  {
    "code" : "2022006699",
    "display" : "Unions Of Ramu Upazila"
  },
  {
    "code" : "2022009099",
    "display" : "Unions Of Teknaf Upazila"
  },
  {
    "code" : "2022009499",
    "display" : "Unions Of Ukhia Upazila"
  },
  {
    "code" : "2030001499",
    "display" : "Unions Of Chhagalnaiya Upazila"
  },
  {
    "code" : "2030002599",
    "display" : "Unions Of Daganbhuiyan Upazila"
  },
  {
    "code" : "2030002999",
    "display" : "Unions Of Feni Sadar Upazila"
  },
  {
    "code" : "2030004199",
    "display" : "Unions Of Fulgazi Upazila"
  },
  {
    "code" : "2030005199",
    "display" : "Unions Of Parshuram Upazila"
  },
  {
    "code" : "2030009499",
    "display" : "Unions Of Sonagazi Upazila"
  },
  {
    "code" : "2046004399",
    "display" : "Unions Of Dighinala Upazila"
  },
  {
    "code" : "2046004999",
    "display" : "Unions Of Khagrachhari Sadar Upazila"
  },
  {
    "code" : "2046006199",
    "display" : "Unions Of Lakshmichhari Upazila"
  },
  {
    "code" : "2046006599",
    "display" : "Unions Of Mahalchhari Upazila"
  },
  {
    "code" : "2046006799",
    "display" : "Unions Of Manikchhari Upazila"
  },
  {
    "code" : "2046007099",
    "display" : "Unions Of Matiranga Upazila"
  },
  {
    "code" : "2046007799",
    "display" : "Unions Of Panchhari Upazila"
  },
  {
    "code" : "2046008099",
    "display" : "Unions Of Ramgarh Upazila"
  },
  {
    "code" : "2051003399",
    "display" : "Unions Of Kamalnagar Upazila"
  },
  {
    "code" : "2051004399",
    "display" : "Unions Of Lakshmipur Sadar Upazila"
  },
  {
    "code" : "2051005899",
    "display" : "Unions Of Roypur Upazila"
  },
  {
    "code" : "2051006599",
    "display" : "Unions Of Ramganj Upazila"
  },
  {
    "code" : "2051007399",
    "display" : "Unions Of Ramgati Upazila"
  },
  {
    "code" : "2075000799",
    "display" : "Unions Of Begumganj Upazila"
  },
  {
    "code" : "2075001099",
    "display" : "Unions Of Chatkhil Upazila"
  },
  {
    "code" : "2075002199",
    "display" : "Unions Of Companiganj Upazila"
  },
  {
    "code" : "2075003699",
    "display" : "Unions Of Hatiya Upazila"
  },
  {
    "code" : "2075004799",
    "display" : "Unions Of Kabirhat Upazila"
  },
  {
    "code" : "2075008099",
    "display" : "Unions Of Senbagh Upazila"
  },
  {
    "code" : "2075008399",
    "display" : "Unions Of Sonaimuri Upazila"
  },
  {
    "code" : "2075008599",
    "display" : "Unions Of Subarnachar Upazila"
  },
  {
    "code" : "2075008799",
    "display" : "Unions Of Noakhali Sadar Upazila"
  },
  {
    "code" : "2084000799",
    "display" : "Unions Of Baghaichhari Upazila"
  },
  {
    "code" : "2084002199",
    "display" : "Unions Of Barkal Upazila Upazila"
  },
  {
    "code" : "2084002599",
    "display" : "Unions Of Kawkhali (betbunia) Upazila"
  },
  {
    "code" : "2084002999",
    "display" : "Unions Of Belai Chhari  Upazi Upazila"
  },
  {
    "code" : "2084003699",
    "display" : "Unions Of Kaptai  Upazila Upazila"
  },
  {
    "code" : "2084004799",
    "display" : "Unions Of Jurai Chhari Upazil Upazila"
  },
  {
    "code" : "2084005899",
    "display" : "Unions Of Langadu  Upazila Upazila"
  },
  {
    "code" : "2084007599",
    "display" : "Unions Of Naniarchar  Upazila Upazila"
  },
  {
    "code" : "2084007899",
    "display" : "Unions Of Rajasthali  Upazila Upazila"
  },
  {
    "code" : "2084008799",
    "display" : "Unions Of Rangamati Sadar  Up Upazila"
  },
  {
    "code" : "3026250499",
    "display" : "Unions Of Badda Upazila"
  },
  {
    "code" : "3026251099",
    "display" : "Unions Of Dakshinkhan Upazila"
  },
  {
    "code" : "3026201299",
    "display" : "Unions Of Demra Upazila"
  },
  {
    "code" : "3026001499",
    "display" : "Unions Of Dhamrai Upazila"
  },
  {
    "code" : "3026001899",
    "display" : "Unions Of Dohar Upazila"
  },
  {
    "code" : "3026252299",
    "display" : "Unions Of Bhatara Upazila"
  },
  {
    "code" : "3026202999",
    "display" : "Unions Of Jatrabari Upazila"
  },
  {
    "code" : "3026203299",
    "display" : "Unions Of Kadamtali Upazila"
  },
  {
    "code" : "3026203499",
    "display" : "Unions Of Kamrangir Char Upazila"
  },
  {
    "code" : "3026203699",
    "display" : "Unions Of Khilgaon Upazila"
  },
  {
    "code" : "3026253799",
    "display" : "Unions Of Khilkhet Upazila"
  },
  {
    "code" : "3026003899",
    "display" : "Unions Of Keraniganj Upazila"
  },
  {
    "code" : "3026205799",
    "display" : "Unions Of Mugda Para Upazila"
  },
  {
    "code" : "3026006299",
    "display" : "Unions Of Nawabganj Upazila"
  },
  {
    "code" : "3026206899",
    "display" : "Unions Of Sabujbagh Upazila"
  },
  {
    "code" : "3026007299",
    "display" : "Unions Of Savar Upazila"
  },
  {
    "code" : "3026259399",
    "display" : "Unions Of Turag Upazila"
  },
  {
    "code" : "3026259699",
    "display" : "Unions Of Uttar Khan Upazila"
  },
  {
    "code" : "3029000399",
    "display" : "Unions Of Alfadanga Upazila"
  },
  {
    "code" : "3029001099",
    "display" : "Unions Of Bhanga Upazila"
  },
  {
    "code" : "3029001899",
    "display" : "Unions Of Boalmari Upazila"
  },
  {
    "code" : "3029002199",
    "display" : "Unions Of Char Bhadrasan Upazila"
  },
  {
    "code" : "3029004799",
    "display" : "Unions Of Faridpur Sadar Upazila"
  },
  {
    "code" : "3029005699",
    "display" : "Unions Of Madhukhali Upazila"
  },
  {
    "code" : "3029006299",
    "display" : "Unions Of Nagarkanda Upazila"
  },
  {
    "code" : "3029008499",
    "display" : "Unions Of Sadarpur Upazila"
  },
  {
    "code" : "3029009099",
    "display" : "Unions Of Saltha Upazila"
  },
  {
    "code" : "3033333099",
    "display" : "Unions Of Gazipur Sadar Upazila"
  },
  {
    "code" : "3033003299",
    "display" : "Unions Of Kaliakair Upazila"
  },
  {
    "code" : "3033003499",
    "display" : "Unions Of Kaliganj Upazila"
  },
  {
    "code" : "3033003699",
    "display" : "Unions Of Kapasia Upazila"
  },
  {
    "code" : "3033008699",
    "display" : "Unions Of Sreepur Upazila"
  },
  {
    "code" : "3035003299",
    "display" : "Unions Of Gopalganj Sadar Upazila"
  },
  {
    "code" : "3035004399",
    "display" : "Unions Of Kashiani Upazila"
  },
  {
    "code" : "3035005199",
    "display" : "Unions Of Kotalipara Upazila"
  },
  {
    "code" : "3035005899",
    "display" : "Unions Of Muksudpur Upazila"
  },
  {
    "code" : "3035009199",
    "display" : "Unions Of Tungipara Upazila"
  },
  {
    "code" : "4539000799",
    "display" : "Unions Of Bakshiganj Upazila"
  },
  {
    "code" : "4539001599",
    "display" : "Unions Of Dewanganj Upazila"
  },
  {
    "code" : "4539002999",
    "display" : "Unions Of Islampur Upazila"
  },
  {
    "code" : "4539003699",
    "display" : "Unions Of Jamalpur Sadar Upazila"
  },
  {
    "code" : "4539005899",
    "display" : "Unions Of Madarganj Upazila"
  },
  {
    "code" : "4539006199",
    "display" : "Unions Of Melandaha Upazila"
  },
  {
    "code" : "4539008599",
    "display" : "Unions Of Sarishabari Upazila Upazila"
  },
  {
    "code" : "3048000299",
    "display" : "Unions Of Austagram Upazila"
  },
  {
    "code" : "3048000699",
    "display" : "Unions Of Bajitpur Upazila"
  },
  {
    "code" : "3048001199",
    "display" : "Unions Of Bhairab Upazila"
  },
  {
    "code" : "3048002799",
    "display" : "Unions Of Hossainpur Upazila"
  },
  {
    "code" : "3048003399",
    "display" : "Unions Of Itna Upazila"
  },
  {
    "code" : "3048004299",
    "display" : "Unions Of Karimganj Upazila"
  },
  {
    "code" : "3048004599",
    "display" : "Unions Of Katiadi Upazila"
  },
  {
    "code" : "3048004999",
    "display" : "Unions Of Kishoreganj Sadar Upazila"
  },
  {
    "code" : "3048005499",
    "display" : "Unions Of Kuliar Char Upazila"
  },
  {
    "code" : "3048005999",
    "display" : "Unions Of Mithamain Upazila"
  },
  {
    "code" : "3048007699",
    "display" : "Unions Of Nikli Upazila"
  },
  {
    "code" : "3048007999",
    "display" : "Unions Of Pakundia Upazila"
  },
  {
    "code" : "3048009299",
    "display" : "Unions Of Tarail Upazila"
  },
  {
    "code" : "3054004099",
    "display" : "Unions Of Kalkini Upazila"
  },
  {
    "code" : "3054005499",
    "display" : "Unions Of Madaripur Sadar Upazila"
  },
  {
    "code" : "3054008099",
    "display" : "Unions Of Rajoir Upazila"
  },
  {
    "code" : "3054008799",
    "display" : "Unions Of Shibchar Upazila"
  },
  {
    "code" : "3056001099",
    "display" : "Unions Of Daulatpur Upazila"
  },
  {
    "code" : "3056002299",
    "display" : "Unions Of Ghior Upazila"
  },
  {
    "code" : "3056002899",
    "display" : "Unions Of Harirampur Upazila"
  },
  {
    "code" : "3056004699",
    "display" : "Unions Of Manikganj Sadar Upazila"
  },
  {
    "code" : "3056007099",
    "display" : "Unions Of Saturia Upazila"
  },
  {
    "code" : "3056007899",
    "display" : "Unions Of Shibalaya Upazila"
  },
  {
    "code" : "3056008299",
    "display" : "Unions Of Singair Upazila"
  },
  {
    "code" : "3059002499",
    "display" : "Unions Of Gazaria Upazila"
  },
  {
    "code" : "3059004499",
    "display" : "Unions Of Lohajang Upazila"
  },
  {
    "code" : "3059005699",
    "display" : "Unions Of Munshiganj Sadar Upazila"
  },
  {
    "code" : "3059007499",
    "display" : "Unions Of Serajdikhan Upazila"
  },
  {
    "code" : "3059008499",
    "display" : "Unions Of Sreenagar Upazila"
  },
  {
    "code" : "3059009499",
    "display" : "Unions Of Tongibari Upazila"
  },
  {
    "code" : "4561001399",
    "display" : "Unions Of Bhaluka Upazila"
  },
  {
    "code" : "4561001699",
    "display" : "Unions Of Dhobaura Upazila"
  },
  {
    "code" : "4561002099",
    "display" : "Unions Of Fulbaria Upazila"
  },
  {
    "code" : "4561002299",
    "display" : "Unions Of Gaffargaon Upazila"
  },
  {
    "code" : "4561002399",
    "display" : "Unions Of Gauripur Upazila"
  },
  {
    "code" : "4561002499",
    "display" : "Unions Of Haluaghat Upazila"
  },
  {
    "code" : "4561003199",
    "display" : "Unions Of Ishwarganj Upazila"
  },
  {
    "code" : "4561405299",
    "display" : "Unions Of Mymensingh Sadar Upazila"
  },
  {
    "code" : "4561006599",
    "display" : "Unions Of Muktagachha Upazila"
  },
  {
    "code" : "4561007299",
    "display" : "Unions Of Nandail Upazila"
  },
  {
    "code" : "4561008199",
    "display" : "Unions Of Phulpur Upazila"
  },
  {
    "code" : "4561008899",
    "display" : "Unions Of Tarakanda Upazila"
  },
  {
    "code" : "4561009499",
    "display" : "Unions Of Trishal Upazila"
  },
  {
    "code" : "3067000299",
    "display" : "Unions Of Araihazar Upazila"
  },
  {
    "code" : "3067000499",
    "display" : "Unions Of Sonargaon Upazila"
  },
  {
    "code" : "3067440699",
    "display" : "Unions Of Bandar Upazila"
  },
  {
    "code" : "3067445899",
    "display" : "Unions Of Narayanganj Sadar Upazila"
  },
  {
    "code" : "3067006899",
    "display" : "Unions Of Rupganj Upazila"
  },
  {
    "code" : "3068000799",
    "display" : "Unions Of Belabo Upazila"
  },
  {
    "code" : "3068005299",
    "display" : "Unions Of Manohardi Upazila"
  },
  {
    "code" : "3068006099",
    "display" : "Unions Of Narsingdi Sadar Upazila"
  },
  {
    "code" : "3068006399",
    "display" : "Unions Of Palash Upazila"
  },
  {
    "code" : "3068006499",
    "display" : "Unions Of Roypura Upazila"
  },
  {
    "code" : "3068007699",
    "display" : "Unions Of Shibpur Upazila"
  },
  {
    "code" : "4572000499",
    "display" : "Unions Of Atpara Upazila"
  },
  {
    "code" : "4572000999",
    "display" : "Unions Of Barhatta Upazila"
  },
  {
    "code" : "4572001899",
    "display" : "Unions Of Durgapur Upazila"
  },
  {
    "code" : "4572003899",
    "display" : "Unions Of Khaliajuri Upazila"
  },
  {
    "code" : "4572004099",
    "display" : "Unions Of Kalmakanda Upazila"
  },
  {
    "code" : "4572004799",
    "display" : "Unions Of Kendua Upazila"
  },
  {
    "code" : "4572005699",
    "display" : "Unions Of Madan Upazila"
  },
  {
    "code" : "4572006399",
    "display" : "Unions Of Mohanganj Upazila"
  },
  {
    "code" : "4572007499",
    "display" : "Unions Of Netrokona Sadar Upazila"
  },
  {
    "code" : "4572008399",
    "display" : "Unions Of Purbadhala Upazila"
  },
  {
    "code" : "3082000799",
    "display" : "Unions Of Baliakandi Upazila"
  },
  {
    "code" : "3082002999",
    "display" : "Unions Of Goalanda Upazila"
  },
  {
    "code" : "3082004799",
    "display" : "Unions Of Kalukhali Upazila"
  },
  {
    "code" : "3082007399",
    "display" : "Unions Of Pangsha Upazila"
  },
  {
    "code" : "3082007699",
    "display" : "Unions Of Rajbari Sadar Upazila"
  },
  {
    "code" : "3086001499",
    "display" : "Unions Of Bhedarganj Upazila"
  },
  {
    "code" : "3086002599",
    "display" : "Unions Of Damudya Upazila"
  },
  {
    "code" : "3086003699",
    "display" : "Unions Of Gosairhat Upazila"
  },
  {
    "code" : "3086006599",
    "display" : "Unions Of Naria Upazila"
  },
  {
    "code" : "3086006999",
    "display" : "Unions Of Shariatpur Sadar Upazila"
  },
  {
    "code" : "3086009499",
    "display" : "Unions Of Zanjira Upazila"
  },
  {
    "code" : "4589003799",
    "display" : "Unions Of Jhenaigati Upazila"
  },
  {
    "code" : "4589006799",
    "display" : "Unions Of Nakla Upazila"
  },
  {
    "code" : "4589007099",
    "display" : "Unions Of Nalitabari Upazila"
  },
  {
    "code" : "4589008899",
    "display" : "Unions Of Sherpur Sadar Upazila"
  },
  {
    "code" : "3026009099",
    "display" : "Unions Of Sreebardi Upazila"
  },
  {
    "code" : "3093000999",
    "display" : "Unions Of Basail Upazila"
  },
  {
    "code" : "3093001999",
    "display" : "Unions Of Bhuapur Upazila"
  },
  {
    "code" : "3093002399",
    "display" : "Unions Of Delduar Upazila"
  },
  {
    "code" : "3093002599",
    "display" : "Unions Of Dhanbari Upazila"
  },
  {
    "code" : "3093002899",
    "display" : "Unions Of Ghatail Upazila"
  },
  {
    "code" : "3093003899",
    "display" : "Unions Of Gopalpur Upazila"
  },
  {
    "code" : "3093004799",
    "display" : "Unions Of Kalihati Upazila"
  },
  {
    "code" : "3093005799",
    "display" : "Unions Of Madhupur Upazila"
  },
  {
    "code" : "3093006699",
    "display" : "Unions Of Mirzapur Upazila"
  },
  {
    "code" : "3093007699",
    "display" : "Unions Of Nagarpur Upazila"
  },
  {
    "code" : "3093008599",
    "display" : "Unions Of Sakhipur Upazila"
  },
  {
    "code" : "3093009599",
    "display" : "Unions Of Tangail Sadar Upazila"
  },
  {
    "code" : "4001000899",
    "display" : "Unions Of Bagerhat Sadar Upazila"
  },
  {
    "code" : "4001001499",
    "display" : "Unions Of Chitalmari Upazila"
  },
  {
    "code" : "4001003499",
    "display" : "Unions Of Fakirhat Upazila"
  },
  {
    "code" : "4001003899",
    "display" : "Unions Of Kachua Upazila"
  },
  {
    "code" : "4001005699",
    "display" : "Unions Of Mollahat Upazila"
  },
  {
    "code" : "4001005899",
    "display" : "Unions Of Mongla Upazila"
  },
  {
    "code" : "4001006099",
    "display" : "Unions Of Morrelganj Upazila"
  },
  {
    "code" : "4001007399",
    "display" : "Unions Of Rampal Upazila"
  },
  {
    "code" : "4001007799",
    "display" : "Unions Of Sarankhola Upazila"
  },
  {
    "code" : "4018000799",
    "display" : "Unions Of Alamdanga Upazila"
  },
  {
    "code" : "4018002399",
    "display" : "Unions Of Chuadanga Sadar Upazila"
  },
  {
    "code" : "4018003199",
    "display" : "Unions Of Damurhuda Upazila"
  },
  {
    "code" : "4018005599",
    "display" : "Unions Of Jiban Nagar Upazila"
  },
  {
    "code" : "4041000499",
    "display" : "Unions Of Abhaynagar Upazila"
  },
  {
    "code" : "4041000999",
    "display" : "Unions Of Bagher Para Upazila"
  },
  {
    "code" : "4041001199",
    "display" : "Unions Of Chaugachha Upazila"
  },
  {
    "code" : "4041002399",
    "display" : "Unions Of Jhikargachha Upazila"
  },
  {
    "code" : "4041003899",
    "display" : "Unions Of Keshabpur Upazila"
  },
  {
    "code" : "4041004799",
    "display" : "Unions Of Jessore Sadar Upazila"
  },
  {
    "code" : "4041006199",
    "display" : "Unions Of Manirampur Upazila"
  },
  {
    "code" : "4041009099",
    "display" : "Unions Of Sharsha Upazila"
  },
  {
    "code" : "4044001499",
    "display" : "Unions Of Harinakunda Upazila"
  },
  {
    "code" : "4044001999",
    "display" : "Unions Of Jhenaidah Sadar Upazila"
  },
  {
    "code" : "4044003399",
    "display" : "Unions Of Kaliganj Upazila"
  },
  {
    "code" : "4044004299",
    "display" : "Unions Of Kotchandpur Upazila"
  },
  {
    "code" : "4044007199",
    "display" : "Unions Of Maheshpur Upazila"
  },
  {
    "code" : "4044008099",
    "display" : "Unions Of Shailkupa Upazila"
  },
  {
    "code" : "4047001299",
    "display" : "Unions Of Batiaghata Upazila"
  },
  {
    "code" : "4047001799",
    "display" : "Unions Of Dacope Upazila"
  },
  {
    "code" : "4047332199",
    "display" : "Unions Of Daulatpur Upazila"
  },
  {
    "code" : "4047003099",
    "display" : "Unions Of Dumuria Upazila"
  },
  {
    "code" : "4047004099",
    "display" : "Unions Of Dighalia Upazila"
  },
  {
    "code" : "4047334899",
    "display" : "Unions Of Khan Jahan Ali Upazila"
  },
  {
    "code" : "4047005399",
    "display" : "Unions Of Koyra Upazila"
  },
  {
    "code" : "4047006499",
    "display" : "Unions Of Paikgachha Upazila"
  },
  {
    "code" : "4047006999",
    "display" : "Unions Of Phultala Upazila"
  },
  {
    "code" : "4047007599",
    "display" : "Unions Of Rupsa Upazila"
  },
  {
    "code" : "4047009499",
    "display" : "Unions Of Terokhada Upazila"
  },
  {
    "code" : "4050001599",
    "display" : "Unions Of Bheramara Upazila"
  },
  {
    "code" : "4050003999",
    "display" : "Unions Of Daulatpur Upazila"
  },
  {
    "code" : "4050006399",
    "display" : "Unions Of Khoksa Upazila"
  },
  {
    "code" : "4050007199",
    "display" : "Unions Of Kumarkhali Upazila"
  },
  {
    "code" : "4050007999",
    "display" : "Unions Of Kushtia Sadar Upazila"
  },
  {
    "code" : "4050009499",
    "display" : "Unions Of Mirpur Upazila"
  },
  {
    "code" : "4055005799",
    "display" : "Unions Of Magura Sadar Upazila"
  },
  {
    "code" : "4055006699",
    "display" : "Unions Of Mohammadpur Upazila"
  },
  {
    "code" : "4055008599",
    "display" : "Unions Of Shalikha Upazila"
  },
  {
    "code" : "4055009599",
    "display" : "Unions Of Sreepur Upazila"
  },
  {
    "code" : "4057004799",
    "display" : "Unions Of Gangni Upazila"
  },
  {
    "code" : "4057006099",
    "display" : "Unions Of Mujib Nagar Upazila"
  },
  {
    "code" : "4057008799",
    "display" : "Unions Of Meherpur Sadar Upazila"
  },
  {
    "code" : "4065002899",
    "display" : "Unions Of Kalia Upazila"
  },
  {
    "code" : "4065005299",
    "display" : "Unions Of Lohagara Upazila"
  },
  {
    "code" : "4065007699",
    "display" : "Unions Of Narail Sadar Upazila"
  },
  {
    "code" : "4087000499",
    "display" : "Unions Of Assasuni Upazila"
  },
  {
    "code" : "4087002599",
    "display" : "Unions Of Debhata Upazila"
  },
  {
    "code" : "4087004399",
    "display" : "Unions Of Kalaroa Upazila"
  },
  {
    "code" : "4087004799",
    "display" : "Unions Of Kaliganj Upazila"
  },
  {
    "code" : "4087008299",
    "display" : "Unions Of Satkhira Sadar Upazila"
  },
  {
    "code" : "4087008699",
    "display" : "Unions Of Shyamnagar Upazila"
  },
  {
    "code" : "4087009099",
    "display" : "Unions Of Tala Upazila"
  },
  {
    "code" : "5010000699",
    "display" : "Unions Of Adamdighi Upazila"
  },
  {
    "code" : "5010002099",
    "display" : "Unions Of Bogra Sadar Upazila"
  },
  {
    "code" : "5010002799",
    "display" : "Unions Of Dhunat Upazila"
  },
  {
    "code" : "5010003399",
    "display" : "Unions Of Dhupchanchia Upazila"
  },
  {
    "code" : "5010004099",
    "display" : "Unions Of Gabtali Upazila"
  },
  {
    "code" : "5010005499",
    "display" : "Unions Of Kahaloo Upazila"
  },
  {
    "code" : "5010006799",
    "display" : "Unions Of Nandigram Upazila"
  },
  {
    "code" : "5010008199",
    "display" : "Unions Of Sariakandi Upazila"
  },
  {
    "code" : "5010008599",
    "display" : "Unions Of Shajahanpur Upazila"
  },
  {
    "code" : "5010008899",
    "display" : "Unions Of Sherpur Upazila"
  },
  {
    "code" : "5010009499",
    "display" : "Unions Of Shibganj Upazila"
  },
  {
    "code" : "5010009599",
    "display" : "Unions Of Sonatola Upazila"
  },
  {
    "code" : "5038001399",
    "display" : "Unions Of Akkelpur Upazila"
  },
  {
    "code" : "5038004799",
    "display" : "Unions Of Joypurhat Sadar Upazila"
  },
  {
    "code" : "5038005899",
    "display" : "Unions Of Kalai Upazila"
  },
  {
    "code" : "5038006199",
    "display" : "Unions Of Khetlal Upazila"
  },
  {
    "code" : "5038007499",
    "display" : "Unions Of Panchbibi Upazila"
  },
  {
    "code" : "5064000399",
    "display" : "Unions Of Atrai Upazila"
  },
  {
    "code" : "5064000699",
    "display" : "Unions Of Badalgachhi Upazila"
  },
  {
    "code" : "5064002899",
    "display" : "Unions Of Dhamoirhat Upazila"
  },
  {
    "code" : "5064004799",
    "display" : "Unions Of Manda Upazila"
  },
  {
    "code" : "5064005099",
    "display" : "Unions Of Mahadebpur Upazila"
  },
  {
    "code" : "5064006099",
    "display" : "Unions Of Naogaon Sadar Upazila"
  },
  {
    "code" : "5064006999",
    "display" : "Unions Of Niamatpur Upazila"
  },
  {
    "code" : "5064007599",
    "display" : "Unions Of Patnitala Upazila"
  },
  {
    "code" : "5064007999",
    "display" : "Unions Of Porsha Upazila"
  },
  {
    "code" : "5064008599",
    "display" : "Unions Of Raninagar Upazila"
  },
  {
    "code" : "5064008699",
    "display" : "Unions Of Sapahar Upazila"
  },
  {
    "code" : "5069000999",
    "display" : "Unions Of Bagatipara Upazila"
  },
  {
    "code" : "5069001599",
    "display" : "Unions Of Baraigram Upazila"
  },
  {
    "code" : "5069004199",
    "display" : "Unions Of Gurudaspur Upazila"
  },
  {
    "code" : "5069004499",
    "display" : "Unions Of Lalpur Upazila"
  },
  {
    "code" : "5069005599",
    "display" : "Unions Of Naldanga Upazila"
  },
  {
    "code" : "5069006399",
    "display" : "Unions Of Natore Sadar Upazila"
  },
  {
    "code" : "5069009199",
    "display" : "Unions Of Singra Upazila"
  },
  {
    "code" : "5070001899",
    "display" : "Unions Of Bholahat Upazila"
  },
  {
    "code" : "5070003799",
    "display" : "Unions Of Gomastapur Upazila"
  },
  {
    "code" : "5070005699",
    "display" : "Unions Of Nachole Upazila"
  },
  {
    "code" : "5070006699",
    "display" : "Unions Of Chapai Nababganj Sadar Upazila"
  },
  {
    "code" : "5070008899",
    "display" : "Unions Of Shibganj Upazila"
  },
  {
    "code" : "5076000599",
    "display" : "Unions Of Atgharia Upazila"
  },
  {
    "code" : "5076001699",
    "display" : "Unions Of Bera Upazila"
  },
  {
    "code" : "5076001999",
    "display" : "Unions Of Bhangura Upazila"
  },
  {
    "code" : "5076002299",
    "display" : "Unions Of Chatmohar Upazila"
  },
  {
    "code" : "5076003399",
    "display" : "Unions Of Faridpur Upazila"
  },
  {
    "code" : "5076003999",
    "display" : "Unions Of Ishwardi Upazila"
  },
  {
    "code" : "5076005599",
    "display" : "Unions Of Pabna Sadar Upazila"
  },
  {
    "code" : "5076007299",
    "display" : "Unions Of Santhia Upazila"
  },
  {
    "code" : "5076008399",
    "display" : "Unions Of Sujanagar Upazila"
  },
  {
    "code" : "5081001099",
    "display" : "Unions Of Bagha Upazila"
  },
  {
    "code" : "5081001299",
    "display" : "Unions Of Baghmara Upazila"
  },
  {
    "code" : "5081002599",
    "display" : "Unions Of Charghat Upazila"
  },
  {
    "code" : "5081003199",
    "display" : "Unions Of Durgapur Upazila"
  },
  {
    "code" : "5081003499",
    "display" : "Unions Of Godagari Upazila"
  },
  {
    "code" : "5081005399",
    "display" : "Unions Of Mohanpur Upazila"
  },
  {
    "code" : "5081007299",
    "display" : "Unions Of Paba Upazila"
  },
  {
    "code" : "5081008299",
    "display" : "Unions Of Puthia Upazila"
  },
  {
    "code" : "5081009499",
    "display" : "Unions Of Tanore Upazila"
  },
  {
    "code" : "5088001199",
    "display" : "Unions Of Belkuchi Upazila"
  },
  {
    "code" : "5088002799",
    "display" : "Unions Of Chauhali Upazila"
  },
  {
    "code" : "5088004499",
    "display" : "Unions Of Kamarkhanda Upazila"
  },
  {
    "code" : "5088005099",
    "display" : "Unions Of Kazipur Upazila"
  },
  {
    "code" : "5088006199",
    "display" : "Unions Of Royganj Upazila"
  },
  {
    "code" : "5088006799",
    "display" : "Unions Of Shahjadpur Upazila"
  },
  {
    "code" : "5088007899",
    "display" : "Unions Of Sirajganj Sadar Upazila"
  },
  {
    "code" : "5088008999",
    "display" : "Unions Of Tarash Upazila"
  },
  {
    "code" : "5088009499",
    "display" : "Unions Of Ullah Para Upazila"
  },
  {
    "code" : "5527001099",
    "display" : "Unions Of Birampur Upazila"
  },
  {
    "code" : "5527001299",
    "display" : "Unions Of Birganj Upazila"
  },
  {
    "code" : "5527001799",
    "display" : "Unions Of Biral Upazila"
  },
  {
    "code" : "5527002199",
    "display" : "Unions Of Bochaganj Upazila"
  },
  {
    "code" : "5527003099",
    "display" : "Unions Of Chirirbandar Upazila"
  },
  {
    "code" : "5527003899",
    "display" : "Unions Of Fulbari Upazila"
  },
  {
    "code" : "5527004399",
    "display" : "Unions Of Ghoraghat Upazila"
  },
  {
    "code" : "5527004799",
    "display" : "Unions Of Hakimpur Upazila"
  },
  {
    "code" : "5527005699",
    "display" : "Unions Of Kaharole Upazila"
  },
  {
    "code" : "5527006099",
    "display" : "Unions Of Khansama Upazila"
  },
  {
    "code" : "5527006499",
    "display" : "Unions Of Dinajpur Sadar Upazila"
  },
  {
    "code" : "5527006999",
    "display" : "Unions Of Nawabganj Upazila"
  },
  {
    "code" : "5527007799",
    "display" : "Unions Of Parbatipur Upazila"
  },
  {
    "code" : "5532002199",
    "display" : "Unions Of Fulchhari Upazila"
  },
  {
    "code" : "5532002499",
    "display" : "Unions Of Gaibandha Sadar Upazila"
  },
  {
    "code" : "5532003099",
    "display" : "Unions Of Gobindaganj Upazila"
  },
  {
    "code" : "5532006799",
    "display" : "Unions Of Palashbari Upazila"
  },
  {
    "code" : "5532008299",
    "display" : "Unions Of Sadullapur Upazila"
  },
  {
    "code" : "5532008899",
    "display" : "Unions Of Saghata Upazila"
  },
  {
    "code" : "5532009199",
    "display" : "Unions Of Sundarganj Upazila"
  },
  {
    "code" : "5549000699",
    "display" : "Unions Of Bhurungamari Upazila"
  },
  {
    "code" : "5549000899",
    "display" : "Unions Of Char Rajibpur Upazila"
  },
  {
    "code" : "5549000999",
    "display" : "Unions Of Chilmari Upazila"
  },
  {
    "code" : "5549001899",
    "display" : "Unions Of Phulbari Upazila"
  },
  {
    "code" : "5549005299",
    "display" : "Unions Of Kurigram Sadar Upazila"
  },
  {
    "code" : "5549006199",
    "display" : "Unions Of Nageshwari Upazila"
  },
  {
    "code" : "5549007799",
    "display" : "Unions Of Rajarhat Upazila"
  },
  {
    "code" : "5549007999",
    "display" : "Unions Of Raumari Upazila"
  },
  {
    "code" : "5549009499",
    "display" : "Unions Of Ulipur Upazila"
  },
  {
    "code" : "5552000299",
    "display" : "Unions Of Aditmari Upazila"
  },
  {
    "code" : "5552003399",
    "display" : "Unions Of Hatibandha Upazila"
  },
  {
    "code" : "5552003999",
    "display" : "Unions Of Kaliganj Upazila"
  },
  {
    "code" : "5552005599",
    "display" : "Unions Of Lalmonirhat Sadar Upazila"
  },
  {
    "code" : "5552007099",
    "display" : "Unions Of Patgram Upazila"
  },
  {
    "code" : "5573001299",
    "display" : "Unions Of Dimla Upazila"
  },
  {
    "code" : "5573001599",
    "display" : "Unions Of Domar Upazila Upazila"
  },
  {
    "code" : "5573003699",
    "display" : "Unions Of Jaldhaka Upazila"
  },
  {
    "code" : "5573004599",
    "display" : "Unions Of Kishoreganj Upazila"
  },
  {
    "code" : "5573006499",
    "display" : "Unions Of Nilphamari Sadar Upazila"
  },
  {
    "code" : "5573008599",
    "display" : "Unions Of Saidpur Upazila Upazila"
  },
  {
    "code" : "5577000499",
    "display" : "Unions Of Atwari Upazila"
  },
  {
    "code" : "5577002599",
    "display" : "Unions Of Boda Upazila"
  },
  {
    "code" : "5577003499",
    "display" : "Unions Of Debiganj Upazila"
  },
  {
    "code" : "5577007399",
    "display" : "Unions Of Panchagarh Sadar Upazila"
  },
  {
    "code" : "5577009099",
    "display" : "Unions Of Tentulia Upazila"
  },
  {
    "code" : "5585000399",
    "display" : "Unions Of Badarganj Upazila"
  },
  {
    "code" : "5585002799",
    "display" : "Unions Of Gangachara Upazila"
  },
  {
    "code" : "5585004299",
    "display" : "Unions Of Kaunia Upazila"
  },
  {
    "code" : "5585754999",
    "display" : "Unions Of Rangpur Sadar Upazila"
  },
  {
    "code" : "5585005899",
    "display" : "Unions Of Mitha Pukur Upazila"
  },
  {
    "code" : "5585007399",
    "display" : "Unions Of Pirgachha Upazila"
  },
  {
    "code" : "5585007699",
    "display" : "Unions Of Pirganj Upazila"
  },
  {
    "code" : "5585009299",
    "display" : "Unions Of Taraganj Upazila"
  },
  {
    "code" : "5594000899",
    "display" : "Unions Of Baliadangi Upazila"
  },
  {
    "code" : "5594005199",
    "display" : "Unions Of Haripur Upazila"
  },
  {
    "code" : "5594008299",
    "display" : "Unions Of Pirganj Upazila"
  },
  {
    "code" : "5594008699",
    "display" : "Unions Of Ranisankail Upazila"
  },
  {
    "code" : "5594009499",
    "display" : "Unions Of Thakurgaon Sadar Upazila"
  },
  {
    "code" : "6036000299",
    "display" : "Unions Of Ajmiriganj Upazila"
  },
  {
    "code" : "6036000599",
    "display" : "Unions Of Bahubal Upazila"
  },
  {
    "code" : "6036001199",
    "display" : "Unions Of Baniachong Upazila"
  },
  {
    "code" : "6036002699",
    "display" : "Unions Of Chunarughat Upazila"
  },
  {
    "code" : "6036004499",
    "display" : "Unions Of Habiganj Sadar Upazila"
  },
  {
    "code" : "6036006899",
    "display" : "Unions Of Lakhai Upazila"
  },
  {
    "code" : "6036007199",
    "display" : "Unions Of Madhabpur Upazila"
  },
  {
    "code" : "6036007799",
    "display" : "Unions Of Nabiganj Upazila"
  },
  {
    "code" : "6058001499",
    "display" : "Unions Of Barlekha Upazila"
  },
  {
    "code" : "6058003599",
    "display" : "Unions Of Juri Upazila"
  },
  {
    "code" : "6058005699",
    "display" : "Unions Of Kamalganj Upazila"
  },
  {
    "code" : "6058006599",
    "display" : "Unions Of Kulaura Upazila"
  },
  {
    "code" : "6058007499",
    "display" : "Unions Of Maulvibazar Sadar Upazila"
  },
  {
    "code" : "6058008099",
    "display" : "Unions Of Rajnagar Upazila"
  },
  {
    "code" : "6058008399",
    "display" : "Unions Of Sreemangal Upazila"
  },
  {
    "code" : "6090001899",
    "display" : "Unions Of Bishwambarpur Upazila"
  },
  {
    "code" : "6090002399",
    "display" : "Unions Of Chhatak Upazila"
  },
  {
    "code" : "6090008799",
    "display" : "Unions Of Dakshin Sunamganj Upazila"
  },
  {
    "code" : "6090002999",
    "display" : "Unions Of Derai Upazila"
  },
  {
    "code" : "6090003299",
    "display" : "Unions Of Dharampasha Upazila"
  },
  {
    "code" : "6090003399",
    "display" : "Unions Of Dowarabazar Upazila"
  },
  {
    "code" : "6090004799",
    "display" : "Unions Of Jagannathpur Upazila"
  },
  {
    "code" : "6090005099",
    "display" : "Unions Of Jamalganj Upazila"
  },
  {
    "code" : "6090008699",
    "display" : "Unions Of Sulla Upazila"
  },
  {
    "code" : "6090008999",
    "display" : "Unions Of Sunamganj Sadar Upazila"
  },
  {
    "code" : "6090009299",
    "display" : "Unions Of Tahirpur Upazila"
  },
  {
    "code" : "6091000899",
    "display" : "Unions Of Balaganj Upazila"
  },
  {
    "code" : "6091001799",
    "display" : "Unions Of Beani Bazar Upazila"
  },
  {
    "code" : "6091002099",
    "display" : "Unions Of Bishwanath Upazila"
  },
  {
    "code" : "6091002799",
    "display" : "Unions Of Companiganj Upazila"
  },
  {
    "code" : "6091503199",
    "display" : "Unions Of Dakshin Surma Upazila"
  },
  {
    "code" : "6091003599",
    "display" : "Unions Of Fenchuganj Upazila"
  },
  {
    "code" : "6091003899",
    "display" : "Unions Of Golapganj Upazila"
  },
  {
    "code" : "6091004199",
    "display" : "Unions Of Gowainghat Upazila"
  },
  {
    "code" : "6091005399",
    "display" : "Unions Of Jaintiapur Upazila"
  },
  {
    "code" : "6091005999",
    "display" : "Unions Of Kanaighat Upazila"
  },
  {
    "code" : "6091506299",
    "display" : "Unions Of Sylhet Sadar Upazila"
  },
  {
    "code" : "6091009499",
    "display" : "Unions Of Zakiganj Upazila"
  },
  {
    "code" : "6091006099",
    "display" : "Unions Of Osmani Nagar Upazila"
  },
  {
    "code" : "2015003999",
    "display" : "Unions of karnaphuli"
  },
  {
    "code" : "2019503399",
    "display" : "Unions of Cumilla Sadar Dakshin"
  },
  {
    "code" : "6036008705",
    "display" : "Unions of Shayestaganj"
  },
  {
    "code" : "4589009099",
    "display" : "Unions of Sreebardi Upazila"
  },
  {
    "code" : "4589009077",
    "display" : "Sreebardi Pourasabha"
  }]
}

```
