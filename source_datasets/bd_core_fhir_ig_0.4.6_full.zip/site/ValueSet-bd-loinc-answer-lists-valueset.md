# Bangladesh LOINC Answer Lists ValueSet - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh LOINC Answer Lists ValueSet**

## ValueSet: Bangladesh LOINC Answer Lists ValueSet (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/ValueSet/bd-loinc-answer-lists-valueset | *Version*:0.4.6 |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | *Computable Name*:BDLoincAnswerListsVS |
| **Copyright/Legal**: This content from LOINC® is copyright © 1995 Regenstrief Institute, Inc. and the LOINC Committee, and available at no cost under the license at http://loinc.org/terms-of-use. | |

 
LOINC answer codes (LA-prefixed) and answer list groupers (LL-prefixed) for Bangladesh laboratory results. Includes all answer codes referenced by in-scope lab result codes from LOINC 2.82. Used as Observation.valueCodeableConcept in bd-lab-result-observation for ordinal and nominal scale results. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "bd-loinc-answer-lists-valueset",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/ValueSet/bd-loinc-answer-lists-valueset",
  "version" : "0.4.6",
  "name" : "BDLoincAnswerListsVS",
  "title" : "Bangladesh LOINC Answer Lists ValueSet",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "LOINC answer codes (LA-prefixed) and answer list groupers (LL-prefixed) \nfor Bangladesh laboratory results. Includes all answer codes referenced by in-scope \nlab result codes from LOINC 2.82. Used as Observation.valueCodeableConcept in \nbd-lab-result-observation for ordinal and nominal scale results.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "immutable" : false,
  "copyright" : "This content from LOINC® is copyright © 1995 Regenstrief Institute, Inc. and the LOINC Committee, and available at no cost under the license at http://loinc.org/terms-of-use.",
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "filter" : [{
        "property" : "concept",
        "op" : "in",
        "value" : "https://fhir.dghs.gov.bd/core/ValueSet/loinc-answer-lists"
      }]
    }]
  }
}

```
