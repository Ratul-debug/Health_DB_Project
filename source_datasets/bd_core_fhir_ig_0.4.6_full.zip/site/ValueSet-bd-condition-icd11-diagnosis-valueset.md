# Bangladesh ICD-11 MMS Condition ValueSet (Diagnosis and Finding) - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh ICD-11 MMS Condition ValueSet (Diagnosis and Finding)**

## ValueSet: Bangladesh ICD-11 MMS Condition ValueSet (Diagnosis and Finding) 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/ValueSet/bd-condition-icd11-diagnosis-valueset | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDConditionICD11DiagnosisVS |
| **Copyright/Legal**: ICD-11 is copyright © World Health Organization. Used under licence. | | |

 
ICD-11 MMS concepts restricted to the Diagnosis (14,071) and Finding (5,590) concept classes, totalling 19,661 concepts as of version 2025-01. 
This ValueSet is the binding target for Condition.code in the BD-Core Condition profile. Substance, Organism, Device, Anatomy, and Misc class concepts are excluded and SHALL NOT appear as standalone stem codes in Condition.code. This restriction applies to stem codes only — satellite codes carried in the icd11-cluster-expression extension are exempt. 
This ValueSet is an empty stub. No compose block is declared because $expand is not supported by the national OCL terminology server and no machine-executable filter for concept_class is available at the IG layer. The compose would be nominal only and is omitted to avoid misrepresenting machine-executable semantics. 
The ValueSet is hosted in OCL as a collection with 19,661 explicit concept references (Diagnosis and Finding classes only). Runtime enforcement is via OCL ValueSet $validate-code: 
GET https://tr.ocl.dghs.gov.bd/api/fhir/ValueSet/$validate-code ?url=https://fhir.dghs.gov.bd/core/ValueSet/bd-condition-icd11-diagnosis-valueset &system=http://id.who.int/icd/release/11/mms &code={code} 
Confirmed behaviour: 
* Diagnosis class (e.g. 1A00): accepted
* Finding class: accepted
* Device class (e.g. XD7EB1): rejected
* Substance class (e.g. XM6RB2): rejected
 
At the HAPI FHIR layer, enforcement is via RemoteTerminologyServiceValidationSupport configured to call OCL. HAPI FHIR deployment is a known gap to be closed before vendor onboarding. 
VERSION UPGRADES: Upgrading to a new ICD-11 MMS release requires re-running populate_condition_valueset.py. Automated via version_upgrade.py. 

 **References** 

* [BD Core Condition Profile (ICD-11)](StructureDefinition-bd-condition.md)

### Logical Definition (CLD)

No formal definition provided for this value set

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "bd-condition-icd11-diagnosis-valueset",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/ValueSet/bd-condition-icd11-diagnosis-valueset",
  "version" : "0.4.6",
  "name" : "BDConditionICD11DiagnosisVS",
  "title" : "Bangladesh ICD-11 MMS Condition ValueSet (Diagnosis and Finding)",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "ICD-11 MMS concepts restricted to the Diagnosis (14,071) and Finding (5,590)\nconcept classes, totalling 19,661 concepts as of version 2025-01.\n\nThis ValueSet is the binding target for Condition.code in the BD-Core\nCondition profile. Substance, Organism, Device, Anatomy, and Misc class\nconcepts are excluded and SHALL NOT appear as standalone stem codes in\nCondition.code. This restriction applies to stem codes only — satellite\ncodes carried in the icd11-cluster-expression extension are exempt.\n\nThis ValueSet is an empty stub. No compose block is declared because\n$expand is not supported by the national OCL terminology server and\nno machine-executable filter for concept_class is available at the\nIG layer. The compose would be nominal only and is omitted to avoid\nmisrepresenting machine-executable semantics.\n\nThe ValueSet is hosted in OCL as a collection with 19,661 explicit\nconcept references (Diagnosis and Finding classes only). Runtime\nenforcement is via OCL ValueSet $validate-code:\n\n  GET https://tr.ocl.dghs.gov.bd/api/fhir/ValueSet/$validate-code\n      ?url=https://fhir.dghs.gov.bd/core/ValueSet/bd-condition-icd11-diagnosis-valueset\n      &system=http://id.who.int/icd/release/11/mms\n      &code={code}\n\nConfirmed behaviour:\n  - Diagnosis class (e.g. 1A00): accepted\n  - Finding class: accepted\n  - Device class (e.g. XD7EB1): rejected\n  - Substance class (e.g. XM6RB2): rejected\n\nAt the HAPI FHIR layer, enforcement is via RemoteTerminologyServiceValidationSupport\nconfigured to call OCL. HAPI FHIR deployment is a known gap to be closed\nbefore vendor onboarding.\n\nVERSION UPGRADES:\n  Upgrading to a new ICD-11 MMS release requires re-running\n  populate_condition_valueset.py. Automated via version_upgrade.py.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "immutable" : false,
  "copyright" : "ICD-11 is copyright © World Health Organization. Used under licence."
}

```
