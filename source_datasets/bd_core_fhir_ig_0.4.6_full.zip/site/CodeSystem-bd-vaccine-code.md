# Bangladesh Vaccine Code System - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh Vaccine Code System**

## CodeSystem: Bangladesh Vaccine Code System 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/CodeSystem/bd-vaccine-code | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDVaccineCS |

 
Vaccine codes used in Bangladesh EPI and immunization program. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [BDVaccineVS](ValueSet-bd-vaccine-valueset.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "bd-vaccine-code",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-vaccine-code",
  "version" : "0.4.6",
  "name" : "BDVaccineCS",
  "title" : "Bangladesh Vaccine Code System",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Vaccine codes used in Bangladesh EPI and immunization program.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 10,
  "concept" : [{
    "code" : "BCG",
    "display" : "BCG Vaccine",
    "definition" : "Bacillus Calmette-Guérin vaccine, used against tuberculosis."
  },
  {
    "code" : "OPV",
    "display" : "Oral Polio Vaccine (OPV)",
    "definition" : "Live attenuated oral polio vaccine."
  },
  {
    "code" : "IPV",
    "display" : "Inactivated Polio Vaccine (IPV)",
    "definition" : "Inactivated polio vaccine."
  },
  {
    "code" : "PENTA",
    "display" : "Pentavalent Vaccine",
    "definition" : "DTP-HepB-Hib combined vaccine."
  },
  {
    "code" : "MR",
    "display" : "Measles-Rubella (MR) Vaccine",
    "definition" : "Combined measles and rubella vaccine."
  },
  {
    "code" : "TT",
    "display" : "Tetanus Toxoid (TT) Vaccine",
    "definition" : "Vaccine used for tetanus prevention."
  },
  {
    "code" : "PCV10",
    "display" : "Pneumococcal Conjugate Vaccine",
    "definition" : "10-valent pneumococcal conjugate vaccine."
  },
  {
    "code" : "ROTA",
    "display" : "Rotavirus Vaccine",
    "definition" : "Live attenuated rotavirus vaccine for diarrheal disease prevention."
  },
  {
    "code" : "HPV",
    "display" : "Human Papillomavirus (HPV) Vaccine",
    "definition" : "Vaccine used for prevention of cervical cancer and HPV-related diseases."
  },
  {
    "code" : "COVID19",
    "display" : "COVID-19 Vaccine",
    "definition" : "Vaccines against SARS-CoV-2 (various manufacturers)."
  }]
}

```
