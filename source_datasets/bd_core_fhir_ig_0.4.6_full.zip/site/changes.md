# IG Change History - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* **IG Change History**

## IG Change History

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

 This provides a list of changes to the MyIG specification since its initial release 

 **2099-01-01 v0.1.0 - My IG R1 (STU ballot 1) Ballot Candidate** based on FHIR R4 

* Initial version

