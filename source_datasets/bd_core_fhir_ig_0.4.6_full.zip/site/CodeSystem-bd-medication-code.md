# Bangladesh Medication Codes - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh Medication Codes**

## CodeSystem: Bangladesh Medication Codes 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/CodeSystem/bd-medication-code | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDMedicationCS |

 
Bangladesh Medication Codes 

 This Code system is referenced in the content logical definition of the following value sets: 

* [BDMedicationVS](ValueSet-bd-medication-valueset.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "bd-medication-code",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-medication-code",
  "version" : "0.4.6",
  "name" : "BDMedicationCS",
  "title" : "Bangladesh Medication Codes",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Bangladesh Medication Codes",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 6,
  "concept" : [{
    "code" : "394-0010-030",
    "display" : "Tubutol",
    "definition" : "Ethambutol"
  },
  {
    "code" : "394-0011-030",
    "display" : "AFDCDT-2",
    "definition" : "Isoniazid + Rifampicin"
  },
  {
    "code" : "394-0012-030",
    "display" : "AFDCDT-3",
    "definition" : "Isoniazid + Pyrazinamide + Rifampicin"
  },
  {
    "code" : "394-0017-046",
    "display" : "Levetiracetam 250",
    "definition" : "Levetiracetam"
  },
  {
    "code" : "394-0021-028",
    "display" : "Donepezil Hydrochloride 5",
    "definition" : "Donepezil Hydrochloride"
  },
  {
    "code" : "355-0065-023",
    "display" : "Cefufine",
    "definition" : "Cefuroxime"
  }]
}

```
