# Patient Profile for Bangladesh - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient Profile for Bangladesh**

## Resource Profile: Patient Profile for Bangladesh 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/StructureDefinition/bd-patient | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDPatient |

 
Patient profile for Bangladesh. 
* Identifiers: NID, BRN, UHID
* Name must be provided in both Bangla and English.
* SHALL have at least one RelatedPerson with relationship = father or mother, and that RelatedPerson SHALL include both a name and an identifier.
 

**Usages:**

* Refer to this Profile: [Immunization Profile for Bangladesh](StructureDefinition-bd-immunization.md), [Medication Request Profile for Bangladesh](StructureDefinition-bd-medication-request.md) and [Related Person Profile for Bangladesh](StructureDefinition-bd-related-person.md)
* Examples for this Profile: [Patient/BDPatientExample](Patient-BDPatientExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/bd.fhir.core|current/StructureDefinition/bd-patient)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-bd-patient.csv), [Excel](StructureDefinition-bd-patient.xlsx), [Schematron](StructureDefinition-bd-patient.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "bd-patient",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-patient",
  "version" : "0.4.6",
  "name" : "BDPatient",
  "title" : "Patient Profile for Bangladesh",
  "status" : "draft",
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Patient profile for Bangladesh.  \n- Identifiers: NID, BRN, UHID  \n- Name must be provided in both Bangla and English.  \n- SHALL have at least one RelatedPerson with relationship = father or mother, and that RelatedPerson SHALL include both a name and an identifier.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "loinc",
    "uri" : "http://loinc.org",
    "name" : "LOINC code for the element"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Patient",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Patient",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Patient",
      "path" : "Patient"
    },
    {
      "id" : "Patient.extension",
      "path" : "Patient.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Patient.extension:religion",
      "path" : "Patient.extension",
      "sliceName" : "religion",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/patient-religion"]
      }]
    },
    {
      "id" : "Patient.extension:religion.value[x]",
      "path" : "Patient.extension.value[x]",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.dghs.gov.bd/core/ValueSet/bd-religions-valueset"
      }
    },
    {
      "id" : "Patient.identifier",
      "path" : "Patient.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "system"
        }],
        "description" : "Slice based on the type of identifier.",
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Patient.identifier:NID",
      "path" : "Patient.identifier",
      "sliceName" : "NID",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Patient.identifier:NID.type",
      "path" : "Patient.identifier.type",
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "https://fhir.dghs.gov.bd/core/ValueSet/bd-identifier-type-valueset"
      }
    },
    {
      "id" : "Patient.identifier:NID.type.coding.system",
      "path" : "Patient.identifier.type.coding.system",
      "patternUri" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-identifier-type"
    },
    {
      "id" : "Patient.identifier:NID.type.coding.code",
      "path" : "Patient.identifier.type.coding.code",
      "patternCode" : "NID"
    },
    {
      "id" : "Patient.identifier:NID.type.text",
      "path" : "Patient.identifier.type.text",
      "patternString" : "Organization identifier"
    },
    {
      "id" : "Patient.identifier:NID.system",
      "path" : "Patient.identifier.system",
      "min" : 1,
      "patternUri" : "http://dghs.gov.bd/identifier/nid"
    },
    {
      "id" : "Patient.identifier:BRN",
      "path" : "Patient.identifier",
      "sliceName" : "BRN",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Patient.identifier:BRN.type",
      "path" : "Patient.identifier.type",
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "https://fhir.dghs.gov.bd/core/ValueSet/bd-identifier-type-valueset"
      }
    },
    {
      "id" : "Patient.identifier:BRN.type.coding.system",
      "path" : "Patient.identifier.type.coding.system",
      "patternUri" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-identifier-type"
    },
    {
      "id" : "Patient.identifier:BRN.type.coding.code",
      "path" : "Patient.identifier.type.coding.code",
      "patternCode" : "BRN"
    },
    {
      "id" : "Patient.identifier:BRN.type.text",
      "path" : "Patient.identifier.type.text",
      "patternString" : "Organization identifier"
    },
    {
      "id" : "Patient.identifier:BRN.system",
      "path" : "Patient.identifier.system",
      "min" : 1,
      "patternUri" : "http://dghs.gov.bd/identifier/brn"
    },
    {
      "id" : "Patient.identifier:UHID",
      "path" : "Patient.identifier",
      "sliceName" : "UHID",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Patient.identifier:UHID.type",
      "path" : "Patient.identifier.type",
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "https://fhir.dghs.gov.bd/core/ValueSet/bd-identifier-type-valueset"
      }
    },
    {
      "id" : "Patient.identifier:UHID.type.coding.system",
      "path" : "Patient.identifier.type.coding.system",
      "patternUri" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-identifier-type"
    },
    {
      "id" : "Patient.identifier:UHID.type.coding.code",
      "path" : "Patient.identifier.type.coding.code",
      "patternCode" : "UHID"
    },
    {
      "id" : "Patient.identifier:UHID.type.text",
      "path" : "Patient.identifier.type.text",
      "patternString" : "Organization identifier"
    },
    {
      "id" : "Patient.identifier:UHID.system",
      "path" : "Patient.identifier.system",
      "min" : 1,
      "patternUri" : "http://dghs.gov.bd/identifier/uhid"
    },
    {
      "id" : "Patient.name",
      "path" : "Patient.name",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Patient.name.use",
      "path" : "Patient.name.use",
      "min" : 1,
      "fixedCode" : "official"
    },
    {
      "id" : "Patient.name.text",
      "path" : "Patient.name.text",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Patient.name.text.extension",
      "path" : "Patient.name.text.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Patient.name.text.extension:nameEn",
      "path" : "Patient.name.text.extension",
      "sliceName" : "nameEn",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-name-en"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.name.text.extension:nameBn",
      "path" : "Patient.name.text.extension",
      "sliceName" : "nameBn",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-name-bn"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.gender",
      "path" : "Patient.gender",
      "min" : 1
    },
    {
      "id" : "Patient.birthDate",
      "path" : "Patient.birthDate",
      "comment" : "If exact date of birth is partially or completely unknown, Implementers SHALL populate this element with the date of birth information listed on the patient's government-issued identification."
    },
    {
      "id" : "Patient.deceased[x]",
      "path" : "Patient.deceased[x]",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "Patient.address",
      "path" : "Patient.address",
      "min" : 1,
      "type" : [{
        "code" : "Address",
        "profile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-address"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.maritalStatus",
      "path" : "Patient.maritalStatus",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.dghs.gov.bd/core/ValueSet/bd-marital-status-valueset"
      }
    },
    {
      "id" : "Patient.photo",
      "path" : "Patient.photo",
      "definition" : "Patient photo for identity verification",
      "comment" : "Attach a photo of the patient when available. Use image/jpeg or image/png.",
      "mustSupport" : true
    },
    {
      "id" : "Patient.link",
      "path" : "Patient.link",
      "definition" : "Link to a RelatedPerson resource representing father, mother, or guardian",
      "comment" : "At least one RelatedPerson with BD identifier and relationship is required.",
      "mustSupport" : true
    },
    {
      "id" : "Patient.link.other",
      "path" : "Patient.link.other",
      "type" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-hierarchy",
          "valueBoolean" : false
        }],
        "code" : "Reference",
        "targetProfile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-related-person"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.link.type",
      "path" : "Patient.link.type",
      "fixedCode" : "seealso"
    }]
  }
}

```
