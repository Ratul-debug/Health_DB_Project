# Medication Dose Form Value Set - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medication Dose Form Value Set**

## ValueSet: Medication Dose Form Value Set 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/ValueSet/edqm-dose-forms | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDMedicationDoseFormVS |

 
Value set containing pharmaceutical dose form concepts from the European Directorate for the Quality of Medicines (EDQM) Standard Terms, domain: Pharmaceutical Dose Forms (PDF). 
This value set is used to code the physical form of a medication product in BDMedication.form. EDQM Standard Terms are maintained and versioned by the Council of Europe and are the WHO-recommended international standard for pharmaceutical dose form coding. 
Concepts are loaded into the national OCL terminology server at https://tr.ocl.dghs.gov.bd under the MoHFW organisation as source EDQM-PDF. 
**Binding:** preferred on BDMedication.form — systems should use EDQM codes when populating dose form, but omission is permitted. A mapping from DGDA plain text dose forms to EDQM codes is planned for a future IG version. 
**Code system canonical:** https://standardterms.edqm.eu **OCL source:** https://tr.ocl.dghs.gov.bd/#/orgs/MoHFW/sources/EDQM-PDF/ 

 **References** 

* [Medication Profile for Bangladesh](StructureDefinition-bd-medication.md)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (Unknown Code System)

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "bd-medication-dose-form",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/ValueSet/edqm-dose-forms",
  "version" : "0.4.6",
  "name" : "BDMedicationDoseFormVS",
  "title" : "Medication Dose Form Value Set",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Value set containing pharmaceutical dose form concepts from the European\nDirectorate for the Quality of Medicines (EDQM) Standard Terms, domain:\nPharmaceutical Dose Forms (PDF).\n\nThis value set is used to code the physical form of a medication product\nin BDMedication.form. EDQM Standard Terms are maintained and versioned\nby the Council of Europe and are the WHO-recommended international standard\nfor pharmaceutical dose form coding.\n\nConcepts are loaded into the national OCL terminology server at\nhttps://tr.ocl.dghs.gov.bd under the MoHFW organisation as source EDQM-PDF.\n\n**Binding:** preferred on BDMedication.form — systems should use EDQM\ncodes when populating dose form, but omission is permitted. A mapping from\nDGDA plain text dose forms to EDQM codes is planned for a future IG version.\n\n**Code system canonical:** https://standardterms.edqm.eu\n**OCL source:** https://tr.ocl.dghs.gov.bd/#/orgs/MoHFW/sources/EDQM-PDF/",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "immutable" : false,
  "compose" : {
    "include" : [{
      "system" : "https://standardterms.edqm.eu"
    }]
  }
}

```
