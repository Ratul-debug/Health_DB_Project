# Dhaka Medical College Hospital - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Dhaka Medical College Hospital**

## Example Organization: Dhaka Medical College Hospital

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

-------

**English**

-------

Profile: [Organization for Bangladesh](StructureDefinition-bd-organization.md)

**identifier**: Facility ID/10000033

**name**: Dhaka Medical College Hospital

**address**: 100 Ramna Dhaka BD 

-------

**German**

-------

Profile: [Organization for Bangladesh](StructureDefinition-bd-organization.md)

**identifier**: Facility ID/10000033

**name**: Dhaka Medical College Hospital

**address**: 100 Ramna Dhaka BD 

-------

**French**

-------

Profil: [Organization for Bangladesh](StructureDefinition-bd-organization.md)

**identifier**: Facility ID/10000033

**name**: Dhaka Medical College Hospital

**address**: 100 Ramna Dhaka BD 



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "BDOrganizationExample",
  "meta" : {
    "profile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-organization"]
  },
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "FI",
        "display" : "Facility ID"
      }]
    },
    "system" : "http://hrm.dghs.gov.bd/facilities/code",
    "value" : "10000033"
  }],
  "name" : "Dhaka Medical College Hospital",
  "address" : [{
    "extension" : [{
      "url" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-division",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-geocodes",
          "code" : "30",
          "display" : "Dhaka"
        }]
      }
    }],
    "line" : ["100 Ramna"],
    "city" : "Dhaka",
    "district" : "Dhaka",
    "country" : "BD"
  }]
}

```
