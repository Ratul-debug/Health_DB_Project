# ICD-11 Mortality and Morbidity Statistics (MMS) - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ICD-11 Mortality and Morbidity Statistics (MMS)**

## CodeSystem: ICD-11 Mortality and Morbidity Statistics (MMS) 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://id.who.int/icd/release/11/mms | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:ICD11MMSCS |
| **Copyright/Legal**: ICD-11 is copyright © World Health Organization. Used under licence. | | |

 
WHO ICD-11 Mortality and Morbidity Statistics linearization. Canonical system URI: http://id.who.int/icd/release/11/mms 
This CodeSystem is declared as a stub (content = #not-present). The authoritative content is maintained by the World Health Organization. In Bangladesh, runtime code validation and lookup are delegated to the national OCL terminology server at https://tr.ocl.dghs.gov.bd. 
Supported operations (use system= parameter, not url=): 
* $validate-code: https://tr.ocl.dghs.gov.bd/api/fhir/CodeSystem/$validate-code?system=http://id.who.int/icd/release/11/mms&code={code}
* $lookup: https://tr.ocl.dghs.gov.bd/api/fhir/CodeSystem/$lookup?system=http://id.who.int/icd/release/11/mms&code={code}
 
$expand is not supported — known OCL limitation. Expansion must not be attempted at build time or by IG Publisher. 
Preferred code form: short stem codes (e.g. 1A00, NC72.Z). Linearization URIs are not used as code identifiers in this IG. 
Version 2025-01 is imported into OCL with 36,941 concepts across the following concept classes: Diagnosis, Finding, Substance, Organism, Device, Anatomy, Misc. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [BDICD11SubstancesVS](ValueSet-icd11-substances-valueset.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "icd11-mms",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "http://id.who.int/icd/release/11/mms",
  "version" : "0.4.6",
  "name" : "ICD11MMSCS",
  "title" : "ICD-11 Mortality and Morbidity Statistics (MMS)",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "WHO ICD-11 Mortality and Morbidity Statistics linearization.\nCanonical system URI: http://id.who.int/icd/release/11/mms\n\nThis CodeSystem is declared as a stub (content = #not-present).\nThe authoritative content is maintained by the World Health Organization.\nIn Bangladesh, runtime code validation and lookup are delegated to the\nnational OCL terminology server at https://tr.ocl.dghs.gov.bd.\n\nSupported operations (use system= parameter, not url=):\n  - $validate-code: https://tr.ocl.dghs.gov.bd/api/fhir/CodeSystem/$validate-code?system=http://id.who.int/icd/release/11/mms&code={code}\n  - $lookup:        https://tr.ocl.dghs.gov.bd/api/fhir/CodeSystem/$lookup?system=http://id.who.int/icd/release/11/mms&code={code}\n\n$expand is not supported — known OCL limitation. Expansion must not be\nattempted at build time or by IG Publisher.\n\nPreferred code form: short stem codes (e.g. 1A00, NC72.Z).\nLinearization URIs are not used as code identifiers in this IG.\n\nVersion 2025-01 is imported into OCL with 36,941 concepts across\nthe following concept classes: Diagnosis, Finding, Substance, Organism,\nDevice, Anatomy, Misc.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "copyright" : "ICD-11 is copyright © World Health Organization. Used under licence.",
  "caseSensitive" : true,
  "content" : "not-present",
  "count" : 36941
}

```
