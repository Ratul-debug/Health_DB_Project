# Bangladesh Occupations - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh Occupations**

## CodeSystem: Bangladesh Occupations 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/CodeSystem/bd-occupations | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDOccupationsCS |

 
Occupations code system according to CCDS guideline 

 This Code system is referenced in the content logical definition of the following value sets: 

* [BDOccupationsVS](ValueSet-bd-occupations-valueset.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "bd-occupations",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-occupations",
  "version" : "0.4.6",
  "name" : "BDOccupationsCS",
  "title" : "Bangladesh Occupations",
  "status" : "draft",
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Occupations code system according to CCDS guideline",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "content" : "complete",
  "count" : 71,
  "concept" : [{
    "code" : "1",
    "display" : "Physical Scientists & Related Technicians",
    "definition" : "ভৌত বিজ্ঞানী ও এতদসংক্রান্ত টেকনিশিয়ান"
  },
  {
    "code" : "2",
    "display" : "Engineering and Architects",
    "definition" : "ইঞ্জিয়ারিং ও স্থপতি"
  },
  {
    "code" : "3",
    "display" : "Engineering and Architect-related Technicians",
    "definition" : "ইঞ্জিয়ারিং ও স্থপতি সম্পর্কিত টেকনিশিয়ান"
  },
  {
    "code" : "4",
    "display" : "Officers of Aircraft and Ship",
    "definition" : "বিমান ও জাহাজের কর্মকর্তা"
  },
  {
    "code" : "5",
    "display" : "Biologists and Related Technicians",
    "definition" : "জীববিজ্ঞানী ও এতদসংক্রান্ত টেকনিশিয়ান"
  },
  {
    "code" : "6",
    "display" : "Physicians, Dentists, and Veterinarians",
    "definition" : "চিকিৎসক, দন্ত চিকিৎসক ও পশু চিকিৎসক"
  },
  {
    "code" : "7",
    "display" : "Nurses and Other Medical Staffs",
    "definition" : "নার্স ও চিকিৎসক সংক্রান্ত অন্যান্য কর্মী"
  },
  {
    "code" : "8",
    "display" : "Statisticians, Mathematicians, System Analysts, and Related Staff",
    "definition" : "পরিসংখ্যানবিদ, গণিতবিদ, সিস্টেম এনালিস্ট ও এতদসংক্রান্ত কর্মী"
  },
  {
    "code" : "9",
    "display" : "Economists",
    "definition" : "অর্থনীতিবিদ"
  },
  {
    "code" : "10",
    "display" : "Accountants",
    "definition" : "হিসাবরক্ষক"
  },
  {
    "code" : "12",
    "display" : "Judges",
    "definition" : "বিচারক"
  },
  {
    "code" : "13",
    "display" : "Teachers",
    "definition" : "শিক্ষক"
  },
  {
    "code" : "14",
    "display" : "Religious Workers",
    "definition" : "ধর্মীয় কর্মী"
  },
  {
    "code" : "15",
    "display" : "Writers, Journalists, and Related Staffs",
    "definition" : "লেখক, সাংবাদিক ও এতদসম্পর্কিত কর্মী"
  },
  {
    "code" : "16",
    "display" : "Painters, Photographers, and Other Creative Artists",
    "definition" : "চিত্রশিল্পী, ফটোগ্রাফার ও এতদসংক্রান্ত সৃজনশীল শিল্পী"
  },
  {
    "code" : "17",
    "display" : "Actors, Singers, and Dancers",
    "definition" : "অভিনয়, কণ্ঠশিল্পী ও নৃত্যশিল্পী"
  },
  {
    "code" : "18",
    "display" : "Sportspersons and Related Staffs",
    "definition" : "খেলোয়াড় এবং এতদসম্পর্কিত কর্মী"
  },
  {
    "code" : "19",
    "display" : "Professional, Technical, and Other Related Workers (not elsewhere classified)",
    "definition" : "পেশাগত, কারিগরি ও অন্যান্য অশ্রেণীভুক্ত এতদসম্পর্কিত কর্মী"
  },
  {
    "code" : "20",
    "display" : "Lawyers",
    "definition" : "আইনজীবী"
  },
  {
    "code" : "21",
    "display" : "Managers",
    "definition" : "ম্যানেজার"
  },
  {
    "code" : "30",
    "display" : "Government Executive Officers",
    "definition" : "সরকারি নির্বাহী কর্মকর্তা"
  },
  {
    "code" : "31",
    "display" : "Clerks",
    "definition" : "করণিক (কেরানী)"
  },
  {
    "code" : "32",
    "display" : "Typists, Stenographers and Computer Operators",
    "definition" : "টাইপিস্ট/স্টেনোগ্রাফার/কম্পিউটার অপারেটর"
  },
  {
    "code" : "33",
    "display" : "Record Keepers, Cahiers and Related Staffs",
    "definition" : "রেকর্ড কিপার, ক্যাশিয়ার ও এতদসম্পর্কিত কর্মী"
  },
  {
    "code" : "34",
    "display" : "Computer Professionals and Associate Staffs",
    "definition" : "কম্পিউটার সম্পর্কিত কর্মী"
  },
  {
    "code" : "35",
    "display" : "Transport and Communication Supervisors",
    "definition" : "যানবাহন ও যোগাযোগ তত্ত্বাবধায়ক"
  },
  {
    "code" : "36",
    "display" : "Drivers and Conductors (Mechanical and Manual)",
    "definition" : "গাড়িচালক ও কন্টাক্টর (যান্ত্রিক ও কায়িক)"
  },
  {
    "code" : "37",
    "display" : "Mail Carriers / Postmen",
    "definition" : "চিঠিপত্র বিলি (ডাক পিয়ন)"
  },
  {
    "code" : "38",
    "display" : "Telephone and Telegraph Operators",
    "definition" : "টেলিফোন ও টেলিগ্রাফ অপারেটর"
  },
  {
    "code" : "39",
    "display" : "Clerical Work, Not Elsewhere Classified",
    "definition" : "অশ্রেণীভুক্ত দাপ্তরিক কাজ"
  },
  {
    "code" : "40",
    "display" : "Managers in Wholesale and Retail Trade",
    "definition" : "ম্যানেজার (পাইকারি ও খুচরা ব্যাবসা)"
  },
  {
    "code" : "42",
    "display" : "Sales Supervisors",
    "definition" : "বিক্রয় তত্ত্বাবধায়ক"
  },
  {
    "code" : "43",
    "display" : "Travel Attendants and Related Workers",
    "definition" : "ভ্রমণ সংক্রান্ত কাজে নিয়োজিত কর্মী"
  },
  {
    "code" : "44",
    "display" : "Salespersons in Insurance, Real Estate, Business, and Related Services",
    "definition" : "বীমা, রিয়েল এস্টেট, ব্যাবসা এবং এতদসংক্রান্ত সেবা বিক্রেতা"
  },
  {
    "code" : "45",
    "display" : "Street and Market Salespersons",
    "definition" : "ফেরিওয়ালা"
  },
  {
    "code" : "46",
    "display" : "Sales Workers, Not Elsewhere Classified",
    "definition" : "অশ্রেণীভুক্ত বিক্রয়কর্মী"
  },
  {
    "code" : "50",
    "display" : "Hotel and Lodging Managers",
    "definition" : "আবাসিক হোটেল ম্যানেজার"
  },
  {
    "code" : "51",
    "display" : "Hotel Proprietors",
    "definition" : "হোটেল মালিক"
  },
  {
    "code" : "52",
    "display" : "Residential Hotel Supervisors",
    "definition" : "আবাসিক হোটেল তত্ত্বাবধায়ক"
  },
  {
    "code" : "53",
    "display" : "Cooks, Waiters, and Related Hotel Workers",
    "definition" : "বাবুর্চি, হোটেল বয় ও এতদসম্পর্কিত কর্মী"
  },
  {
    "code" : "54",
    "display" : "Unclassified Housemaids",
    "definition" : "অশ্রেণীভুক্ত গৃহ পরিচারিকা"
  },
  {
    "code" : "55",
    "display" : "Caretakers, Janitors, and Related Domestic Workers",
    "definition" : "বাড়ির কেয়ারটেকার, ঝাড়ুদার ও এতদসম্পর্কিত কর্মী"
  },
  {
    "code" : "56",
    "display" : "Laundry Workers",
    "definition" : "ধোপা"
  },
  {
    "code" : "58",
    "display" : "Security Guards",
    "definition" : "নিরাপত্তা কর্মী"
  },
  {
    "code" : "59",
    "display" : "Unclassified Service Workers",
    "definition" : "অশ্রেণীভুক্ত সেবা কর্মী"
  },
  {
    "code" : "60",
    "display" : "Agricultural Farm Managers and Supervisors",
    "definition" : "কৃষিখামার ব্যবস্থাপক ও তত্ত্বাবধায়ক"
  },
  {
    "code" : "61",
    "display" : "Crop and Livestock Farmers",
    "definition" : "কৃষিকাজ"
  },
  {
    "code" : "63",
    "display" : "Forestry Workers",
    "definition" : "বন কর্মী"
  },
  {
    "code" : "64",
    "display" : "Fishers, Hunters, and Related Workers",
    "definition" : "জেলে, শিকারি ও এতদসম্পর্কিত কর্মী"
  },
  {
    "code" : "70",
    "display" : "Production Supervisors and Foremen",
    "definition" : "উৎপাদন তত্ত্বাবধায়ক ও ফোরম্যান"
  },
  {
    "code" : "71",
    "display" : "Miners and Quarry Workers",
    "definition" : "খননকর্মী ও খননকারী"
  },
  {
    "code" : "72",
    "display" : "Metal Processing and Finishing Workers",
    "definition" : "ধাতু প্রক্রিয়াকারী"
  },
  {
    "code" : "74",
    "display" : "Chemical Products Processing Workers",
    "definition" : "রাসায়নিক দ্রব্য প্রক্রিয়াকারী"
  },
  {
    "code" : "75",
    "display" : "Weavers, Knitters, Dyers, and Related Textile Workers",
    "definition" : "তাঁতী, কাপড় বোনা ও রং করা"
  },
  {
    "code" : "76",
    "display" : "Tanners and Leather Processing Workers",
    "definition" : "চামড়া প্রক্রিয়াকারী"
  },
  {
    "code" : "77",
    "display" : "Food and Beverage Processing Plant Operators",
    "definition" : "খাদ্য ও পানীয় প্রক্রিয়াকারী"
  },
  {
    "code" : "78",
    "display" : "Tobacco Preparers and Tobacco Processing Workers",
    "definition" : "তামাক প্রক্রিয়াকারী"
  },
  {
    "code" : "79",
    "display" : "Tailors, Dressmakers, and Sewing Workers",
    "definition" : "দর্জি ও অন্যান্য সেলাই কর্মী"
  },
  {
    "code" : "80",
    "display" : "Footwear and Leather Goods Makers",
    "definition" : "জুতা ও চামড়াজাত দ্রব্য প্রস্তুতকারী"
  },
  {
    "code" : "81",
    "display" : "Carpenters",
    "definition" : "কাঠমিস্ত্রি"
  },
  {
    "code" : "82",
    "display" : "Stone Cutters and Processing Workers",
    "definition" : "পাথর কাটা ও প্রক্রিয়াকারী"
  },
  {
    "code" : "83",
    "display" : "Blacksmiths, Toolmakers, and Related Trades Workers",
    "definition" : "কর্মকার, ঢালাইকর্মী ও যন্ত্রাংশ প্রস্তুতকারী"
  },
  {
    "code" : "84",
    "display" : "Non-Electrical Machine Operators",
    "definition" : "বৈদ্যুতিক ব্যতীত অন্যান্য মেশিনকর্মী"
  },
  {
    "code" : "85",
    "display" : "Electricians",
    "definition" : "বৈদ্যুতিক কর্মী"
  },
  {
    "code" : "86",
    "display" : "Broadcasting and Audio-Visual Technicians",
    "definition" : "শব্দ প্রচার কর্মী ও চলচ্চিত্র প্রদর্শনকারী"
  },
  {
    "code" : "87",
    "display" : "Water and Sewerage Construction Workers and Welders",
    "definition" : "পানি ও পয়োঃ নিষ্কাশন কাঠামো নির্মাণকারী ও ধাতু ঝালাইকারী"
  },
  {
    "code" : "88",
    "display" : "Jewellery and Precious Metal Workers",
    "definition" : "স্বর্ণকার"
  },
  {
    "code" : "89",
    "display" : "Glass, Pottery, and Related Trades Workers",
    "definition" : "গ্লাস ও মাটির জিনিস প্রস্তুতকারী"
  },
  {
    "code" : "90",
    "display" : "Rubber and Plastic Products Makers",
    "definition" : "রাবার ও প্লাস্টিক দ্রব্য প্রস্তুতকারী"
  },
  {
    "code" : "91",
    "display" : "Paper and Paperboard Products Workers",
    "definition" : "কাগজ ও কাগজের বোর্ড প্রস্তুতকারী"
  },
  {
    "code" : "92",
    "display" : "Printers and Related Workers",
    "definition" : "মুদ্রণকাজ"
  }]
}

```
