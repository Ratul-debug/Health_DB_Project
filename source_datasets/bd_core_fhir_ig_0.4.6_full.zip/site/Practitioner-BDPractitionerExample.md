# Example Practitioner - BDPractitionerExample - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example Practitioner - BDPractitionerExample**

## Example Practitioner: Example Practitioner - BDPractitionerExample

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

-------

**English**

-------

Profile: [Practitioner for Bangladesh](StructureDefinition-bd-practitioner.md)

**identifier**: Medical License number/A-12345

**name**: Tanvir Ahmed (Official)

**telecom**: [+8801712345678](tel:+8801712345678)

**gender**: Male

-------

**German**

-------

Profile: [Practitioner for Bangladesh](StructureDefinition-bd-practitioner.md)

**identifier**: Medical License number/A-12345

**name**: Tanvir Ahmed (Official)

**telecom**: [+8801712345678](tel:+8801712345678)

**gender**: Male

-------

**French**

-------

Profil: [Practitioner for Bangladesh](StructureDefinition-bd-practitioner.md)

**identifier**: Medical License number/A-12345

**name**: Tanvir Ahmed (Official)

**telecom**: [+8801712345678](tel:+8801712345678)

**gender**: Male



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "BDPractitionerExample",
  "meta" : {
    "profile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-practitioner"]
  },
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "MD",
        "display" : "Medical License number"
      }]
    },
    "system" : "https://fhir.dghs.gov.bd/core/identifier/bmdc-registration",
    "value" : "A-12345"
  }],
  "name" : [{
    "use" : "official",
    "family" : "Ahmed",
    "given" : ["Tanvir"],
    "prefix" : ["Dr."]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "+8801712345678",
    "use" : "work"
  }],
  "gender" : "male"
}

```
