# Bangladesh Medication Dose Form CodeSystem - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh Medication Dose Form CodeSystem**

## CodeSystem: Bangladesh Medication Dose Form CodeSystem 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/CodeSystem/bd-dose-form | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDMedicationDoseForm |

 
Medication dose form codes according to CCDS guideline 

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "bd-dose-form",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-dose-form",
  "version" : "0.4.6",
  "name" : "BDMedicationDoseForm",
  "title" : "Bangladesh Medication Dose Form CodeSystem",
  "status" : "draft",
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Medication dose form codes according to CCDS guideline",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "content" : "complete",
  "count" : 10,
  "concept" : [{
    "code" : "TAB",
    "display" : "Tablet",
    "definition" : "Solid oral dosage form, usually uncoated or coated, intended for swallowing."
  },
  {
    "code" : "DTAB",
    "display" : "Dispersible Tablet",
    "definition" : "Tablet designed to be dissolved/dispersed in water before administration."
  },
  {
    "code" : "CAP",
    "display" : "Capsule",
    "definition" : "Solid dosage form with active ingredients enclosed in a gelatin shell."
  },
  {
    "code" : "SYP",
    "display" : "Syrup",
    "definition" : "Liquid oral dosage form containing active substance(s) in solution."
  },
  {
    "code" : "SUSP",
    "display" : "Suspension",
    "definition" : "Liquid oral dosage form with insoluble particles dispersed in a liquid."
  },
  {
    "code" : "PFS",
    "display" : "Powder for Suspension",
    "definition" : "Powder that requires reconstitution into a liquid suspension before use."
  },
  {
    "code" : "INJ",
    "display" : "Injection",
    "definition" : "Sterile solution or suspension intended for parenteral administration."
  },
  {
    "code" : "SOL",
    "display" : "Solution",
    "definition" : "Liquid dosage form where drug is fully dissolved in a solvent."
  },
  {
    "code" : "CRM",
    "display" : "Cream",
    "definition" : "Semi-solid topical dosage form containing the drug in an emulsion base."
  },
  {
    "code" : "LOT",
    "display" : "Lotion",
    "definition" : "Low-viscosity liquid topical dosage form for external application."
  }]
}

```
