# Bangladesh Immunization Reaction Code System - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh Immunization Reaction Code System**

## CodeSystem: Bangladesh Immunization Reaction Code System 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/CodeSystem/bd-immunization-reaction | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDImmunizationReactionCS |

 
Codes for adverse reactions after vaccination in Bangladesh. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [BDImmunizationReactionValueSet](ValueSet-bd-immunization-reaction-valueset.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "bd-immunization-reaction",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-immunization-reaction",
  "version" : "0.4.6",
  "name" : "BDImmunizationReactionCS",
  "title" : "Bangladesh Immunization Reaction Code System",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Codes for adverse reactions after vaccination in Bangladesh.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 6,
  "concept" : [{
    "code" : "NONE",
    "display" : "No Reaction",
    "definition" : "No adverse reaction observed after vaccination."
  },
  {
    "code" : "FEVER",
    "display" : "Fever",
    "definition" : "Elevated body temperature following vaccination."
  },
  {
    "code" : "SWELLING",
    "display" : "Swelling",
    "definition" : "Local swelling at the injection site."
  },
  {
    "code" : "RASH",
    "display" : "Rash",
    "definition" : "Generalized or localized rash after vaccination."
  },
  {
    "code" : "ANAPHYLAXIS",
    "display" : "Anaphylaxis",
    "definition" : "Severe immediate allergic reaction following vaccination."
  },
  {
    "code" : "OTHER",
    "display" : "Other Reaction",
    "definition" : "Any other adverse reaction not categorized above."
  }]
}

```
