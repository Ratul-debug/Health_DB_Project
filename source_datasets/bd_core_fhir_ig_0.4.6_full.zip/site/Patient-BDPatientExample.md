# Example Patient - BDPatientExample - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example Patient - BDPatientExample**

## Example Patient: Example Patient - BDPatientExample

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

-------

**English**

-------

Profile: [Patient Profile for Bangladesh](StructureDefinition-bd-patient.md)

Abul Kashem(official) Male, DoB: 1985-05-20 ( http://dghs.gov.bd/identifier/uhid#?ngen-9?)

-------

| | |
| :--- | :--- |
| Other Id: | Organization identifier/1234567890 |
| Contact Detail | BD (home) |
| [Patient Religion](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-patient-religion.html) | Islam |

-------

**German**

-------

Profile: [Patient Profile for Bangladesh](StructureDefinition-bd-patient.md)

Abul Kashem(official) Male, DoB: 1985-05-20 ( http://dghs.gov.bd/identifier/uhid#?ngen-9?)

-------

| | |
| :--- | :--- |
| Other Id: | Organization identifier/1234567890 |
| Contact Detail | BD (home) |
| [Patient Religion](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-patient-religion.html) | Islam |

-------

**French**

-------

Profil: [Patient Profile for Bangladesh](StructureDefinition-bd-patient.md)

Abul Kashem(official) Male, Date de Naissance :1985-05-20 ( http://dghs.gov.bd/identifier/uhid#?ngen-9?)

-------

| | |
| :--- | :--- |
| Autre identifiant : | Organization identifier/1234567890 |
| Coordonnées | BD (home) |
| [Patient Religion](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-patient-religion.html) | Islam |



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "BDPatientExample",
  "meta" : {
    "profile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-patient"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/patient-religion",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-religions",
        "code" : "1",
        "display" : "Islam"
      }]
    }
  }],
  "identifier" : [{
    "system" : "http://dghs.gov.bd/identifier/uhid"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-identifier-type",
        "code" : "NID"
      }],
      "text" : "Organization identifier"
    },
    "system" : "http://dghs.gov.bd/identifier/nid",
    "value" : "1234567890"
  }],
  "name" : [{
    "use" : "official",
    "text" : "Abul Kashem",
    "_text" : {
      "extension" : [{
        "url" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-name-en",
        "valueString" : "Abul Kashem"
      },
      {
        "url" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-name-bn",
        "valueString" : "আবুল কাশেম"
      }]
    }
  }],
  "gender" : "male",
  "birthDate" : "1985-05-20",
  "address" : [{
    "extension" : [{
      "url" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-divisions",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-geocodes",
          "code" : "30",
          "display" : "Dhaka"
        }]
      }
    },
    {
      "url" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-upazillas",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-geocodes",
          "code" : "10040028",
          "display" : "Dhamrai"
        }]
      }
    }],
    "use" : "home",
    "district" : "3026",
    "country" : "BD"
  }]
}

```
