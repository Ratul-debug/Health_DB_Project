# DGDA Registered Drugs Value Set - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DGDA Registered Drugs Value Set**

## ValueSet: DGDA Registered Drugs Value Set 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://dgda.gov.bd/fhir/ValueSet/registered-drugs | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDDGDADrugsVS |

 
Value set containing all registered drug products from the Drug Registration Authority (DGDA) of Bangladesh. This value set includes 39,196 finished pharmaceutical drug product concepts maintained in the national OCL terminology server at https://tr.ocl.dghs.gov.bd. 
This value set is the normative binding for BDMedication.code and represents the only permitted drug coding vocabulary for medication resources in the Bangladesh national health information exchange. 
Validation is performed via $validate-code and $lookup against the national OCL terminology server. $expand is not supported for this value set due to its size. 
Source collection: dgda-registered-drugs-valueset (MoHFW organisation, OCL) OCL collection canonical: https://dgda.gov.bd/fhir/ValueSet/registered-drugs OCL FHIR endpoint: https://tr.ocl.dghs.gov.bd/orgs/MoHFW/collections/dgda-registered-drugs-valueset/ 

 **References** 

* [Medication Profile for Bangladesh](StructureDefinition-bd-medication.md)

### Logical Definition (CLD)

 

### Expansion

No Expansion for this valueset (Unknown Code System)

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "dgda-registered-drugs",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://dgda.gov.bd/fhir/ValueSet/registered-drugs",
  "version" : "0.4.6",
  "name" : "BDDGDADrugsVS",
  "title" : "DGDA Registered Drugs Value Set",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Value set containing all registered drug products from the Drug Registration\nAuthority (DGDA) of Bangladesh. This value set includes 39,196 finished\npharmaceutical drug product concepts maintained in the national OCL terminology\nserver at https://tr.ocl.dghs.gov.bd.\n\nThis value set is the normative binding for BDMedication.code and represents\nthe only permitted drug coding vocabulary for medication resources in the\nBangladesh national health information exchange.\n\nValidation is performed via $validate-code and $lookup against the national\nOCL terminology server. $expand is not supported for this value set due to its\nsize.\n\nSource collection: dgda-registered-drugs-valueset (MoHFW organisation, OCL)\nOCL collection canonical: https://dgda.gov.bd/fhir/ValueSet/registered-drugs\nOCL FHIR endpoint: https://tr.ocl.dghs.gov.bd/orgs/MoHFW/collections/dgda-registered-drugs-valueset/",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "immutable" : false,
  "compose" : {
    "include" : [{
      "system" : "https://dgda.gov.bd/drug-registry"
    }]
  }
}

```
