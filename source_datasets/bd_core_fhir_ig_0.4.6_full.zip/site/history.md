# Version History - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* **Version History**

## Version History

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

This page provides the version history for the Bangladesh Core FHIR Implementation Guide.

For a machine-readable version history see [package-list.json](package-list.json).

**Published Versions**

| | | | |
| :--- | :--- | :--- | :--- |
| [Latest 0.4.6](https://fhir.dghs.gov.bd/core/0.4.6/) | 2026-04-27 | Trial Use | Release 0.4.6 |
| [0.4.5](https://fhir.dghs.gov.bd/core/0.4.5/) | 2026-04-10 | Trial Use | minor bug fixes |
| [0.4.4](https://fhir.dghs.gov.bd/core/0.4.4/) | 2026-04-06 | Trial Use | minor bug fixes |
| [0.4.3](https://fhir.dghs.gov.bd/core/0.4.3/) | 2026-04-06 | Trial Use | minor bug fixes |
| [0.4.2](https://fhir.dghs.gov.bd/core/0.4.2/) | 2026-04-06 | Trial Use | Patient profile minor bug fixes |
| [0.4.1](https://fhir.dghs.gov.bd/core/0.4.1/) | 2026-04-06 | Trial Use | DGDA Drug and LOINC Integration with minor bug fixes |
| [0.4.0](https://fhir.dghs.gov.bd/core/0.4.0/) | 2026-04-06 | Trial Use | DGDA Drug and LOINC Integration |
| [0.3.0](https://fhir.dghs.gov.bd/core/0.3.0/) | 2026-03-08 | Trial Use | ICD-11 MMS integration and minor bug fixes |
| [0.2.5](https://fhir.dghs.gov.bd/core/0.2.5/) | 2025-10-06 | Trial Use | Minor bug fix release |
| [0.2.4](https://fhir.dghs.gov.bd/core/0.2.4/) | 2025-10-06 | Trial Use | Minor visual improvements |
| [0.2.3](https://fhir.dghs.gov.bd/core/0.2.3/) | 2025-10-06 | Trial Use | Minor documentation updates |
| [0.2.2](https://fhir.dghs.gov.bd/core/0.2.2/) | 2025-10-06 | Trial Use | Minor bug fix release |
| [0.2.1](https://fhir.dghs.gov.bd/core/0.2.1/) | 2025-10-06 | Trial Use | Second draft release of the Bangladesh Core FHIR IG |
| [0.2.0](https://fhir.dghs.gov.bd/core/0.2.0/) | 2025-10-02 | Trial Use | First draft release of the Bangladesh Core FHIR IG |

**Continuous Integration Build**

The latest development build is available at: [https://fhir.dghs.gov.bd/core/](https://fhir.dghs.gov.bd/core/)

