# DGDA Drug Registry Code System - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DGDA Drug Registry Code System**

## CodeSystem: DGDA Drug Registry Code System 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://dgda.gov.bd/drug-registry | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDDGDADrugCS |

 
Code system representing the Drug Registration Authority (DGDA) of Bangladesh's official drug registry. Concepts are maintained in the national OCL terminology server at https://tr.ocl.dghs.gov.bd and are not enumerated within this Implementation Guide. 
This code system contains two concept classes: 
* **Drug**: Finished pharmaceutical drug products (identified by DAR number and trade name)
* **Ingredient**: Raw material / active pharmaceutical ingredients
 
Concept IDs follow the format: {DAR-number}–{trade-name-slug} Example: 353-0026-039–marvelous-fe 
**Canonical URL note:** https://dgda.gov.bd/drug-registry is a logical identifier only and does not resolve to a web endpoint. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [BDDGDADrugsVS](ValueSet-dgda-registered-drugs.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "dgda-drug-registry",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://dgda.gov.bd/drug-registry",
  "version" : "0.4.6",
  "name" : "BDDGDADrugCS",
  "title" : "DGDA Drug Registry Code System",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Code system representing the Drug Registration Authority (DGDA) of Bangladesh's\nofficial drug registry. Concepts are maintained in the national OCL terminology\nserver at https://tr.ocl.dghs.gov.bd and are not enumerated within this\nImplementation Guide.\n\nThis code system contains two concept classes:\n- **Drug**: Finished pharmaceutical drug products (identified by DAR number and trade name)\n- **Ingredient**: Raw material / active pharmaceutical ingredients\n\nConcept IDs follow the format: {DAR-number}--{trade-name-slug}\nExample: 353-0026-039--marvelous-fe\n\n**Canonical URL note:** https://dgda.gov.bd/drug-registry is a logical identifier\nonly and does not resolve to a web endpoint.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "caseSensitive" : true,
  "valueSet" : "https://dgda.gov.bd/fhir/ValueSet/registered-drugs",
  "content" : "not-present",
  "count" : 39196
}

```
