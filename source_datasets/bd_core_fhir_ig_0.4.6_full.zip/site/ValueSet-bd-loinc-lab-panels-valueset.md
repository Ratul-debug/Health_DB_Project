# Bangladesh LOINC Lab Panels ValueSet - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh LOINC Lab Panels ValueSet**

## ValueSet: Bangladesh LOINC Lab Panels ValueSet (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/ValueSet/bd-loinc-lab-panels-valueset | *Version*:0.4.6 |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | *Computable Name*:BDLoincLabPanelsVS |
| **Copyright/Legal**: This content from LOINC® is copyright © 1995 Regenstrief Institute, Inc. and the LOINC Committee, and available at no cost under the license at http://loinc.org/terms-of-use. | |

 
LOINC orderable laboratory panel codes for Bangladesh. Includes universal lab order panel codes from LOINC 2.82 scoped to the Universal Lab Orders ValueSet. Used as Observation.code in bd-lab-panel-observation. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "bd-loinc-lab-panels-valueset",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/ValueSet/bd-loinc-lab-panels-valueset",
  "version" : "0.4.6",
  "name" : "BDLoincLabPanelsVS",
  "title" : "Bangladesh LOINC Lab Panels ValueSet",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "LOINC orderable laboratory panel codes for Bangladesh. Includes universal \nlab order panel codes from LOINC 2.82 scoped to the Universal Lab Orders ValueSet. \nUsed as Observation.code in bd-lab-panel-observation.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "immutable" : false,
  "copyright" : "This content from LOINC® is copyright © 1995 Regenstrief Institute, Inc. and the LOINC Committee, and available at no cost under the license at http://loinc.org/terms-of-use.",
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "filter" : [{
        "property" : "concept",
        "op" : "in",
        "value" : "https://fhir.dghs.gov.bd/core/ValueSet/loinc-lab-panels"
      }]
    }]
  }
}

```
