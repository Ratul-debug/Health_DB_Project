# Artifacts Summary - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [BD Core Condition Profile (ICD-11)](StructureDefinition-bd-condition.md) | Condition resource coded with ICD-11 MMS, restricted to Diagnosis and Finding class concepts. Defined in the Bangladesh Core FHIR Implementation Guide (BD-Core-FHIR-IG) published by DGHS/MoHFW. |
| [Bangladesh Laboratory Panel Observation](StructureDefinition-bd-lab-panel-observation.md) | Profile for laboratory panel (order-level) Observations in Bangladesh. Represents an ordered laboratory test panel (e.g. CBC, LFT, RFT) as the parent Observation in a hasMember hierarchy.Usage:* Observation.code is the panel/order code (from BD LOINC Lab Panels ValueSet)
* Observation.hasMember references individual result Observations (bd-lab-result-observation) for each component
* Observation.value[x] is prohibited — panels do not carry a direct result value
* Observation.category is fixed to 'laboratory'
FHIR hasMember pattern: DiagnosticReport.result –> bd-lab-panel-observation └── hasMember –> bd-lab-result-observation (x N) |
| [Bangladesh Laboratory Report](StructureDefinition-bd-lab-report.md) | Profile for laboratory DiagnosticReport in Bangladesh, aligned with IPS (International Patient Summary) DiagnosticReport pattern.Usage:* Represents a complete laboratory report for a patient encounter
* DiagnosticReport.result references panel-level Observations (bd-lab-panel-observation) or standalone result Observations (bd-lab-result-observation) where no panel grouping exists
* DiagnosticReport.code is fixed to LOINC 11502-2 (Laboratory report)
* specimen is SHOULD (MS, 0..*)
Report structure: bd-lab-report (DiagnosticReport) ├── result –> bd-lab-panel-observation │ └── hasMember –> bd-lab-result-observation (x N) └── result –> bd-lab-result-observation (standalone, no panel) |
| [Bangladesh Laboratory Result Observation](StructureDefinition-bd-lab-result-observation.md) | Profile for individual laboratory result (component-level) Observations in Bangladesh. Represents a single test result within a laboratory panel (e.g. Haemoglobin within a CBC panel).Usage:* Observation.code is the result/component code (from BD LOINC Lab Results ValueSet)
* Observation.value[x] is required — every leaf result must carry a value
* Observation.hasMember is prohibited — leaf results cannot group further
* Observation.derivedFrom references the parent panel Observation
* Observation.category is fixed to 'laboratory'
FHIR hasMember pattern: bd-lab-panel-observation └── hasMember –> bd-lab-result-observation (this profile)Coded results (Ord/Nom scale): Use valueCodeableConcept with codes from BD LOINC Answer Lists ValueSet. |
| [Bangladesh Observation Profile](StructureDefinition-bd-observation.md) | Base observation profile for Bangladesh. This is an abstract-style base profile from which all BD-Core observation profiles are derived. It is not intended to be used directly in clinical resources — use a derived profile instead.Derived profiles (v0.4.0):* bd-lab-panel-observation : Laboratory panel/order (hasMember pattern)
* bd-lab-result-observation : Laboratory leaf result (child of hasMember)
Planned derived profiles (v0.5.0+):* bd-vital-signs-observation
* bd-exam-observation
 |
| [Encounter Profile for Bangladesh](StructureDefinition-bd-encounter.md) | Profile of Encounter Bangladesh Standard |
| [Immunization Profile for Bangladesh](StructureDefinition-bd-immunization.md) | Bangladesh Immunization Profile |
| [Location of Immunization for Bangladesh](StructureDefinition-bd-location.md) | Address for Bangladesh Standard |
| [Medication Profile for Bangladesh](StructureDefinition-bd-medication.md) | Profile of the Medication resource for the Bangladesh National Health Information Exchange (HIE). Drug products are coded using the DGDA Drug Registry maintained by the Drug Registration Authority of Bangladesh and served via the national OCL terminology server at https://tr.ocl.dghs.gov.bd.Ingredient coding uses ICD-11 MMS substance codes (XM-prefix) to support International Patient Summary (IPS) generation and cross-border data exchange. Ingredient data is system-populated from OCL Has-active-ingredient mappings and is not required to be entered manually by clinicians.Combination drugs are supported via the repeating ingredient element. Unmatched ingredients (not yet mapped to ICD-11 substances) may be represented using ingredient.itemCodeableConcept.text without a coded value.Dose form is optional and should be coded using EDQM Standard Terms when populated. Dose form is derivable from the DGDA drug concept via OCL lookup. A DGDA plain text dose form to EDQM code mapping is planned for a future IG version. |
| [Medication Request Profile for Bangladesh](StructureDefinition-bd-medication-request.md) | Profile of the MedicationRequest resource for the Bangladesh National Health Information Exchange (HIE). Prescriptions must reference a BDMedication resource coded against the DGDA Drug Registry, ensuring all prescribed medications are traceable to DGDA-registered drug products.This profile constrains medication references to BDMedication only. Inline medicationCodeableConcept is not permitted — all medication data must be carried in a referenced BDMedication resource to support ingredient coding for IPS and cross-border data exchange.Route of administration is coded using HL7 v3 RouteOfAdministration served via the national OCL terminology server. |
| [Organization for Bangladesh](StructureDefinition-bd-organization.md) | Organization for Bangladesh Standard |
| [Patient Profile for Bangladesh](StructureDefinition-bd-patient.md) | Banlgladesh Patient Profile |
| [Practitioner for Bangladesh](StructureDefinition-bd-practitioner.md) | Practitioner for Bangladesh Standard |
| [Related Person Profile for Bangladesh](StructureDefinition-bd-related-person.md) | Profile for RelatedPerson in Bangladesh. Used to represent father, mother, or guardian of a patient.* Identifier is mandatory and must use BD identifier systems (NID, BRN, UHID)
* Relationship is mandatory
* Name is mandatory
 |

### Structures: Data Type Profiles 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Address for Bangladesh](StructureDefinition-bd-address.md) | Address for Bangladesh Standard |

### Structures: Extension Definitions 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Bangla Name](StructureDefinition-bd-name-bn.md) | Bangla translation of the patient name |
| [Bangladesh Occupations](StructureDefinition-occupation-bd.md) | Occupation |
| [Division](StructureDefinition-bd-divisions.md) | BD Division |
| [English Name](StructureDefinition-bd-name-en.md) | English translation of the patient name |
| [ICD-11 Cluster Expression](StructureDefinition-icd11-cluster-expression.md) | Carries a postcoordinated ICD-11 cluster expression as a single string on a Coding element where the stem code alone is insufficient to fully represent the clinical concept.A cluster expression combines a stem code with one or more satellite codes using the & operator (combination) or / operator (specificity). Example: NC72.Z&XK8G&XJ7ZH&XJ7YM* NC72.Z — stem: Fracture of femur, unspecified
* XK8G — satellite: laterality
* XJ7ZH — satellite: fracture subtype
* XJ7YM — satellite: fracture open or closed
Usage rules:* SHALL only be present when the expression contains at least one satellite code joined by & or / operators.
* Single stem codes SHALL be represented in Coding.code only and validated via OCL $validate-code. The cluster validator at https://icd11.dghs.gov.bd/cluster/validate explicitly rejects stem-only expressions.
* The stem code in Coding.code SHALL match the leading stem code in this expression string.
* Satellite codes in the cluster expression are exempt from the Diagnosis/Finding class restriction that applies to stem codes in Condition.code.
* Cluster expressions SHALL be validated against the Bangladesh ICD-11 Cluster Validator at https://icd11.dghs.gov.bd/cluster/validate prior to submission to the HIE.
Cluster validator endpoint: POST https://icd11.dghs.gov.bd/cluster/validate Body: { "expression": "NC72.Z&XK8G&XJ7ZH&XJ7YM" }This extension is not MustSupport and is not mandatory. It is present only when postcoordination is clinically required. Cluster expressions are typically sourced from the WHO Electronic Coding Tool (ECT) at the point of care. |
| [Language Extension](StructureDefinition-language.md) | Language |
| [Patient Blood Group](StructureDefinition-bd-blood-group.md) | Blood group of the patient according to CCDS guideline |
| [Patient Nationality](StructureDefinition-nationality.md) | Nationality of the patient based on Bangladesh country list. |
| [Upazilla](StructureDefinition-bd-upazillas.md) | BD Upazilla |

### Terminology: Value Sets 

These define sets of codes used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Allowed Languages](ValueSet-bd-language-valueset.md) | Only English and Bengali are allowed |
| [BD Encounter Class Subset](ValueSet-bd-encounter-class-subset.md) | Subset of EncounterClass limited to inpatient, ambulatory, and emergency. |
| [BD Encounter Status Subset](ValueSet-bd-encounter-status-subset.md) | Subset of EncounterStatus limited to planned, in-progress, finished, and cancelled. |
| [Bangladesh Blood Group ValueSet](ValueSet-bd-blood-group-valueset.md) | Blood group value set according to CCDS guideline |
| [Bangladesh City Corperation ValueSet](ValueSet-bd-city-corporation-code-valueset.md) | Bangladesh City Corperation Codes (only two-digit codes) |
| [Bangladesh Division ValueSet](ValueSet-bd-division-code-valueset.md) | Bangladesh Division Codes (only two-digit codes) |
| [Bangladesh ICD-11 MMS Condition ValueSet (Diagnosis and Finding)](ValueSet-bd-condition-icd11-diagnosis-valueset.md) | ICD-11 MMS concepts restricted to the Diagnosis (14,071) and Finding (5,590) concept classes, totalling 19,661 concepts as of version 2025-01.This ValueSet is the binding target for Condition.code in the BD-Core Condition profile. Substance, Organism, Device, Anatomy, and Misc class concepts are excluded and SHALL NOT appear as standalone stem codes in Condition.code. This restriction applies to stem codes only — satellite codes carried in the icd11-cluster-expression extension are exempt.This ValueSet is an empty stub. No compose block is declared because $expand is not supported by the national OCL terminology server and no machine-executable filter for concept_class is available at the IG layer. The compose would be nominal only and is omitted to avoid misrepresenting machine-executable semantics.The ValueSet is hosted in OCL as a collection with 19,661 explicit concept references (Diagnosis and Finding classes only). Runtime enforcement is via OCL ValueSet $validate-code:GET https://tr.ocl.dghs.gov.bd/api/fhir/ValueSet/$validate-code ?url=https://fhir.dghs.gov.bd/core/ValueSet/bd-condition-icd11-diagnosis-valueset &system=http://id.who.int/icd/release/11/mms &code={code}Confirmed behaviour:* Diagnosis class (e.g. 1A00): accepted
* Finding class: accepted
* Device class (e.g. XD7EB1): rejected
* Substance class (e.g. XM6RB2): rejected
At the HAPI FHIR layer, enforcement is via RemoteTerminologyServiceValidationSupport configured to call OCL. HAPI FHIR deployment is a known gap to be closed before vendor onboarding.VERSION UPGRADES: Upgrading to a new ICD-11 MMS release requires re-running populate_condition_valueset.py. Automated via version_upgrade.py. |
| [Bangladesh Identifier Type](ValueSet-bd-identifier-type-valueset.md) | Bangladesh Standard Identifier type |
| [Bangladesh Immunization Reaction Value Set](ValueSet-bd-immunization-reaction-valueset.md) | Allowed vaccine reactions for immunization in Bangladesh. |
| [Bangladesh Immunization Route Value Set](ValueSet-bd-immunization-route-valueset.md) | Allowed administration routes for vaccines in Bangladesh. |
| [Bangladesh Immunization Site Value Set](ValueSet-bd-immunization-site-valueset.md) | Allowed administration sites for vaccines in Bangladesh. |
| [Bangladesh LOINC Answer Lists ValueSet](ValueSet-bd-loinc-answer-lists-valueset.md) | LOINC answer codes (LA-prefixed) and answer list groupers (LL-prefixed) for Bangladesh laboratory results. Includes all answer codes referenced by in-scope lab result codes from LOINC 2.82. Used as Observation.valueCodeableConcept in bd-lab-result-observation for ordinal and nominal scale results. |
| [Bangladesh LOINC Lab Panels ValueSet](ValueSet-bd-loinc-lab-panels-valueset.md) | LOINC orderable laboratory panel codes for Bangladesh. Includes universal lab order panel codes from LOINC 2.82 scoped to the Universal Lab Orders ValueSet. Used as Observation.code in bd-lab-panel-observation. |
| [Bangladesh LOINC Lab Results ValueSet](ValueSet-bd-loinc-lab-results-valueset.md) | LOINC leaf-level laboratory result codes for Bangladesh. Includes individual component/result codes from LOINC 2.82 scoped to the Universal Lab Orders ValueSet. Excludes discouraged and non-laboratory codes. Used as Observation.code in bd-lab-result-observation. |
| [Bangladesh Marital Status ValueSet](ValueSet-bd-marital-status-valueset.md) | Marital status value set according to CCDS guideline |
| [Bangladesh Medication ValueSet](ValueSet-bd-medication-valueset.md) | Bangladesh Medication ValueSet |
| [Bangladesh Municipalities ValueSet](ValueSet-bd-municipalities-code-valueset.md) | Bangladesh Municipalities Codes (only two-digit codes) |
| [Bangladesh Occupations ValueSet](ValueSet-bd-occupations-valueset.md) | Occupations value set according to CCDS guideline |
| [Bangladesh Religions ValueSet](ValueSet-bd-religions-valueset.md) | Religions value set according to CCDS guideline |
| [Bangladesh Upazila ValueSet](ValueSet-bd-upazilla-code-valueset.md) | Bangladesh Upazila Codes (only two-digit codes) |
| [Bangladesh Vaccine Value Set](ValueSet-bd-vaccine-valueset.md) | Allowed vaccines for immunization in Bangladesh. |
| [Bangladesh district ValueSet](ValueSet-bd-district-code-valueset.md) | Bangladesh district Codes (only two-digit codes) |
| [DGDA Registered Drugs Value Set](ValueSet-dgda-registered-drugs.md) | Value set containing all registered drug products from the Drug Registration Authority (DGDA) of Bangladesh. This value set includes 39,196 finished pharmaceutical drug product concepts maintained in the national OCL terminology server at https://tr.ocl.dghs.gov.bd.This value set is the normative binding for BDMedication.code and represents the only permitted drug coding vocabulary for medication resources in the Bangladesh national health information exchange.Validation is performed via $validate-code and $lookup against the national OCL terminology server. $expand is not supported for this value set due to its size.Source collection: dgda-registered-drugs-valueset (MoHFW organisation, OCL) OCL collection canonical: https://dgda.gov.bd/fhir/ValueSet/registered-drugs OCL FHIR endpoint: https://tr.ocl.dghs.gov.bd/orgs/MoHFW/collections/dgda-registered-drugs-valueset/ |
| [ICD-11 Substances Value Set](ValueSet-icd11-substances-valueset.md) | Value set containing all ICD-11 MMS substance and medicament concepts (XM-prefix concept class: Substance) maintained in the national OCL terminology server at https://tr.ocl.dghs.gov.bd.This value set contains 7,776 substance concepts and is used for coding active pharmaceutical ingredients in the BDMedication.ingredient element to support IPS generation and cross-border data exchange.This value set is defined and maintained in OCL. It is declared here as a minimal stub to allow IG publisher binding resolution only.**OCL collection canonical:** https://fhir.dghs.gov.bd/core/ValueSet/icd11-substances-valueset **OCL FHIR endpoint:** https://tr.ocl.dghs.gov.bd/orgs/MoHFW/collections/icd11-substances-valueset/ |
| [Medication Dose Form Value Set](ValueSet-bd-medication-dose-form.md) | Value set containing pharmaceutical dose form concepts from the European Directorate for the Quality of Medicines (EDQM) Standard Terms, domain: Pharmaceutical Dose Forms (PDF).This value set is used to code the physical form of a medication product in BDMedication.form. EDQM Standard Terms are maintained and versioned by the Council of Europe and are the WHO-recommended international standard for pharmaceutical dose form coding.Concepts are loaded into the national OCL terminology server at https://tr.ocl.dghs.gov.bd under the MoHFW organisation as source EDQM-PDF.**Binding:** preferred on BDMedication.form — systems should use EDQM codes when populating dose form, but omission is permitted. A mapping from DGDA plain text dose forms to EDQM codes is planned for a future IG version.**Code system canonical:** https://standardterms.edqm.eu **OCL source:** https://tr.ocl.dghs.gov.bd/#/orgs/MoHFW/sources/EDQM-PDF/ |
| [Nationality ValueSet](ValueSet-bd-country-list-valueset.md) | Nationality value set |
| [Route of Administration Value Set](ValueSet-bd-route-of-administration.md) | Value set containing route of administration concepts from the HL7 Version 3 RouteOfAdministration code system.This value set is used to code the route by which a medication is administered in MedicationRequest.dosageInstruction.route. HL7 v3 RouteOfAdministration is a license-free, internationally recognised vocabulary already embedded in the FHIR ecosystem.Concepts are loaded into the national OCL terminology server at https://tr.ocl.dghs.gov.bd under the MoHFW organisation.**Code system canonical:** http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration **Binding:** required on BDMedicationRequest.dosageInstruction.route |

### Terminology: Code Systems 

These define new code systems used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Bangladesh Blood Group CodeSystem](CodeSystem-bd-blood-groups.md) | Blood group codes according to CCDS guideline |
| [Bangladesh GeoCodes CodeSystem](CodeSystem-bd-geocodes.md) | Bangladesh GeoCodes |
| [Bangladesh Identifier Types](CodeSystem-bd-identifier-type.md) | Codes identifying the type of identifiers used in Bangladesh. |
| [Bangladesh Immunization Reaction Code System](CodeSystem-bd-immunization-reaction.md) | Codes for adverse reactions after vaccination in Bangladesh. |
| [Bangladesh Immunization Route Code System](CodeSystem-bd-immunization-route.md) | Codes for routes of vaccine administration in Bangladesh. |
| [Bangladesh Immunization Site Code System](CodeSystem-bd-immunization-site.md) | Codes for anatomical site of vaccine administration in Bangladesh. |
| [Bangladesh Marital Status](CodeSystem-bd-marital-status.md) |  |
| [Bangladesh Medication Codes](CodeSystem-bd-medication-code.md) | Bangladesh Medication Codes |
| [Bangladesh Medication Dose Form CodeSystem](CodeSystem-bd-dose-form.md) | Medication dose form codes according to CCDS guideline |
| [Bangladesh Occupations](CodeSystem-bd-occupations.md) | Occupations code system according to CCDS guideline |
| [Bangladesh Religions](CodeSystem-bd-religions.md) |  |
| [Bangladesh Vaccine Code System](CodeSystem-bd-vaccine-code.md) | Vaccine codes used in Bangladesh EPI and immunization program. |
| [DGDA Drug Registry Code System](CodeSystem-dgda-drug-registry.md) | Code system representing the Drug Registration Authority (DGDA) of Bangladesh's official drug registry. Concepts are maintained in the national OCL terminology server at https://tr.ocl.dghs.gov.bd and are not enumerated within this Implementation Guide.This code system contains two concept classes:* **Drug**: Finished pharmaceutical drug products (identified by DAR number and trade name)
* **Ingredient**: Raw material / active pharmaceutical ingredients
Concept IDs follow the format: {DAR-number}–{trade-name-slug} Example: 353-0026-039–marvelous-fe**Canonical URL note:** https://dgda.gov.bd/drug-registry is a logical identifier only and does not resolve to a web endpoint. |
| [ICD-11 Mortality and Morbidity Statistics (MMS)](CodeSystem-icd11-mms.md) | WHO ICD-11 Mortality and Morbidity Statistics linearization. Canonical system URI: http://id.who.int/icd/release/11/mmsThis CodeSystem is declared as a stub (content = #not-present). The authoritative content is maintained by the World Health Organization. In Bangladesh, runtime code validation and lookup are delegated to the national OCL terminology server at https://tr.ocl.dghs.gov.bd.Supported operations (use system= parameter, not url=):* $validate-code: https://tr.ocl.dghs.gov.bd/api/fhir/CodeSystem/$validate-code?system=http://id.who.int/icd/release/11/mms&code={code}
* $lookup: https://tr.ocl.dghs.gov.bd/api/fhir/CodeSystem/$lookup?system=http://id.who.int/icd/release/11/mms&code={code}
$expand is not supported — known OCL limitation. Expansion must not be attempted at build time or by IG Publisher.Preferred code form: short stem codes (e.g. 1A00, NC72.Z). Linearization URIs are not used as code identifiers in this IG.Version 2025-01 is imported into OCL with 36,941 concepts across the following concept classes: Diagnosis, Finding, Substance, Organism, Device, Anatomy, Misc. |
| [Nationality List](CodeSystem-bd-country-list.md) |  |

### Terminology: Naming Systems 

These define identifier and/or code system identities used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [ICD11MMSBangladesh](NamingSystem-icd11-mms-bd.md) | Declares the ICD-11 Mortality and Morbidity Statistics (MMS) coding system as a known and supported terminology within the Bangladesh national health information infrastructure.Canonical system URI: http://id.who.int/icd/release/11/mms Canonical authority: World Health Organization (WHO)Preferred code form: short stem codes (e.g. 1A00, NC72.Z). Linearization URIs are not used as code identifiers in this IG.National terminology resolver (OCL): https://tr.ocl.dghs.gov.bdSupported OCL operations (use system= parameter, not url=):* $validate-code: https://tr.ocl.dghs.gov.bd/api/fhir/CodeSystem/$validate-code ?system=http://id.who.int/icd/release/11/mms&code={code}
* $lookup: https://tr.ocl.dghs.gov.bd/api/fhir/CodeSystem/$lookup ?system=http://id.who.int/icd/release/11/mms&code={code}
$expand is not supported — known OCL limitation.Version 2025-01 is active in the national OCL instance with 36,941 imported concepts. The OCL resolver is an internal national service; vendors do not interact with it directly. All vendor submissions are validated at the HIE boundary via the Bangladesh ICD-11 Cluster Validator at https://icd11.dghs.gov.bd/cluster/validate. |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| |
| :--- |
| [Dhaka Medical College Hospital](Organization-BDOrganizationExample.md) |
| [Example Encounter - BDEncounterExample](Encounter-BDEncounterExample.md) |
| [Example Medication - BDMedicationExample](Medication-BDMedicationExample.md) |
| [Example MedicationRequest - BDMedicationRequestExample](MedicationRequest-BDMedicationRequestExample.md) |
| [Example Patient - BDPatientExample](Patient-BDPatientExample.md) |
| [Example Practitioner - BDPractitionerExample](Practitioner-BDPractitionerExample.md) |

