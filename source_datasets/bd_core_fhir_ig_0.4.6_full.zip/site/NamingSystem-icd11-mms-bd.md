# ICD11MMSBangladesh - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ICD11MMSBangladesh**

## NamingSystem: ICD11MMSBangladesh 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/NamingSystem/icd11-mms-bd | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:ICD11MMSBangladesh |

 
Declares the ICD-11 Mortality and Morbidity Statistics (MMS) coding system as a known and supported terminology within the Bangladesh national health information infrastructure. 
Canonical system URI: http://id.who.int/icd/release/11/mms Canonical authority: World Health Organization (WHO) 
Preferred code form: short stem codes (e.g. 1A00, NC72.Z). Linearization URIs are not used as code identifiers in this IG. 
National terminology resolver (OCL): https://tr.ocl.dghs.gov.bd 
Supported OCL operations (use system= parameter, not url=): 
* $validate-code: https://tr.ocl.dghs.gov.bd/api/fhir/CodeSystem/$validate-code ?system=http://id.who.int/icd/release/11/mms&code={code}
* $lookup: https://tr.ocl.dghs.gov.bd/api/fhir/CodeSystem/$lookup ?system=http://id.who.int/icd/release/11/mms&code={code}
 
$expand is not supported — known OCL limitation. 
Version 2025-01 is active in the national OCL instance with 36,941 imported concepts. The OCL resolver is an internal national service; vendors do not interact with it directly. All vendor submissions are validated at the HIE boundary via the Bangladesh ICD-11 Cluster Validator at https://icd11.dghs.gov.bd/cluster/validate. 



## Resource Content

```json
{
  "resourceType" : "NamingSystem",
  "id" : "icd11-mms-bd",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-NamingSystem.url",
    "valueUri" : "https://fhir.dghs.gov.bd/core/NamingSystem/icd11-mms-bd"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-NamingSystem.version",
    "valueString" : "0.4.6"
  }],
  "name" : "ICD11MMSBangladesh",
  "status" : "active",
  "kind" : "codesystem",
  "date" : "2025-01-01",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "responsible" : "World Health Organization (WHO)",
  "description" : "Declares the ICD-11 Mortality and Morbidity Statistics (MMS) coding system\nas a known and supported terminology within the Bangladesh national health\ninformation infrastructure.\n\nCanonical system URI: http://id.who.int/icd/release/11/mms\nCanonical authority: World Health Organization (WHO)\n\nPreferred code form: short stem codes (e.g. 1A00, NC72.Z).\nLinearization URIs are not used as code identifiers in this IG.\n\nNational terminology resolver (OCL):\n  https://tr.ocl.dghs.gov.bd\n\nSupported OCL operations (use system= parameter, not url=):\n  - $validate-code: https://tr.ocl.dghs.gov.bd/api/fhir/CodeSystem/$validate-code\n      ?system=http://id.who.int/icd/release/11/mms&code={code}\n  - $lookup: https://tr.ocl.dghs.gov.bd/api/fhir/CodeSystem/$lookup\n      ?system=http://id.who.int/icd/release/11/mms&code={code}\n\n$expand is not supported — known OCL limitation.\n\nVersion 2025-01 is active in the national OCL instance with 36,941\nimported concepts. The OCL resolver is an internal national service;\nvendors do not interact with it directly. All vendor submissions are\nvalidated at the HIE boundary via the Bangladesh ICD-11 Cluster Validator\nat https://icd11.dghs.gov.bd/cluster/validate.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "uniqueId" : [{
    "type" : "uri",
    "value" : "http://id.who.int/icd/release/11/mms",
    "preferred" : true,
    "comment" : "Canonical ICD-11 MMS system URI. Canonical authority is WHO.",
    "period" : {
      "start" : "2025-01-01"
    }
  },
  {
    "type" : "uri",
    "value" : "https://tr.ocl.dghs.gov.bd/orgs/MoHFW/sources/ICD-11-MMS/",
    "preferred" : false,
    "comment" : "National terminology resolver — Bangladesh OCL instance. Not the canonical system URI."
  }]
}

```
