# Background and Context - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* **Background and Context**

## Background and Context

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

 The Bangladesh Core FHIR Implementation Guide defines national base profiles, code systems, and value sets to ensure interoperability across digital health systems under DGHS and MoHFW. 

### Motivation

 Bangladesh has multiple health information systems developed over the years, including DHIS2, multiple hospital automation systems, field automation systems, and HRIS. These systems use different data standards, which makes interoperability difficult. This guide aligns national systems with HL7® FHIR® R4 to ensure semantic consistency and facilitate integration with global initiatives. 

### Scope

* Patient identity management (UHID, NID, BRN)
* Health facility and organization registry
* Immunization, laboratory, and condition profiles
* Terminology services (ICD-11, SNOMED subsets, local CodeSystems)

### National Digital Health Architecture

 The following diagram shows how FHIR-based services are integrated into Bangladesh's national digital health architecture: 

 ![](bd-core-architecture.png) 

