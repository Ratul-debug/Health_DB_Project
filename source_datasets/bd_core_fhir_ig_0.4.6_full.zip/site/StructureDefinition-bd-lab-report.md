# Bangladesh Laboratory Report - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bangladesh Laboratory Report**

## Resource Profile: Bangladesh Laboratory Report 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/StructureDefinition/bd-lab-report | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDLabReportProfile |

 
Profile for laboratory DiagnosticReport in Bangladesh, aligned with IPS (International Patient Summary) DiagnosticReport pattern. 
Usage: 
* Represents a complete laboratory report for a patient encounter
* DiagnosticReport.result references panel-level Observations (bd-lab-panel-observation) or standalone result Observations (bd-lab-result-observation) where no panel grouping exists
* DiagnosticReport.code is fixed to LOINC 11502-2 (Laboratory report)
* specimen is SHOULD (MS, 0..*)
 
Report structure: bd-lab-report (DiagnosticReport) ├── result –> bd-lab-panel-observation │ └── hasMember –> bd-lab-result-observation (x N) └── result –> bd-lab-result-observation (standalone, no panel) 

**Usages:**

* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/bd.fhir.core|current/StructureDefinition/bd-lab-report)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-bd-lab-report.csv), [Excel](StructureDefinition-bd-lab-report.xlsx), [Schematron](StructureDefinition-bd-lab-report.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "bd-lab-report",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-lab-report",
  "version" : "0.4.6",
  "name" : "BDLabReportProfile",
  "title" : "Bangladesh Laboratory Report",
  "status" : "draft",
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Profile for laboratory DiagnosticReport in Bangladesh, aligned with IPS\n(International Patient Summary) DiagnosticReport pattern.\n\nUsage:\n  - Represents a complete laboratory report for a patient encounter\n  - DiagnosticReport.result references panel-level Observations\n    (bd-lab-panel-observation) or standalone result Observations\n    (bd-lab-result-observation) where no panel grouping exists\n  - DiagnosticReport.code is fixed to LOINC 11502-2 (Laboratory report)\n  - specimen is SHOULD (MS, 0..*)\n\nReport structure:\n  bd-lab-report (DiagnosticReport)\n      ├── result --> bd-lab-panel-observation\n      │                 └── hasMember --> bd-lab-result-observation (x N)\n      └── result --> bd-lab-result-observation  (standalone, no panel)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "DiagnosticReport",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/DiagnosticReport",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "DiagnosticReport",
      "path" : "DiagnosticReport"
    },
    {
      "id" : "DiagnosticReport.identifier",
      "path" : "DiagnosticReport.identifier",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.identifier.value",
      "path" : "DiagnosticReport.identifier.value",
      "min" : 1
    },
    {
      "id" : "DiagnosticReport.status",
      "path" : "DiagnosticReport.status",
      "definition" : "Status of the laboratory report",
      "comment" : "E.g. registered, partial, preliminary, final, amended, corrected",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.org/fhir/ValueSet/diagnostic-report-status"
      }
    },
    {
      "id" : "DiagnosticReport.category",
      "path" : "DiagnosticReport.category",
      "definition" : "Fixed to 'LAB' for laboratory diagnostic reports",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "LAB",
          "display" : "Laboratory"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.code",
      "path" : "DiagnosticReport.code",
      "definition" : "Fixed to LOINC 11502-2 — Laboratory report",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "11502-2",
          "display" : "Laboratory report"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.subject",
      "path" : "DiagnosticReport.subject",
      "definition" : "Reference to the Patient this report is about",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.subject.reference",
      "path" : "DiagnosticReport.subject.reference",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.subject.display",
      "path" : "DiagnosticReport.subject.display",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.encounter",
      "path" : "DiagnosticReport.encounter",
      "definition" : "Reference to the Encounter during which this report was ordered",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.encounter.reference",
      "path" : "DiagnosticReport.encounter.reference",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.effective[x]",
      "path" : "DiagnosticReport.effective[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.effective[x]:effectiveDateTime",
      "path" : "DiagnosticReport.effective[x]",
      "sliceName" : "effectiveDateTime",
      "definition" : "Date/time the specimen was collected or the report period",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "DiagnosticReport.issued",
      "path" : "DiagnosticReport.issued",
      "definition" : "Date/time the report was issued by the laboratory",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.performer",
      "path" : "DiagnosticReport.performer",
      "definition" : "Laboratory or practitioner who performed the test",
      "comment" : "Typically the laboratory Organization. May also include the responsible Practitioner.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.resultsInterpreter",
      "path" : "DiagnosticReport.resultsInterpreter",
      "definition" : "Clinician or pathologist who interpreted the laboratory results",
      "comment" : "Include when a formal interpretation or authorisation was made by a named clinician.",
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.specimen",
      "path" : "DiagnosticReport.specimen",
      "definition" : "Specimen(s) used for this laboratory report",
      "comment" : "Should be present when specimen information is available. IPS alignment: SHOULD.",
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.result",
      "path" : "DiagnosticReport.result",
      "definition" : "References to Observation resources that are part of this report",
      "comment" : "Use BDLabPanelObservationProfile for ordered panels (CBC, LFT, RFT, etc.)\nwhere individual results are grouped under a panel using hasMember.\nUse BDLabResultObservationProfile directly for standalone results\nthat are not part of a named panel.",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-lab-panel-observation",
        "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-lab-result-observation"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.conclusion",
      "path" : "DiagnosticReport.conclusion",
      "definition" : "Clinical interpretation or summary of the laboratory report",
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.conclusionCode",
      "path" : "DiagnosticReport.conclusionCode",
      "definition" : "Coded representation of the clinical conclusion",
      "comment" : "May use ICD-11 MMS codes consistent with bd-condition-icd11-diagnosis-valueset",
      "mustSupport" : true
    },
    {
      "id" : "DiagnosticReport.presentedForm",
      "path" : "DiagnosticReport.presentedForm",
      "definition" : "Entire report as issued — e.g. PDF attachment",
      "comment" : "Include the original report document when available",
      "mustSupport" : true
    }]
  }
}

```
