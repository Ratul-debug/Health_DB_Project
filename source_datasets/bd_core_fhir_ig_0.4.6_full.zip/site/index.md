# BD-Core-FHIR-IG Home Page - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* **BD-Core-FHIR-IG Home Page**

## BD-Core-FHIR-IG Home Page

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core | *Version*:0.4.6 | |
| * IG Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BangladeshCoreFHIRIG |

### Introduction

 The Bangladesh Core FHIR Implementation Guide (BD-Core-FHIR-IG) is part of the Bangladesh Digital Health Blueprint. It defines how health information should be exchanged across systems in Bangladesh in a safe, standardized, and interoperable way. 

 By adopting international FHIR standards, this guide helps ensure that patient data can flow smoothly between hospitals, clinics, and national programs, while also enabling future cross-border health information exchange. 

-------

#### FHIR Sandbox Server

 A live sandbox environment is available for testing and development based on this implementation guide. 

 **Base URL:**
 [ https://sandbox.fhir.dghs.gov.bd/fhir ](https://sandbox.fhir.dghs.gov.bd/fhir) 

 This sandbox supports HL7 FHIR R4 and implements the Bangladesh Core FHIR profiles and terminology bindings. It is intended for testing, validation, and system integration only. 

* [Capability Statement](https://sandbox.fhir.dghs.gov.bd/fhir/metadata)
* [FHIR Tester UI](https://sandbox.fhir.dghs.gov.bd)

 Developers are encouraged to validate their implementations against this sandbox before moving to production environments. 

-------

### Technical Overview

 This guide provides national FHIR profiles, value sets, and terminology bindings that software developers and system implementers must use when designing digital health applications for Bangladesh. Using these standards ensures consistency, reduces duplication, and supports patient-centered care. 

 The main sections of this IG are: 

* [Background](background.md) - Context and rationale for the IG
* [Detailed Specification](spec.md) - Profiles, value sets, and conformance requirements
* [Fragments](fragments.md) - Guidance about how to embed fragments in an IG
* [Downloads](downloads.md) - Allows downloading a copy of this implementation guide and other useful information



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "bd.fhir.core",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1
  }],
  "url" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core",
  "version" : "0.4.6",
  "name" : "BangladeshCoreFHIRIG",
  "title" : "Bangladesh Core FHIR Implementation Guide",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "This Implementation Guide defines the Bangladesh Core FHIR profiles, value sets, code systems, and implementation rules for national digital health systems.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "packageId" : "bd.fhir.core",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.1.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.2.0"
  },
  {
    "id" : "cqf",
    "uri" : "http://fhir.org/guides/cqf/common/ImplementationGuide/fhir.cqf.common",
    "packageId" : "fhir.cqf.common",
    "version" : "4.0.1"
  }],
  "definition" : {
    "extension" : [{
      "extension" : [{
        "url" : "code",
        "valueString" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2025+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "Published by DGHS, MoHFW"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-binary"
      },
      {
        "url" : "value",
        "valueString" : "input\\cql"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "templates\\liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "shownav"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "i18n-lang"
      },
      {
        "url" : "value",
        "valueString" : "de"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "i18n-lang"
      },
      {
        "url" : "value",
        "valueString" : "fr"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "translation-sources"
      },
      {
        "url" : "value",
        "valueString" : "input/translations-de"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "translation-sources"
      },
      {
        "url" : "value",
        "valueString" : "input/translations-fr"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://fhir.dghs.gov.bd/core/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.1.2"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2025+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "Published by DGHS, MoHFW"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-binary"
      },
      {
        "url" : "value",
        "valueString" : "input\\cql"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "templates\\liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "shownav"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-lang"
      },
      {
        "url" : "value",
        "valueString" : "de"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-lang"
      },
      {
        "url" : "value",
        "valueString" : "fr"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "translation-sources"
      },
      {
        "url" : "value",
        "valueString" : "input/translations-de"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "translation-sources"
      },
      {
        "url" : "value",
        "valueString" : "input/translations-fr"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://fhir.dghs.gov.bd/core/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-patient"
      },
      "name" : "Patient Profile for Bangladesh",
      "description" : "Banlgladesh Patient Profile"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/bd-blood-groups"
      },
      "name" : "Bangladesh Blood Group CodeSystem",
      "description" : "Blood group codes according to CCDS guideline"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/bd-country-list"
      },
      "name" : "Nationality List"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/bd-dose-form"
      },
      "name" : "Bangladesh Medication Dose Form CodeSystem",
      "description" : "Medication dose form codes according to CCDS guideline"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/bd-geocodes"
      },
      "name" : "Bangladesh GeoCodes CodeSystem",
      "description" : "Bangladesh GeoCodes"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/bd-identifier-type"
      },
      "name" : "Bangladesh Identifier Types",
      "description" : "Codes identifying the type of identifiers used in Bangladesh."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/bd-immunization-reaction"
      },
      "name" : "Bangladesh Immunization Reaction Code System",
      "description" : "Codes for adverse reactions after vaccination in Bangladesh."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/bd-immunization-route"
      },
      "name" : "Bangladesh Immunization Route Code System",
      "description" : "Codes for routes of vaccine administration in Bangladesh."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/bd-immunization-site"
      },
      "name" : "Bangladesh Immunization Site Code System",
      "description" : "Codes for anatomical site of vaccine administration in Bangladesh."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/bd-marital-status"
      },
      "name" : "Bangladesh Marital Status"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/bd-medication-code"
      },
      "name" : "Bangladesh Medication Codes",
      "description" : "Bangladesh Medication Codes"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/bd-occupations"
      },
      "name" : "Bangladesh Occupations",
      "description" : "Occupations code system according to CCDS guideline"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/bd-religions"
      },
      "name" : "Bangladesh Religions"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/bd-vaccine-code"
      },
      "name" : "Bangladesh Vaccine Code System",
      "description" : "Vaccine codes used in Bangladesh EPI and immunization program."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/dgda-drug-registry"
      },
      "name" : "DGDA Drug Registry Code System",
      "description" : "Code system representing the Drug Registration Authority (DGDA) of Bangladesh's\nofficial drug registry. Concepts are maintained in the national OCL terminology\nserver at https://tr.ocl.dghs.gov.bd and are not enumerated within this\nImplementation Guide.\n\nThis code system contains two concept classes:\n- **Drug**: Finished pharmaceutical drug products (identified by DAR number and trade name)\n- **Ingredient**: Raw material / active pharmaceutical ingredients\n\nConcept IDs follow the format: {DAR-number}--{trade-name-slug}\nExample: 353-0026-039--marvelous-fe\n\n**Canonical URL note:** https://dgda.gov.bd/drug-registry is a logical identifier\nonly and does not resolve to a web endpoint."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/icd11-mms"
      },
      "name" : "ICD-11 Mortality and Morbidity Statistics (MMS)",
      "description" : "WHO ICD-11 Mortality and Morbidity Statistics linearization.\nCanonical system URI: http://id.who.int/icd/release/11/mms\n\nThis CodeSystem is declared as a stub (content = #not-present).\nThe authoritative content is maintained by the World Health Organization.\nIn Bangladesh, runtime code validation and lookup are delegated to the\nnational OCL terminology server at https://tr.ocl.dghs.gov.bd.\n\nSupported operations (use system= parameter, not url=):\n  - $validate-code: https://tr.ocl.dghs.gov.bd/api/fhir/CodeSystem/$validate-code?system=http://id.who.int/icd/release/11/mms&code={code}\n  - $lookup:        https://tr.ocl.dghs.gov.bd/api/fhir/CodeSystem/$lookup?system=http://id.who.int/icd/release/11/mms&code={code}\n\n$expand is not supported — known OCL limitation. Expansion must not be\nattempted at build time or by IG Publisher.\n\nPreferred code form: short stem codes (e.g. 1A00, NC72.Z).\nLinearization URIs are not used as code identifiers in this IG.\n\nVersion 2025-01 is imported into OCL with 36,941 concepts across\nthe following concept classes: Diagnosis, Finding, Substance, Organism,\nDevice, Anatomy, Misc."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      }],
      "reference" : {
        "reference" : "Encounter/BDEncounterExample"
      },
      "name" : "Example Encounter - BDEncounterExample",
      "exampleCanonical" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-encounter"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Medication"
      }],
      "reference" : {
        "reference" : "Medication/BDMedicationExample"
      },
      "name" : "Example Medication - BDMedicationExample",
      "exampleCanonical" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-medication"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      }],
      "reference" : {
        "reference" : "MedicationRequest/BDMedicationRequestExample"
      },
      "name" : "Example MedicationRequest - BDMedicationRequestExample",
      "exampleCanonical" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-medication-request"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "NamingSystem"
      }],
      "reference" : {
        "reference" : "NamingSystem/icd11-mms-bd"
      },
      "name" : "ICD11MMSBangladesh",
      "description" : "Declares the ICD-11 Mortality and Morbidity Statistics (MMS) coding system\nas a known and supported terminology within the Bangladesh national health\ninformation infrastructure.\n\nCanonical system URI: http://id.who.int/icd/release/11/mms\nCanonical authority: World Health Organization (WHO)\n\nPreferred code form: short stem codes (e.g. 1A00, NC72.Z).\nLinearization URIs are not used as code identifiers in this IG.\n\nNational terminology resolver (OCL):\n  https://tr.ocl.dghs.gov.bd\n\nSupported OCL operations (use system= parameter, not url=):\n  - $validate-code: https://tr.ocl.dghs.gov.bd/api/fhir/CodeSystem/$validate-code\n      ?system=http://id.who.int/icd/release/11/mms&code={code}\n  - $lookup: https://tr.ocl.dghs.gov.bd/api/fhir/CodeSystem/$lookup\n      ?system=http://id.who.int/icd/release/11/mms&code={code}\n\n$expand is not supported — known OCL limitation.\n\nVersion 2025-01 is active in the national OCL instance with 36,941\nimported concepts. The OCL resolver is an internal national service;\nvendors do not interact with it directly. All vendor submissions are\nvalidated at the HIE boundary via the Bangladesh ICD-11 Cluster Validator\nat https://icd11.dghs.gov.bd/cluster/validate."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/BDOrganizationExample"
      },
      "name" : "Dhaka Medical College Hospital",
      "exampleCanonical" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-organization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      }],
      "reference" : {
        "reference" : "Patient/BDPatientExample"
      },
      "name" : "Example Patient - BDPatientExample",
      "exampleCanonical" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-patient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      }],
      "reference" : {
        "reference" : "Practitioner/BDPractitionerExample"
      },
      "name" : "Example Practitioner - BDPractitionerExample",
      "exampleCanonical" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-practitioner"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-address"
      },
      "name" : "Address for Bangladesh",
      "description" : "Address for Bangladesh Standard"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-blood-group"
      },
      "name" : "Patient Blood Group",
      "description" : "Blood group of the patient according to CCDS guideline"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-condition"
      },
      "name" : "BD Core Condition Profile (ICD-11)",
      "description" : "Condition resource coded with ICD-11 MMS, restricted to Diagnosis and\nFinding class concepts. Defined in the Bangladesh Core FHIR Implementation\nGuide (BD-Core-FHIR-IG) published by DGHS/MoHFW."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-divisions"
      },
      "name" : "Division",
      "description" : "BD Division"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-encounter"
      },
      "name" : "Encounter Profile for Bangladesh",
      "description" : "Profile of Encounter Bangladesh Standard"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-immunization"
      },
      "name" : "Immunization Profile for Bangladesh",
      "description" : "Bangladesh Immunization Profile"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-lab-panel-observation"
      },
      "name" : "Bangladesh Laboratory Panel Observation",
      "description" : "Profile for laboratory panel (order-level) Observations in Bangladesh.\nRepresents an ordered laboratory test panel (e.g. CBC, LFT, RFT) as the\nparent Observation in a hasMember hierarchy.\n\nUsage:\n  - Observation.code is the panel/order code (from BD LOINC Lab Panels ValueSet)\n  - Observation.hasMember references individual result Observations\n    (bd-lab-result-observation) for each component\n  - Observation.value[x] is prohibited — panels do not carry a direct result value\n  - Observation.category is fixed to 'laboratory'\n\nFHIR hasMember pattern:\n  DiagnosticReport.result --> bd-lab-panel-observation\n                                  └── hasMember --> bd-lab-result-observation (x N)"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-lab-report"
      },
      "name" : "Bangladesh Laboratory Report",
      "description" : "Profile for laboratory DiagnosticReport in Bangladesh, aligned with IPS\n(International Patient Summary) DiagnosticReport pattern.\n\nUsage:\n  - Represents a complete laboratory report for a patient encounter\n  - DiagnosticReport.result references panel-level Observations\n    (bd-lab-panel-observation) or standalone result Observations\n    (bd-lab-result-observation) where no panel grouping exists\n  - DiagnosticReport.code is fixed to LOINC 11502-2 (Laboratory report)\n  - specimen is SHOULD (MS, 0..*)\n\nReport structure:\n  bd-lab-report (DiagnosticReport)\n      ├── result --> bd-lab-panel-observation\n      │                 └── hasMember --> bd-lab-result-observation (x N)\n      └── result --> bd-lab-result-observation  (standalone, no panel)"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-lab-result-observation"
      },
      "name" : "Bangladesh Laboratory Result Observation",
      "description" : "Profile for individual laboratory result (component-level) Observations\nin Bangladesh. Represents a single test result within a laboratory panel\n(e.g. Haemoglobin within a CBC panel).\n\nUsage:\n  - Observation.code is the result/component code (from BD LOINC Lab Results ValueSet)\n  - Observation.value[x] is required — every leaf result must carry a value\n  - Observation.hasMember is prohibited — leaf results cannot group further\n  - Observation.derivedFrom references the parent panel Observation\n  - Observation.category is fixed to 'laboratory'\n\nFHIR hasMember pattern:\n  bd-lab-panel-observation\n      └── hasMember --> bd-lab-result-observation (this profile)\n\nCoded results (Ord/Nom scale):\n  Use valueCodeableConcept with codes from BD LOINC Answer Lists ValueSet."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-location"
      },
      "name" : "Location of Immunization for Bangladesh",
      "description" : "Address for Bangladesh Standard"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-medication-request"
      },
      "name" : "Medication Request Profile for Bangladesh",
      "description" : "Profile of the MedicationRequest resource for the Bangladesh National Health\nInformation Exchange (HIE). Prescriptions must reference a BDMedication\nresource coded against the DGDA Drug Registry, ensuring all prescribed\nmedications are traceable to DGDA-registered drug products.\n\nThis profile constrains medication references to BDMedication only.\nInline medicationCodeableConcept is not permitted — all medication data\nmust be carried in a referenced BDMedication resource to support ingredient\ncoding for IPS and cross-border data exchange.\n\nRoute of administration is coded using HL7 v3 RouteOfAdministration served\nvia the national OCL terminology server."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-medication"
      },
      "name" : "Medication Profile for Bangladesh",
      "description" : "Profile of the Medication resource for the Bangladesh National Health Information\nExchange (HIE). Drug products are coded using the DGDA Drug Registry maintained\nby the Drug Registration Authority of Bangladesh and served via the national OCL\nterminology server at https://tr.ocl.dghs.gov.bd.\n\nIngredient coding uses ICD-11 MMS substance codes (XM-prefix) to support\nInternational Patient Summary (IPS) generation and cross-border data exchange.\nIngredient data is system-populated from OCL Has-active-ingredient mappings and\nis not required to be entered manually by clinicians.\n\nCombination drugs are supported via the repeating ingredient element.\nUnmatched ingredients (not yet mapped to ICD-11 substances) may be represented\nusing ingredient.itemCodeableConcept.text without a coded value.\n\nDose form is optional and should be coded using EDQM Standard Terms when\npopulated. Dose form is derivable from the DGDA drug concept via OCL lookup.\nA DGDA plain text dose form to EDQM code mapping is planned for a future\nIG version."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-name-bn"
      },
      "name" : "Bangla Name",
      "description" : "Bangla translation of the patient name"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-name-en"
      },
      "name" : "English Name",
      "description" : "English translation of the patient name"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-observation"
      },
      "name" : "Bangladesh Observation Profile",
      "description" : "Base observation profile for Bangladesh. This is an abstract-style base profile\nfrom which all BD-Core observation profiles are derived. It is not intended to\nbe used directly in clinical resources — use a derived profile instead.\n\nDerived profiles (v0.4.0):\n  - bd-lab-panel-observation  : Laboratory panel/order (hasMember pattern)\n  - bd-lab-result-observation : Laboratory leaf result (child of hasMember)\n\nPlanned derived profiles (v0.5.0+):\n  - bd-vital-signs-observation\n  - bd-exam-observation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-organization"
      },
      "name" : "Organization for Bangladesh",
      "description" : "Organization for Bangladesh Standard"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-practitioner"
      },
      "name" : "Practitioner for Bangladesh",
      "description" : "Practitioner for Bangladesh Standard"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-related-person"
      },
      "name" : "Related Person Profile for Bangladesh",
      "description" : "Profile for RelatedPerson in Bangladesh.\nUsed to represent father, mother, or guardian of a patient.\n- Identifier is mandatory and must use BD identifier systems (NID, BRN, UHID)\n- Relationship is mandatory\n- Name is mandatory"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/bd-upazillas"
      },
      "name" : "Upazilla",
      "description" : "BD Upazilla"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/icd11-cluster-expression"
      },
      "name" : "ICD-11 Cluster Expression",
      "description" : "Carries a postcoordinated ICD-11 cluster expression as a single string\non a Coding element where the stem code alone is insufficient to fully\nrepresent the clinical concept.\n\nA cluster expression combines a stem code with one or more satellite\ncodes using the & operator (combination) or / operator (specificity).\nExample: NC72.Z&XK8G&XJ7ZH&XJ7YM\n  - NC72.Z  — stem: Fracture of femur, unspecified\n  - XK8G    — satellite: laterality\n  - XJ7ZH   — satellite: fracture subtype\n  - XJ7YM   — satellite: fracture open or closed\n\nUsage rules:\n  - SHALL only be present when the expression contains at least one\n    satellite code joined by & or / operators.\n  - Single stem codes SHALL be represented in Coding.code only and\n    validated via OCL $validate-code. The cluster validator at\n    https://icd11.dghs.gov.bd/cluster/validate explicitly rejects\n    stem-only expressions.\n  - The stem code in Coding.code SHALL match the leading stem code\n    in this expression string.\n  - Satellite codes in the cluster expression are exempt from the\n    Diagnosis/Finding class restriction that applies to stem codes\n    in Condition.code.\n  - Cluster expressions SHALL be validated against the Bangladesh\n    ICD-11 Cluster Validator at https://icd11.dghs.gov.bd/cluster/validate\n    prior to submission to the HIE.\n\nCluster validator endpoint:\n  POST https://icd11.dghs.gov.bd/cluster/validate\n  Body: { \"expression\": \"NC72.Z&XK8G&XJ7ZH&XJ7YM\" }\n\nThis extension is not MustSupport and is not mandatory. It is present\nonly when postcoordination is clinically required. Cluster expressions\nare typically sourced from the WHO Electronic Coding Tool (ECT) at the\npoint of care."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/language"
      },
      "name" : "Language Extension",
      "description" : "Language"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/nationality"
      },
      "name" : "Patient Nationality",
      "description" : "Nationality of the patient based on Bangladesh country list."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/occupation-bd"
      },
      "name" : "Bangladesh Occupations",
      "description" : "Occupation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-blood-group-valueset"
      },
      "name" : "Bangladesh Blood Group ValueSet",
      "description" : "Blood group value set according to CCDS guideline"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-city-corporation-code-valueset"
      },
      "name" : "Bangladesh City Corperation ValueSet",
      "description" : "Bangladesh City Corperation Codes (only two-digit codes)"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-condition-icd11-diagnosis-valueset"
      },
      "name" : "Bangladesh ICD-11 MMS Condition ValueSet (Diagnosis and Finding)",
      "description" : "ICD-11 MMS concepts restricted to the Diagnosis (14,071) and Finding (5,590)\nconcept classes, totalling 19,661 concepts as of version 2025-01.\n\nThis ValueSet is the binding target for Condition.code in the BD-Core\nCondition profile. Substance, Organism, Device, Anatomy, and Misc class\nconcepts are excluded and SHALL NOT appear as standalone stem codes in\nCondition.code. This restriction applies to stem codes only — satellite\ncodes carried in the icd11-cluster-expression extension are exempt.\n\nThis ValueSet is an empty stub. No compose block is declared because\n$expand is not supported by the national OCL terminology server and\nno machine-executable filter for concept_class is available at the\nIG layer. The compose would be nominal only and is omitted to avoid\nmisrepresenting machine-executable semantics.\n\nThe ValueSet is hosted in OCL as a collection with 19,661 explicit\nconcept references (Diagnosis and Finding classes only). Runtime\nenforcement is via OCL ValueSet $validate-code:\n\n  GET https://tr.ocl.dghs.gov.bd/api/fhir/ValueSet/$validate-code\n      ?url=https://fhir.dghs.gov.bd/core/ValueSet/bd-condition-icd11-diagnosis-valueset\n      &system=http://id.who.int/icd/release/11/mms\n      &code={code}\n\nConfirmed behaviour:\n  - Diagnosis class (e.g. 1A00): accepted\n  - Finding class: accepted\n  - Device class (e.g. XD7EB1): rejected\n  - Substance class (e.g. XM6RB2): rejected\n\nAt the HAPI FHIR layer, enforcement is via RemoteTerminologyServiceValidationSupport\nconfigured to call OCL. HAPI FHIR deployment is a known gap to be closed\nbefore vendor onboarding.\n\nVERSION UPGRADES:\n  Upgrading to a new ICD-11 MMS release requires re-running\n  populate_condition_valueset.py. Automated via version_upgrade.py."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-country-list-valueset"
      },
      "name" : "Nationality ValueSet",
      "description" : "Nationality value set"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-district-code-valueset"
      },
      "name" : "Bangladesh district ValueSet",
      "description" : "Bangladesh district Codes (only two-digit codes)"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-division-code-valueset"
      },
      "name" : "Bangladesh Division ValueSet",
      "description" : "Bangladesh Division Codes (only two-digit codes)"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-encounter-class-subset"
      },
      "name" : "BD Encounter Class Subset",
      "description" : "Subset of EncounterClass limited to inpatient, ambulatory, and emergency."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-encounter-status-subset"
      },
      "name" : "BD Encounter Status Subset",
      "description" : "Subset of EncounterStatus limited to planned, in-progress, finished, and cancelled."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-identifier-type-valueset"
      },
      "name" : "Bangladesh Identifier Type",
      "description" : "Bangladesh Standard Identifier type"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-immunization-reaction-valueset"
      },
      "name" : "Bangladesh Immunization Reaction Value Set",
      "description" : "Allowed vaccine reactions for immunization in Bangladesh."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-immunization-route-valueset"
      },
      "name" : "Bangladesh Immunization Route Value Set",
      "description" : "Allowed administration routes for vaccines in Bangladesh."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-immunization-site-valueset"
      },
      "name" : "Bangladesh Immunization Site Value Set",
      "description" : "Allowed administration sites for vaccines in Bangladesh."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-language-valueset"
      },
      "name" : "Allowed Languages",
      "description" : "Only English and Bengali are allowed"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-loinc-answer-lists-valueset"
      },
      "name" : "Bangladesh LOINC Answer Lists ValueSet",
      "description" : "LOINC answer codes (LA-prefixed) and answer list groupers (LL-prefixed) \nfor Bangladesh laboratory results. Includes all answer codes referenced by in-scope \nlab result codes from LOINC 2.82. Used as Observation.valueCodeableConcept in \nbd-lab-result-observation for ordinal and nominal scale results."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-loinc-lab-panels-valueset"
      },
      "name" : "Bangladesh LOINC Lab Panels ValueSet",
      "description" : "LOINC orderable laboratory panel codes for Bangladesh. Includes universal \nlab order panel codes from LOINC 2.82 scoped to the Universal Lab Orders ValueSet. \nUsed as Observation.code in bd-lab-panel-observation."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-loinc-lab-results-valueset"
      },
      "name" : "Bangladesh LOINC Lab Results ValueSet",
      "description" : "LOINC leaf-level laboratory result codes for Bangladesh. Includes \nindividual component/result codes from LOINC 2.82 scoped to the Universal Lab Orders \nValueSet. Excludes discouraged and non-laboratory codes. Used as Observation.code \nin bd-lab-result-observation."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-marital-status-valueset"
      },
      "name" : "Bangladesh Marital Status ValueSet",
      "description" : "Marital status value set according to CCDS guideline"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-medication-dose-form"
      },
      "name" : "Medication Dose Form Value Set",
      "description" : "Value set containing pharmaceutical dose form concepts from the European\nDirectorate for the Quality of Medicines (EDQM) Standard Terms, domain:\nPharmaceutical Dose Forms (PDF).\n\nThis value set is used to code the physical form of a medication product\nin BDMedication.form. EDQM Standard Terms are maintained and versioned\nby the Council of Europe and are the WHO-recommended international standard\nfor pharmaceutical dose form coding.\n\nConcepts are loaded into the national OCL terminology server at\nhttps://tr.ocl.dghs.gov.bd under the MoHFW organisation as source EDQM-PDF.\n\n**Binding:** preferred on BDMedication.form — systems should use EDQM\ncodes when populating dose form, but omission is permitted. A mapping from\nDGDA plain text dose forms to EDQM codes is planned for a future IG version.\n\n**Code system canonical:** https://standardterms.edqm.eu\n**OCL source:** https://tr.ocl.dghs.gov.bd/#/orgs/MoHFW/sources/EDQM-PDF/"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-medication-valueset"
      },
      "name" : "Bangladesh Medication ValueSet",
      "description" : "Bangladesh Medication ValueSet"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-municipalities-code-valueset"
      },
      "name" : "Bangladesh Municipalities ValueSet",
      "description" : "Bangladesh Municipalities Codes (only two-digit codes)"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-occupations-valueset"
      },
      "name" : "Bangladesh Occupations ValueSet",
      "description" : "Occupations value set according to CCDS guideline"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-religions-valueset"
      },
      "name" : "Bangladesh Religions ValueSet",
      "description" : "Religions value set according to CCDS guideline"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-route-of-administration"
      },
      "name" : "Route of Administration Value Set",
      "description" : "Value set containing route of administration concepts from the HL7 Version 3\nRouteOfAdministration code system.\n\nThis value set is used to code the route by which a medication is administered\nin MedicationRequest.dosageInstruction.route. HL7 v3 RouteOfAdministration\nis a license-free, internationally recognised vocabulary already embedded in\nthe FHIR ecosystem.\n\nConcepts are loaded into the national OCL terminology server at\nhttps://tr.ocl.dghs.gov.bd under the MoHFW organisation.\n\n**Code system canonical:** http://terminology.hl7.org/CodeSystem/v3-RouteOfAdministration\n**Binding:** required on BDMedicationRequest.dosageInstruction.route"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-upazilla-code-valueset"
      },
      "name" : "Bangladesh Upazila ValueSet",
      "description" : "Bangladesh Upazila Codes (only two-digit codes)"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/bd-vaccine-valueset"
      },
      "name" : "Bangladesh Vaccine Value Set",
      "description" : "Allowed vaccines for immunization in Bangladesh."
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/dgda-registered-drugs"
      },
      "name" : "DGDA Registered Drugs Value Set",
      "description" : "Value set containing all registered drug products from the Drug Registration\nAuthority (DGDA) of Bangladesh. This value set includes 39,196 finished\npharmaceutical drug product concepts maintained in the national OCL terminology\nserver at https://tr.ocl.dghs.gov.bd.\n\nThis value set is the normative binding for BDMedication.code and represents\nthe only permitted drug coding vocabulary for medication resources in the\nBangladesh national health information exchange.\n\nValidation is performed via $validate-code and $lookup against the national\nOCL terminology server. $expand is not supported for this value set due to its\nsize.\n\nSource collection: dgda-registered-drugs-valueset (MoHFW organisation, OCL)\nOCL collection canonical: https://dgda.gov.bd/fhir/ValueSet/registered-drugs\nOCL FHIR endpoint: https://tr.ocl.dghs.gov.bd/orgs/MoHFW/collections/dgda-registered-drugs-valueset/"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/icd11-substances-valueset"
      },
      "name" : "ICD-11 Substances Value Set",
      "description" : "Value set containing all ICD-11 MMS substance and medicament concepts\n(XM-prefix concept class: Substance) maintained in the national OCL\nterminology server at https://tr.ocl.dghs.gov.bd.\n\nThis value set contains 7,776 substance concepts and is used for coding\nactive pharmaceutical ingredients in the BDMedication.ingredient element\nto support IPS generation and cross-border data exchange.\n\nThis value set is defined and maintained in OCL. It is declared here as a\nminimal stub to allow IG publisher binding resolution only.\n\n**OCL collection canonical:** https://fhir.dghs.gov.bd/core/ValueSet/icd11-substances-valueset\n**OCL FHIR endpoint:** https://tr.ocl.dghs.gov.bd/orgs/MoHFW/collections/icd11-substances-valueset/"
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "informative"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
          "valueCode" : "informative"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "BD-Core-FHIR-IG Home Page",
        "generation" : "html"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
          "valueCode" : "informative"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "background.html"
        }],
        "nameUrl" : "background.html",
        "title" : "Background and Context",
        "generation" : "html"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
          "valueCode" : "trial-use"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "spec.html"
        }],
        "nameUrl" : "spec.html",
        "title" : "Detailed BD-Core-FHIR Specification",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
            "valueCode" : "trial-use"
          },
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "fragments.html"
          }],
          "nameUrl" : "fragments.html",
          "title" : "Fragments",
          "generation" : "html"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
            "valueCode" : "trial-use"
          },
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "spec2.html"
          }],
          "nameUrl" : "spec2.html",
          "title" : "Spec sub-page",
          "generation" : "markdown"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
          "valueCode" : "informative"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "downloads.html"
        }],
        "nameUrl" : "downloads.html",
        "title" : "Useful Downloads",
        "generation" : "html"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
          "valueCode" : "informative"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "changes.html"
        }],
        "nameUrl" : "changes.html",
        "title" : "IG Change History",
        "generation" : "html"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
          "valueCode" : "informative"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "history.html"
        }],
        "nameUrl" : "history.html",
        "title" : "Version History",
        "generation" : "html"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input\\history"
    },
    {
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
