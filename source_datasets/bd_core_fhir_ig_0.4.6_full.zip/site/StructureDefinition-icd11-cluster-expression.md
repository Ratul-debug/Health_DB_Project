# ICD-11 Cluster Expression - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ICD-11 Cluster Expression**

## Extension: ICD-11 Cluster Expression 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/StructureDefinition/icd11-cluster-expression | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:ICD11ClusterExpression |

Carries a postcoordinated ICD-11 cluster expression as a single string on a Coding element where the stem code alone is insufficient to fully represent the clinical concept.

A cluster expression combines a stem code with one or more satellite codes using the & operator (combination) or / operator (specificity). Example: NC72.Z&XK8G&XJ7ZH&XJ7YM

* NC72.Z — stem: Fracture of femur, unspecified
* XK8G — satellite: laterality
* XJ7ZH — satellite: fracture subtype
* XJ7YM — satellite: fracture open or closed

Usage rules:

* SHALL only be present when the expression contains at least one satellite code joined by & or / operators.
* Single stem codes SHALL be represented in Coding.code only and validated via OCL $validate-code. The cluster validator at https://icd11.dghs.gov.bd/cluster/validate explicitly rejects stem-only expressions.
* The stem code in Coding.code SHALL match the leading stem code in this expression string.
* Satellite codes in the cluster expression are exempt from the Diagnosis/Finding class restriction that applies to stem codes in Condition.code.
* Cluster expressions SHALL be validated against the Bangladesh ICD-11 Cluster Validator at https://icd11.dghs.gov.bd/cluster/validate prior to submission to the HIE.

Cluster validator endpoint: POST https://icd11.dghs.gov.bd/cluster/validate Body: { "expression": "NC72.Z&XK8G&XJ7ZH&XJ7YM" }

This extension is not MustSupport and is not mandatory. It is present only when postcoordination is clinically required. Cluster expressions are typically sourced from the WHO Electronic Coding Tool (ECT) at the point of care.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [BD Core Condition Profile (ICD-11)](StructureDefinition-bd-condition.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/bd.fhir.core|current/StructureDefinition/icd11-cluster-expression)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-icd11-cluster-expression.csv), [Excel](StructureDefinition-icd11-cluster-expression.xlsx), [Schematron](StructureDefinition-icd11-cluster-expression.sch) 

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "icd11-cluster-expression",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/StructureDefinition/icd11-cluster-expression",
  "version" : "0.4.6",
  "name" : "ICD11ClusterExpression",
  "title" : "ICD-11 Cluster Expression",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Carries a postcoordinated ICD-11 cluster expression as a single string\non a Coding element where the stem code alone is insufficient to fully\nrepresent the clinical concept.\n\nA cluster expression combines a stem code with one or more satellite\ncodes using the & operator (combination) or / operator (specificity).\nExample: NC72.Z&XK8G&XJ7ZH&XJ7YM\n  - NC72.Z  — stem: Fracture of femur, unspecified\n  - XK8G    — satellite: laterality\n  - XJ7ZH   — satellite: fracture subtype\n  - XJ7YM   — satellite: fracture open or closed\n\nUsage rules:\n  - SHALL only be present when the expression contains at least one\n    satellite code joined by & or / operators.\n  - Single stem codes SHALL be represented in Coding.code only and\n    validated via OCL $validate-code. The cluster validator at\n    https://icd11.dghs.gov.bd/cluster/validate explicitly rejects\n    stem-only expressions.\n  - The stem code in Coding.code SHALL match the leading stem code\n    in this expression string.\n  - Satellite codes in the cluster expression are exempt from the\n    Diagnosis/Finding class restriction that applies to stem codes\n    in Condition.code.\n  - Cluster expressions SHALL be validated against the Bangladesh\n    ICD-11 Cluster Validator at https://icd11.dghs.gov.bd/cluster/validate\n    prior to submission to the HIE.\n\nCluster validator endpoint:\n  POST https://icd11.dghs.gov.bd/cluster/validate\n  Body: { \"expression\": \"NC72.Z&XK8G&XJ7ZH&XJ7YM\" }\n\nThis extension is not MustSupport and is not mandatory. It is present\nonly when postcoordination is clinically required. Cluster expressions\nare typically sourced from the WHO Electronic Coding Tool (ECT) at the\npoint of care.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Coding"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "ICD-11 Cluster Expression",
      "definition" : "Carries a postcoordinated ICD-11 cluster expression as a single string\non a Coding element where the stem code alone is insufficient to fully\nrepresent the clinical concept.\n\nA cluster expression combines a stem code with one or more satellite\ncodes using the & operator (combination) or / operator (specificity).\nExample: NC72.Z&XK8G&XJ7ZH&XJ7YM\n  - NC72.Z  — stem: Fracture of femur, unspecified\n  - XK8G    — satellite: laterality\n  - XJ7ZH   — satellite: fracture subtype\n  - XJ7YM   — satellite: fracture open or closed\n\nUsage rules:\n  - SHALL only be present when the expression contains at least one\n    satellite code joined by & or / operators.\n  - Single stem codes SHALL be represented in Coding.code only and\n    validated via OCL $validate-code. The cluster validator at\n    https://icd11.dghs.gov.bd/cluster/validate explicitly rejects\n    stem-only expressions.\n  - The stem code in Coding.code SHALL match the leading stem code\n    in this expression string.\n  - Satellite codes in the cluster expression are exempt from the\n    Diagnosis/Finding class restriction that applies to stem codes\n    in Condition.code.\n  - Cluster expressions SHALL be validated against the Bangladesh\n    ICD-11 Cluster Validator at https://icd11.dghs.gov.bd/cluster/validate\n    prior to submission to the HIE.\n\nCluster validator endpoint:\n  POST https://icd11.dghs.gov.bd/cluster/validate\n  Body: { \"expression\": \"NC72.Z&XK8G&XJ7ZH&XJ7YM\" }\n\nThis extension is not MustSupport and is not mandatory. It is present\nonly when postcoordination is clinically required. Cluster expressions\nare typically sourced from the WHO Electronic Coding Tool (ECT) at the\npoint of care."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "https://fhir.dghs.gov.bd/core/StructureDefinition/icd11-cluster-expression"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "short" : "ICD-11 postcoordinated cluster expression string",
      "definition" : "The full postcoordinated cluster expression, including the stem code and\nall satellite codes joined by & or / operators. Example:\nNC72.Z&XK8G&XJ7ZH&XJ7YM. The stem code in this string SHALL match\nCoding.code on the parent Coding element.",
      "min" : 1,
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
