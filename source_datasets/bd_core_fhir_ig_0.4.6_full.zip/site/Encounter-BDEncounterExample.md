# Example Encounter - BDEncounterExample - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example Encounter - BDEncounterExample**

## Example Encounter: Example Encounter - BDEncounterExample

| |
| :--- |
| *Page standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) |

-------

**English**

-------

Profile: [Encounter Profile for Bangladesh](StructureDefinition-bd-encounter.md)

**identifier**: `https://fhir.dghs.gov.bd/core/identifier/encounter`/ENC-2023-001

**status**: Finished

**class**: [ActCode: AMB](http://terminology.hl7.org/7.1.0/CodeSystem-v3-ActCode.html#v3-ActCode-AMB) (ambulatory)

**subject**: [Abul Kashem(official) Male, DoB: 1985-05-20 ( http://dghs.gov.bd/identifier/uhid#?ngen-9?)](Patient-BDPatientExample.md)

### Participants

| | | |
| :--- | :--- | :--- |
| - | **Period** | **Individual** |
| * | 2023-10-27 10:00:00+0000 --> 2023-10-27 10:30:00+0000 | [Practitioner Tanvir Ahmed (official)](Practitioner-BDPractitionerExample.md) |

**serviceProvider**: [Organization Dhaka Medical College Hospital](Organization-BDOrganizationExample.md)

-------

**German**

-------

Profile: [Encounter Profile for Bangladesh](StructureDefinition-bd-encounter.md)

**identifier**: `https://fhir.dghs.gov.bd/core/identifier/encounter`/ENC-2023-001

**status**: Finished

**class**: [ActCode: AMB](http://terminology.hl7.org/7.1.0/CodeSystem-v3-ActCode.html#v3-ActCode-AMB) (ambulatory)

**subject**: [Abul Kashem(official) Male, DoB: 1985-05-20 ( http://dghs.gov.bd/identifier/uhid#?ngen-9?)](Patient-BDPatientExample.md)

### Participants

| | | |
| :--- | :--- | :--- |
| - | **Period** | **Individual** |
| * | 2023-10-27 10:00:00+0000 --> 2023-10-27 10:30:00+0000 | [Practitioner Tanvir Ahmed (official)](Practitioner-BDPractitionerExample.md) |

**serviceProvider**: [Organization Dhaka Medical College Hospital](Organization-BDOrganizationExample.md)

-------

**French**

-------

Profil: [Encounter Profile for Bangladesh](StructureDefinition-bd-encounter.md)

**identifier**: `https://fhir.dghs.gov.bd/core/identifier/encounter`/ENC-2023-001

**status**: Finished

**class**: [ActCode: AMB](http://terminology.hl7.org/7.1.0/CodeSystem-v3-ActCode.html#v3-ActCode-AMB) (ambulatory)

**subject**: [Abul Kashem(official) Male, Date de Naissance :1985-05-20 ( http://dghs.gov.bd/identifier/uhid#?ngen-9?)](Patient-BDPatientExample.md)

### Participants

| | | |
| :--- | :--- | :--- |
| - | **Period** | **Individual** |
| * | 2023-10-27 10:00:00+0000 --> 2023-10-27 10:30:00+0000 | [Practitioner Tanvir Ahmed (official)](Practitioner-BDPractitionerExample.md) |

**serviceProvider**: [Organization Dhaka Medical College Hospital](Organization-BDOrganizationExample.md)



## Resource Content

```json
{
  "resourceType" : "Encounter",
  "id" : "BDEncounterExample",
  "meta" : {
    "profile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-encounter"]
  },
  "identifier" : [{
    "system" : "https://fhir.dghs.gov.bd/core/identifier/encounter",
    "value" : "ENC-2023-001"
  }],
  "status" : "finished",
  "class" : {
    "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
    "code" : "AMB",
    "display" : "ambulatory"
  },
  "subject" : {
    "reference" : "Patient/BDPatientExample"
  },
  "participant" : [{
    "period" : {
      "start" : "2023-10-27T10:00:00Z",
      "end" : "2023-10-27T10:30:00Z"
    },
    "individual" : {
      "reference" : "Practitioner/BDPractitionerExample"
    }
  }],
  "serviceProvider" : {
    "reference" : "Organization/BDOrganizationExample"
  }
}

```
