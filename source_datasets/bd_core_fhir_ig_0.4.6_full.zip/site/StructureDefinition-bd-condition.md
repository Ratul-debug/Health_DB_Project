# BD Core Condition Profile (ICD-11) - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BD Core Condition Profile (ICD-11)**

## Resource Profile: BD Core Condition Profile (ICD-11) 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/StructureDefinition/bd-condition | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDConditionProfile |

 
Condition resource coded with ICD-11 MMS, restricted to Diagnosis and Finding class concepts. Defined in the Bangladesh Core FHIR Implementation Guide (BD-Core-FHIR-IG) published by DGHS/MoHFW. 

**Usages:**

* Refer to this Profile: [Encounter Profile for Bangladesh](StructureDefinition-bd-encounter.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/bd.fhir.core|current/StructureDefinition/bd-condition)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-bd-condition.csv), [Excel](StructureDefinition-bd-condition.xlsx), [Schematron](StructureDefinition-bd-condition.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "bd-condition",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-condition",
  "version" : "0.4.6",
  "name" : "BDConditionProfile",
  "title" : "BD Core Condition Profile (ICD-11)",
  "status" : "draft",
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Condition resource coded with ICD-11 MMS, restricted to Diagnosis and\nFinding class concepts. Defined in the Bangladesh Core FHIR Implementation\nGuide (BD-Core-FHIR-IG) published by DGHS/MoHFW.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Condition",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Condition",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Condition",
      "path" : "Condition"
    },
    {
      "id" : "Condition.code",
      "path" : "Condition.code",
      "comment" : "Condition.code SHALL contain at least one coding conforming to the\ncoding[stem] slice with system = http://id.who.int/icd/release/11/mms.\n\nStem code rules:\n  - The stem code SHALL be a Diagnosis or Finding class ICD-11 MMS concept.\n  - This restriction is enforced at runtime via OCL ValueSet $validate-code\n    against the Bangladesh ICD-11 MMS Condition ValueSet.\n  - Stem-only codes SHALL be validated via OCL $validate-code.\n  - Substance, Organism, Device, Anatomy, and Misc class concepts SHALL NOT\n    appear as standalone stem codes in Condition.code.\n\nCluster expression rules:\n  - When a concept requires postcoordination, the full cluster expression\n    SHALL be carried in the icd11-cluster-expression extension on coding[stem].\n  - The icd11-cluster-expression extension SHALL only be present when the\n    expression contains at least one satellite code joined by & or / operators.\n  - Satellite codes in the cluster expression are exempt from the\n    Diagnosis/Finding class restriction.\n  - Cluster expressions SHALL be validated against the Bangladesh ICD-11\n    Cluster Validator at https://icd11.dghs.gov.bd/cluster/validate\n    prior to submission to the HIE.\n\nAdditional local codings are permitted alongside the mandatory ICD-11 stem\n(slicing is open). Cluster expressions are typically sourced from the WHO\nElectronic Coding Tool (ECT) at the point of care.",
      "min" : 1,
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://fhir.dghs.gov.bd/core/ValueSet/bd-condition-icd11-diagnosis-valueset"
      }
    },
    {
      "id" : "Condition.code.coding",
      "path" : "Condition.code.coding",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "system"
        }],
        "description" : "Slice requiring exactly one ICD-11 MMS stem code. Additional local codings permitted.",
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Condition.code.coding:stem",
      "path" : "Condition.code.coding",
      "sliceName" : "stem",
      "short" : "Mandatory ICD-11 MMS stem code",
      "definition" : "Exactly one ICD-11 MMS stem code is required. The stem code SHALL be a\nDiagnosis or Finding class concept. When the condition requires\npostcoordination, the full cluster expression is carried in the\nicd11-cluster-expression extension on this coding element.",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Condition.code.coding:stem.extension:clusterExpression",
      "path" : "Condition.code.coding.extension",
      "sliceName" : "clusterExpression",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/icd11-cluster-expression"]
      }]
    },
    {
      "id" : "Condition.code.coding:stem.system",
      "path" : "Condition.code.coding.system",
      "min" : 1,
      "fixedUri" : "http://id.who.int/icd/release/11/mms"
    },
    {
      "id" : "Condition.code.coding:stem.code",
      "path" : "Condition.code.coding.code",
      "min" : 1
    }]
  }
}

```
