# Related Person Profile for Bangladesh - Bangladesh Core FHIR Implementation Guide v0.4.6

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Related Person Profile for Bangladesh**

## Resource Profile: Related Person Profile for Bangladesh 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://fhir.dghs.gov.bd/core/StructureDefinition/bd-related-person | *Version*:0.4.6 | |
| * Standards status: *[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BDRelatedPerson |

 
Profile for RelatedPerson in Bangladesh. Used to represent father, mother, or guardian of a patient. 
* Identifier is mandatory and must use BD identifier systems (NID, BRN, UHID)
* Relationship is mandatory
* Name is mandatory
 

**Usages:**

* Refer to this Profile: [Patient Profile for Bangladesh](StructureDefinition-bd-patient.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/bd.fhir.core|current/StructureDefinition/bd-related-person)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-bd-related-person.csv), [Excel](StructureDefinition-bd-related-person.xlsx), [Schematron](StructureDefinition-bd-related-person.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "bd-related-person",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "informative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.dghs.gov.bd/core/ImplementationGuide/bd.fhir.core"
      }]
    }
  }],
  "url" : "https://fhir.dghs.gov.bd/core/StructureDefinition/bd-related-person",
  "version" : "0.4.6",
  "name" : "BDRelatedPerson",
  "title" : "Related Person Profile for Bangladesh",
  "status" : "draft",
  "date" : "2026-04-27T17:15:47+00:00",
  "publisher" : "Directorate General of Health Services (DGHS), Bangladesh",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "http://dghs.gov.bd"
    }]
  }],
  "description" : "Profile for RelatedPerson in Bangladesh.\nUsed to represent father, mother, or guardian of a patient.\n- Identifier is mandatory and must use BD identifier systems (NID, BRN, UHID)\n- Relationship is mandatory\n- Name is mandatory",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "050"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "RelatedPerson",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/RelatedPerson",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "RelatedPerson",
      "path" : "RelatedPerson"
    },
    {
      "id" : "RelatedPerson.identifier",
      "path" : "RelatedPerson.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "system"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "RelatedPerson.identifier:NID",
      "path" : "RelatedPerson.identifier",
      "sliceName" : "NID",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "RelatedPerson.identifier:NID.type.coding.system",
      "path" : "RelatedPerson.identifier.type.coding.system",
      "patternUri" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-identifier-type"
    },
    {
      "id" : "RelatedPerson.identifier:NID.type.coding.code",
      "path" : "RelatedPerson.identifier.type.coding.code",
      "patternCode" : "NID"
    },
    {
      "id" : "RelatedPerson.identifier:NID.type.text",
      "path" : "RelatedPerson.identifier.type.text",
      "patternString" : "Organization identifier"
    },
    {
      "id" : "RelatedPerson.identifier:NID.system",
      "path" : "RelatedPerson.identifier.system",
      "min" : 1,
      "patternUri" : "http://dghs.gov.bd/identifier/nid"
    },
    {
      "id" : "RelatedPerson.identifier:BRN",
      "path" : "RelatedPerson.identifier",
      "sliceName" : "BRN",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "RelatedPerson.identifier:BRN.type.coding.system",
      "path" : "RelatedPerson.identifier.type.coding.system",
      "patternUri" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-identifier-type"
    },
    {
      "id" : "RelatedPerson.identifier:BRN.type.coding.code",
      "path" : "RelatedPerson.identifier.type.coding.code",
      "patternCode" : "BRN"
    },
    {
      "id" : "RelatedPerson.identifier:BRN.type.text",
      "path" : "RelatedPerson.identifier.type.text",
      "patternString" : "Organization identifier"
    },
    {
      "id" : "RelatedPerson.identifier:BRN.system",
      "path" : "RelatedPerson.identifier.system",
      "min" : 1,
      "patternUri" : "http://dghs.gov.bd/identifier/brn"
    },
    {
      "id" : "RelatedPerson.identifier:UHID",
      "path" : "RelatedPerson.identifier",
      "sliceName" : "UHID",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "RelatedPerson.identifier:UHID.type.coding.system",
      "path" : "RelatedPerson.identifier.type.coding.system",
      "patternUri" : "https://fhir.dghs.gov.bd/core/CodeSystem/bd-identifier-type"
    },
    {
      "id" : "RelatedPerson.identifier:UHID.type.coding.code",
      "path" : "RelatedPerson.identifier.type.coding.code",
      "patternCode" : "UHID"
    },
    {
      "id" : "RelatedPerson.identifier:UHID.type.text",
      "path" : "RelatedPerson.identifier.type.text",
      "patternString" : "Organization identifier"
    },
    {
      "id" : "RelatedPerson.identifier:UHID.system",
      "path" : "RelatedPerson.identifier.system",
      "min" : 1,
      "patternUri" : "http://dghs.gov.bd/identifier/uhid"
    },
    {
      "id" : "RelatedPerson.patient",
      "path" : "RelatedPerson.patient",
      "definition" : "The patient this related person is associated with",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://fhir.dghs.gov.bd/core/StructureDefinition/bd-patient"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "RelatedPerson.relationship",
      "path" : "RelatedPerson.relationship",
      "definition" : "Relationship of this person to the patient",
      "comment" : "E.g. FTH (father), MTH (mother), GUARD (guardian) from v3-RoleCode",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "RelatedPerson.name",
      "path" : "RelatedPerson.name",
      "definition" : "Name of the related person",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    }]
  }
}

```
